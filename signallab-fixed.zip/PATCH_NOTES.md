# SignalLab backtest fixes

This build fixes the most important problems found in the uploaded project:

1. **Historical range bug fixed** — Last 7/30/90 Days now generates the correct number of candles for the selected timeframe instead of a few hundred candles masquerading as multi-day data.
2. **Trade cap increased** — the old 50-trade cap is now 500, reducing the chance that a short demo dataset makes a strategy look artificially perfect.
3. **Longer backtest timeout** — increased from 8 seconds to 30 seconds so the corrected historical ranges can be processed on a phone.
4. **Expiry/timeframe mismatch prevented** — the UI only offers expiry durations that are exact multiples of the selected chart timeframe. A 60-minute expiry was added for 1H charts.
5. **Strategy selection respects expiry compatibility** — selecting a strategy automatically chooses a compatible expiry when necessary.
6. **Audit disclosure** — if the 500-trade safety cap is reached, the audit explicitly reports that the result covers only the processed portion.

## Important limitation

The project still uses `DeterministicDemoHistoricalDataProvider`. The app therefore **does not contain real market historical data**. Backtest results are simulations and must not be treated as evidence of real-world profitability until a verified historical OHLC data provider is connected.
