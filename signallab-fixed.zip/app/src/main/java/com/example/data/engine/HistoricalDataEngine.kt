package com.example.data.engine

import com.example.data.model.Asset
import com.example.data.model.Candle
import com.example.data.model.Timeframe
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Clean data provider abstraction for obtaining OHLCV historical candles.
 */
interface HistoricalDataProvider {
    val name: String
    val isRealData: Boolean

    fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        count: Int,
        endTimeMs: Long = System.currentTimeMillis()
    ): List<Candle>

    fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        startDateMs: Long,
        endDateMs: Long
    ): List<Candle>
}

/**
 * Deterministic Demo Historical Data Provider.
 * Generates continuous, realistic OHLCV market candle series using deterministic mathematical seed paths.
 * Explicitly designated as DEMO DATA ONLY.
 */
class DeterministicDemoHistoricalDataProvider : HistoricalDataProvider {
    override val name: String = "Deterministic Demo Simulation Engine"
    override val isRealData: Boolean = false

    override fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        count: Int,
        endTimeMs: Long
    ): List<Candle> {
        val candles = ArrayList<Candle>(count)
        val stepMs = timeframe.minutes * 60 * 1000L
        val startTimeMs = endTimeMs - (count * stepMs)

        // Deterministic seed derived from asset, timeframe, and count
        val seed = asset.name.hashCode().toLong() * 31L +
                timeframe.name.hashCode().toLong() * 17L +
                count.toLong() * 7L
        val random = Random(seed)

        val baseVolatility = when (asset) {
            Asset.BTC_USD -> 160.0
            Asset.USD_JPY -> 0.15
            Asset.GBP_USD -> 0.00075
            Asset.EUR_USD -> 0.00055
        }

        val tfMultiplier = kotlin.math.sqrt(timeframe.minutes.toDouble())
        val volatility = baseVolatility * tfMultiplier

        var currentPrice = asset.basePrice * (1.0 + (random.nextDouble() - 0.5) * 0.015)

        for (i in 0 until count) {
            val timestamp = startTimeMs + (i * stepMs)

            // Market wave dynamics: macro cycle + micro oscillation + noise
            val macroCycle = sin(i / 28.0) * volatility * 0.9
            val microCycle = cos(i / 7.0) * volatility * 0.4
            val noise = (random.nextDouble() - 0.495) * volatility * 1.2

            val open = currentPrice
            val priceChange = (macroCycle + microCycle + noise) * (0.8 + random.nextDouble() * 0.4)
            val close = (open + priceChange).coerceAtLeast(0.0001)

            val highWick = random.nextDouble() * volatility * 0.85
            val lowWick = random.nextDouble() * volatility * 0.85
            val high = max(open, close) + highWick
            val low = (min(open, close) - lowWick).coerceAtLeast(0.00001)

            val baseVol = when (asset) {
                Asset.BTC_USD -> 450.0
                Asset.USD_JPY -> 1200.0
                else -> 800.0
            }
            val isSpike = random.nextDouble() > 0.88
            val volumeMultiplier = if (isSpike) 2.2 + random.nextDouble() * 1.8 else 0.6 + random.nextDouble() * 0.8
            val volume = baseVol * volumeMultiplier

            candles.add(
                Candle(
                    timestamp = timestamp,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = volume
                )
            )

            currentPrice = close
        }

        return candles
    }

    override fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        startDateMs: Long,
        endDateMs: Long
    ): List<Candle> {
        val stepMs = timeframe.minutes * 60 * 1000L
        val count = max(10, ((endDateMs - startDateMs) / stepMs).toInt())
        return fetchCandles(asset, timeframe, count, endDateMs)
    }
}

/**
 * Historical Data Engine singleton that coordinates market data providers.
 */
object HistoricalDataEngine {

    private var currentProvider: HistoricalDataProvider = DeterministicDemoHistoricalDataProvider()

    fun setProvider(provider: HistoricalDataProvider) {
        currentProvider = provider
    }

    fun getProvider(): HistoricalDataProvider = currentProvider

    fun generateCandles(
        asset: Asset,
        timeframe: Timeframe,
        count: Int = 200,
        endTimeMs: Long = System.currentTimeMillis()
    ): List<Candle> {
        return currentProvider.fetchCandles(asset, timeframe, count, endTimeMs)
    }

    fun getCandleCountForRange(rangeLabel: String, timeframe: Timeframe): Int {
        // The previous implementation returned a few hundred candles for a
        // "7/30/90 day" range (for example, only 380 M5 candles for 30 days).
        // That made the UI label a dataset as 30 days while it actually
        // represented less than 32 hours. Generate the requested duration.
        val durationMs = getRangeDurationMs(rangeLabel)
        val stepMs = timeframe.minutes * 60_000L
        return ((durationMs + stepMs - 1L) / stepMs).toInt() + 1
    }

    fun getRangeDurationMs(rangeLabel: String): Long {
        val dayMs = 24 * 60 * 60 * 1000L
        return when (rangeLabel) {
            "Last 7 Days" -> 7 * dayMs
            "Last 30 Days" -> 30 * dayMs
            "Last 90 Days" -> 90 * dayMs
            else -> 30 * dayMs
        }
    }
}
