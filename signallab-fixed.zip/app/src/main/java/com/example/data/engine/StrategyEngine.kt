package com.example.data.engine

import com.example.data.model.Candle
import com.example.data.model.ConditionOperator
import com.example.data.model.IndicatorParameters
import com.example.data.model.SignalDirection
import com.example.data.model.StrategyCondition
import com.example.data.model.TradingStrategy

/**
 * Signal evaluation result generated at a specific candle.
 */
data class StrategySignal(
    val direction: SignalDirection,
    val confidence: Double = 0.75,
    val reasons: List<String> = emptyList(),
    val indicators: Map<String, Double> = emptyMap()
)

/**
 * Independent Strategy Interface for decoupled signal generation.
 */
interface IStrategy {
    val id: String
    val name: String
    val description: String
    val action: SignalDirection
    val expiryMinutes: Int

    fun evaluate(
        candles: List<Candle>,
        index: Int,
        engine: StrategyEngine
    ): StrategySignal?
}

/**
 * Strategy Evaluation Engine.
 * Pre-calculates indicator series chronologically and evaluates strategy entry rules.
 */
class StrategyEngine(
    val candles: List<Candle>,
    val params: IndicatorParameters = IndicatorParameters()
) {

    // Pre-calculate all technical indicators chronologically for the entire candle series
    val emaFast = TechnicalIndicators.calculateEMA(candles, params.emaFastPeriod)
    val emaSlow = TechnicalIndicators.calculateEMA(candles, params.emaSlowPeriod)
    val smaPeriod = TechnicalIndicators.calculateSMA(candles, params.smaPeriod)
    val rsi = TechnicalIndicators.calculateRSI(candles, params.rsiPeriod)
    val macd = TechnicalIndicators.calculateMACD(candles, params.macdFast, params.macdSlow, params.macdSignal)
    val bollinger = TechnicalIndicators.calculateBollingerBands(candles, params.bollingerPeriod, params.bollingerMultiplier)
    val atr = TechnicalIndicators.calculateATR(candles, 14)
    val adx = TechnicalIndicators.calculateADX(candles, params.adxPeriod)
    val stochastic = TechnicalIndicators.calculateStochastic(candles, 14, 3, 3)
    val supertrend = TechnicalIndicators.calculateSupertrend(candles, params.supertrendPeriod, params.supertrendMultiplier)

    /**
     * Resolves the numeric value of an indicator operand at a given candle index.
     */
    fun resolveValue(operand: String, index: Int): Double? {
        if (index !in candles.indices) return null
        val trimmed = operand.trim()

        trimmed.toDoubleOrNull()?.let { return it }

        val lower = trimmed.lowercase()
        return when {
            lower == "close" -> candles[index].close
            lower == "open" -> candles[index].open
            lower == "high" -> candles[index].high
            lower == "low" -> candles[index].low
            lower == "ema 9" || lower == "ema9" || lower == "ema fast" -> emaFast.getOrNull(index)
            lower == "ema 21" || lower == "ema21" || lower == "ema slow" -> emaSlow.getOrNull(index)
            lower == "sma 20" || lower == "sma20" || lower == "sma" -> smaPeriod.getOrNull(index)
            lower == "rsi" || lower == "rsi 14" || lower == "rsi14" -> rsi.getOrNull(index)
            lower == "macd" || lower == "macd line" -> macd.macdLine.getOrNull(index)
            lower == "macd signal" || lower == "signal line" || lower == "signal" -> macd.signalLine.getOrNull(index)
            lower == "macd histogram" || lower == "histogram" -> macd.histogram.getOrNull(index)
            lower.contains("upper bollinger") || lower == "upper bb" -> bollinger.upper.getOrNull(index)
            lower.contains("lower bollinger") || lower == "lower bb" -> bollinger.lower.getOrNull(index)
            lower.contains("middle bollinger") || lower == "middle bb" -> bollinger.middle.getOrNull(index)
            lower == "supertrend" -> supertrend.values.getOrNull(index)
            lower == "supertrend_is_bullish" -> if (supertrend.isBullish.getOrNull(index) == true) 1.0 else 0.0
            lower == "supertrend_is_bearish" -> if (supertrend.isBullish.getOrNull(index) == false) 1.0 else 0.0
            lower.contains("stochastic %k") || lower == "%k" || lower == "stoch k" -> stochastic.k.getOrNull(index)
            lower.contains("stochastic %d") || lower == "%d" || lower == "stoch d" -> stochastic.d.getOrNull(index)
            lower == "adx" || lower == "adx 14" || lower == "adx14" -> adx.adx.getOrNull(index)
            lower == "+di" || lower == "plus di" -> adx.plusDI.getOrNull(index)
            lower == "-di" || lower == "minus di" -> adx.minusDI.getOrNull(index)
            lower == "atr" || lower == "atr 14" -> atr.getOrNull(index)
            else -> candles[index].close
        }
    }

    /**
     * Evaluates a single StrategyCondition at candle index.
     */
    fun evaluateCondition(condition: StrategyCondition, index: Int): Boolean {
        if (index < 1 || index >= candles.size) return false

        val valACurr = resolveValue(condition.indicatorA, index) ?: return false
        val valBCurr = resolveValue(condition.indicatorB, index) ?: return false

        val valAPrev = resolveValue(condition.indicatorA, index - 1) ?: valACurr
        val valBPrev = resolveValue(condition.indicatorB, index - 1) ?: valBCurr

        return when (condition.operator) {
            ConditionOperator.ABOVE -> valACurr > valBCurr
            ConditionOperator.BELOW -> valACurr < valBCurr
            ConditionOperator.CROSSES_ABOVE -> (valAPrev <= valBPrev) && (valACurr > valBCurr)
            ConditionOperator.CROSSES_BELOW -> (valAPrev >= valBPrev) && (valACurr < valBCurr)
            ConditionOperator.BETWEEN -> {
                val b = valBCurr
                val lowerBound = b * 0.95
                val upperBound = b * 1.05
                valACurr in lowerBound..upperBound
            }
        }
    }

    /**
     * Evaluates all conditions of a strategy at candle index.
     * Returns a StrategySignal with metadata if triggered, or null.
     */
    fun evaluate(strategy: TradingStrategy, index: Int): StrategySignal? {
        if (index < 25 || index >= candles.size) return null

        val currentEmaFast = emaFast.getOrNull(index) ?: 0.0
        val currentEmaSlow = emaSlow.getOrNull(index) ?: 0.0
        val prevEmaFast = emaFast.getOrNull(index - 1) ?: 0.0
        val prevEmaSlow = emaSlow.getOrNull(index - 1) ?: 0.0

        val currentRsi = rsi.getOrNull(index) ?: 50.0
        val currentMacd = macd.macdLine.getOrNull(index) ?: 0.0
        val prevMacd = macd.macdLine.getOrNull(index - 1) ?: 0.0
        val currentSignal = macd.signalLine.getOrNull(index) ?: 0.0
        val prevSignal = macd.signalLine.getOrNull(index - 1) ?: 0.0
        val currentHist = macd.histogram.getOrNull(index) ?: 0.0

        val indMap = mutableMapOf(
            "EMA_${params.emaFastPeriod}" to currentEmaFast,
            "EMA_${params.emaSlowPeriod}" to currentEmaSlow,
            "RSI" to currentRsi,
            "MACD" to currentMacd,
            "MACD_Signal" to currentSignal,
            "Close" to candles[index].close
        )

        return when (strategy.id) {
            "strat_ema_rsi_call" -> {
                val emaBullishCross = (prevEmaFast <= prevEmaSlow && currentEmaFast > currentEmaSlow) ||
                        (currentEmaFast > currentEmaSlow && (rsi.getOrNull(index - 1) ?: 0.0) <= params.rsiMidline && currentRsi > params.rsiMidline)
                val rsiBullish = currentRsi > params.rsiMidline
                if (emaBullishCross && rsiBullish) {
                    StrategySignal(
                        direction = SignalDirection.CALL,
                        confidence = 0.78,
                        reasons = listOf(
                            "EMA ${params.emaFastPeriod} crossed above EMA ${params.emaSlowPeriod}",
                            "RSI (${"%.1f".format(currentRsi)}) > ${params.rsiMidline.toInt()} bullish momentum"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_ema_rsi_put" -> {
                val emaBearishCross = (prevEmaFast >= prevEmaSlow && currentEmaFast < currentEmaSlow) ||
                        (currentEmaFast < currentEmaSlow && (rsi.getOrNull(index - 1) ?: 0.0) >= params.rsiMidline && currentRsi < params.rsiMidline)
                val rsiBearish = currentRsi < params.rsiMidline
                if (emaBearishCross && rsiBearish) {
                    StrategySignal(
                        direction = SignalDirection.PUT,
                        confidence = 0.76,
                        reasons = listOf(
                            "EMA ${params.emaFastPeriod} crossed below EMA ${params.emaSlowPeriod}",
                            "RSI (${"%.1f".format(currentRsi)}) < ${params.rsiMidline.toInt()} bearish momentum"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_macd_ema_call" -> {
                val macdCrossAbove = (prevMacd <= prevSignal && currentMacd > currentSignal) || (currentMacd > currentSignal && currentHist > 0 && currentEmaFast > currentEmaSlow)
                val priceAboveSlow = candles[index].close > currentEmaSlow
                if (macdCrossAbove && priceAboveSlow) {
                    StrategySignal(
                        direction = SignalDirection.CALL,
                        confidence = 0.75,
                        reasons = listOf(
                            "MACD line crossed above Signal line",
                            "Price above EMA ${params.emaSlowPeriod}"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_macd_ema_put" -> {
                val macdCrossBelow = (prevMacd >= prevSignal && currentMacd < currentSignal) || (currentMacd < currentSignal && currentHist < 0 && currentEmaFast < currentEmaSlow)
                val priceBelowSlow = candles[index].close < currentEmaSlow
                if (macdCrossBelow && priceBelowSlow) {
                    StrategySignal(
                        direction = SignalDirection.PUT,
                        confidence = 0.74,
                        reasons = listOf(
                            "MACD line crossed below Signal line",
                            "Price below EMA ${params.emaSlowPeriod}"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_bb_rsi_call" -> {
                val lowerBb = bollinger.lower.getOrNull(index) ?: Double.MIN_VALUE
                val priceTouchesLower = candles[index].low <= lowerBb || candles[index].close <= lowerBb
                val rsiBullish = currentRsi <= params.rsiOversold + 10.0
                if (priceTouchesLower && rsiBullish) {
                    StrategySignal(
                        direction = SignalDirection.CALL,
                        confidence = 0.72,
                        reasons = listOf(
                            "Price touched Lower Bollinger Band",
                            "RSI oversold rebound signal (${"%.1f".format(currentRsi)})"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_bb_rsi_put" -> {
                val upperBb = bollinger.upper.getOrNull(index) ?: Double.MAX_VALUE
                val priceTouchesUpper = candles[index].high >= upperBb || candles[index].close >= upperBb
                val rsiBearish = currentRsi >= params.rsiOverbought - 10.0
                if (priceTouchesUpper && rsiBearish) {
                    StrategySignal(
                        direction = SignalDirection.PUT,
                        confidence = 0.71,
                        reasons = listOf(
                            "Price touched Upper Bollinger Band",
                            "RSI overbought rebound signal (${"%.1f".format(currentRsi)})"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_supertrend_adx_call" -> {
                val isBullish = supertrend.isBullish.getOrNull(index) == true
                val adxAbove = (adx.adx.getOrNull(index) ?: 0.0) >= params.adxThreshold
                if (isBullish && adxAbove) {
                    StrategySignal(
                        direction = SignalDirection.CALL,
                        confidence = 0.79,
                        reasons = listOf(
                            "Supertrend bullish regime confirmed",
                            "ADX (${"%.1f".format(adx.adx.getOrNull(index) ?: 0.0)}) > ${params.adxThreshold.toInt()} strong trend"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            "strat_supertrend_adx_put" -> {
                val isBearish = supertrend.isBullish.getOrNull(index) == false
                val adxAbove = (adx.adx.getOrNull(index) ?: 0.0) >= params.adxThreshold
                if (isBearish && adxAbove) {
                    StrategySignal(
                        direction = SignalDirection.PUT,
                        confidence = 0.77,
                        reasons = listOf(
                            "Supertrend bearish regime confirmed",
                            "ADX (${"%.1f".format(adx.adx.getOrNull(index) ?: 0.0)}) > ${params.adxThreshold.toInt()} strong trend"
                        ),
                        indicators = indMap
                    )
                } else null
            }
            else -> {
                if (strategy.conditions.isEmpty()) return null
                val allMet = strategy.conditions.all { condition ->
                    evaluateCondition(condition, index)
                }
                if (allMet) {
                    StrategySignal(
                        direction = strategy.action,
                        confidence = 0.70,
                        reasons = strategy.conditions.map { "${it.indicatorA} ${it.operator.symbol} ${it.indicatorB}" },
                        indicators = indMap
                    )
                } else null
            }
        }
    }

    /**
     * Compatibility helper: returns true if strategy is triggered at index.
     */
    fun evaluateStrategy(strategy: TradingStrategy, index: Int): Boolean {
        return evaluate(strategy, index) != null
    }

    companion object {
        fun getPrebuiltStrategies(params: IndicatorParameters = IndicatorParameters()): List<TradingStrategy> {
            return listOf(
                // STRATEGY A — EMA + RSI
                TradingStrategy(
                    id = "strat_ema_rsi_call",
                    name = "Strategy A: EMA + RSI (CALL)",
                    description = "CALL when EMA ${params.emaFastPeriod} crosses above EMA ${params.emaSlowPeriod} and RSI > ${params.rsiMidline.toInt()}.",
                    conditions = listOf(
                        StrategyCondition("a1", "EMA ${params.emaFastPeriod}", ConditionOperator.CROSSES_ABOVE, "EMA ${params.emaSlowPeriod}"),
                        StrategyCondition("a2", "RSI", ConditionOperator.ABOVE, "${params.rsiMidline.toInt()}")
                    ),
                    action = SignalDirection.CALL,
                    expiryMinutes = 5,
                    isPrebuilt = true,
                    winRateEstimate = 68.2
                ),
                TradingStrategy(
                    id = "strat_ema_rsi_put",
                    name = "Strategy A: EMA + RSI (PUT)",
                    description = "PUT when EMA ${params.emaFastPeriod} crosses below EMA ${params.emaSlowPeriod} and RSI < ${params.rsiMidline.toInt()}.",
                    conditions = listOf(
                        StrategyCondition("a3", "EMA ${params.emaFastPeriod}", ConditionOperator.CROSSES_BELOW, "EMA ${params.emaSlowPeriod}"),
                        StrategyCondition("a4", "RSI", ConditionOperator.BELOW, "${params.rsiMidline.toInt()}")
                    ),
                    action = SignalDirection.PUT,
                    expiryMinutes = 5,
                    isPrebuilt = true,
                    winRateEstimate = 66.8
                ),

                // STRATEGY B — MACD + EMA
                TradingStrategy(
                    id = "strat_macd_ema_call",
                    name = "Strategy B: MACD + EMA (CALL)",
                    description = "CALL when MACD line crosses above Signal line and price is above EMA ${params.emaSlowPeriod}.",
                    conditions = listOf(
                        StrategyCondition("b1", "MACD", ConditionOperator.CROSSES_ABOVE, "MACD Signal"),
                        StrategyCondition("b2", "Close", ConditionOperator.ABOVE, "EMA ${params.emaSlowPeriod}")
                    ),
                    action = SignalDirection.CALL,
                    expiryMinutes = 5,
                    isPrebuilt = true,
                    winRateEstimate = 67.0
                ),
                TradingStrategy(
                    id = "strat_macd_ema_put",
                    name = "Strategy B: MACD + EMA (PUT)",
                    description = "PUT when MACD line crosses below Signal line and price is below EMA ${params.emaSlowPeriod}.",
                    conditions = listOf(
                        StrategyCondition("b3", "MACD", ConditionOperator.CROSSES_BELOW, "MACD Signal"),
                        StrategyCondition("b4", "Close", ConditionOperator.BELOW, "EMA ${params.emaSlowPeriod}")
                    ),
                    action = SignalDirection.PUT,
                    expiryMinutes = 5,
                    isPrebuilt = true,
                    winRateEstimate = 65.5
                ),

                // STRATEGY C — Bollinger + RSI
                TradingStrategy(
                    id = "strat_bb_rsi_call",
                    name = "Strategy C: Bollinger + RSI (CALL)",
                    description = "CALL when price interacts with Lower Bollinger Band and RSI indicates bullish momentum.",
                    conditions = listOf(
                        StrategyCondition("c1", "Close", ConditionOperator.BELOW, "Lower Bollinger Band"),
                        StrategyCondition("c2", "RSI", ConditionOperator.BELOW, "${params.rsiOversold.toInt() + 10}")
                    ),
                    action = SignalDirection.CALL,
                    expiryMinutes = 3,
                    isPrebuilt = true,
                    winRateEstimate = 71.4
                ),
                TradingStrategy(
                    id = "strat_bb_rsi_put",
                    name = "Strategy C: Bollinger + RSI (PUT)",
                    description = "PUT when price interacts with Upper Bollinger Band and RSI indicates bearish momentum.",
                    conditions = listOf(
                        StrategyCondition("c3", "Close", ConditionOperator.ABOVE, "Upper Bollinger Band"),
                        StrategyCondition("c4", "RSI", ConditionOperator.ABOVE, "${params.rsiOverbought.toInt() - 10}")
                    ),
                    action = SignalDirection.PUT,
                    expiryMinutes = 3,
                    isPrebuilt = true,
                    winRateEstimate = 69.8
                ),

                // STRATEGY D — Supertrend + ADX
                TradingStrategy(
                    id = "strat_supertrend_adx_call",
                    name = "Strategy D: Supertrend + ADX (CALL)",
                    description = "CALL when Supertrend is bullish and ADX > ${params.adxThreshold.toInt()}.",
                    conditions = listOf(
                        StrategyCondition("d1", "Close", ConditionOperator.ABOVE, "Supertrend"),
                        StrategyCondition("d2", "ADX", ConditionOperator.ABOVE, "${params.adxThreshold.toInt()}")
                    ),
                    action = SignalDirection.CALL,
                    expiryMinutes = 5,
                    isPrebuilt = true,
                    winRateEstimate = 69.1
                ),
                TradingStrategy(
                    id = "strat_supertrend_adx_put",
                    name = "Strategy D: Supertrend + ADX (PUT)",
                    description = "PUT when Supertrend is bearish and ADX > ${params.adxThreshold.toInt()}.",
                    conditions = listOf(
                        StrategyCondition("d3", "Close", ConditionOperator.BELOW, "Supertrend"),
                        StrategyCondition("d4", "ADX", ConditionOperator.ABOVE, "${params.adxThreshold.toInt()}")
                    ),
                    action = SignalDirection.PUT,
                    expiryMinutes = 5,
                    isPrebuilt = true,
                    winRateEstimate = 67.7
                )
            )
        }
    }
}

