package com.example.data.repository

import com.example.data.engine.BacktestEngine
import com.example.data.engine.HistoricalDataEngine
import com.example.data.engine.StrategyEngine
import com.example.data.engine.TechnicalIndicators
import com.example.data.model.Asset
import com.example.data.model.BacktestConfig
import com.example.data.model.BacktestResult
import com.example.data.model.Candle
import com.example.data.model.IndicatorParameters
import com.example.data.model.PaperTrade
import com.example.data.model.PaperTradeStatus
import com.example.data.model.SignalDirection
import com.example.data.model.SignalItem
import com.example.data.model.SignalStatus
import com.example.data.model.Timeframe
import com.example.data.model.TradingStrategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Data Source Interface for Historical OHLCV Candles.
 * Allows seamless switching between Demo Data generation and future live exchange/broker APIs.
 */
interface HistoricalDataSource {
    fun fetchCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle>
    fun isDemoData(): Boolean
}

class DeterministicDemoHistoricalDataSource : HistoricalDataSource {
    override fun fetchCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle> {
        return HistoricalDataEngine.generateCandles(asset, timeframe, count)
    }

    override fun isDemoData(): Boolean = true
}

/**
 * Clean Trading Repository Interface for SignalLab.
 */
interface ITradingRepository {
    val virtualBalance: StateFlow<Double>
    val paperTrades: StateFlow<List<PaperTrade>>
    val strategies: StateFlow<List<TradingStrategy>>
    val signals: StateFlow<List<SignalItem>>
    val indicatorParams: StateFlow<IndicatorParameters>

    fun getCurrentPrice(asset: Asset): Double
    fun updateAssetPrice(asset: Asset, newPrice: Double)
    fun resetVirtualBalance(newBalance: Double)
    fun addVirtualFunds(amount: Double)
    fun placePaperTrade(asset: Asset, direction: SignalDirection, stake: Double, expiryMinutes: Int, payoutPercentage: Double): Boolean
    fun tickActiveTrades()
    fun saveStrategy(strategy: TradingStrategy)
    fun deleteStrategy(strategyId: String)
    fun updateIndicatorParameters(params: IndicatorParameters)
    fun resetIndicatorParameters()
    fun generateCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle>
    fun runBacktest(config: BacktestConfig): BacktestResult
}

class TradingRepository(
    private val historicalDataSource: HistoricalDataSource = DeterministicDemoHistoricalDataSource()
) : ITradingRepository {

    private val _virtualBalance = MutableStateFlow(10000.0)
    override val virtualBalance: StateFlow<Double> = _virtualBalance.asStateFlow()

    private val _paperTrades = MutableStateFlow<List<PaperTrade>>(emptyList())
    override val paperTrades: StateFlow<List<PaperTrade>> = _paperTrades.asStateFlow()

    private val _indicatorParams = MutableStateFlow(IndicatorParameters())
    override val indicatorParams: StateFlow<IndicatorParameters> = _indicatorParams.asStateFlow()

    private val _strategies = MutableStateFlow<List<TradingStrategy>>(
        StrategyEngine.getPrebuiltStrategies(_indicatorParams.value)
    )
    override val strategies: StateFlow<List<TradingStrategy>> = _strategies.asStateFlow()

    private val _signals = MutableStateFlow<List<SignalItem>>(generateDynamicSignals())
    override val signals: StateFlow<List<SignalItem>> = _signals.asStateFlow()

    // Live asset prices cache
    private val assetPrices = mutableMapOf(
        Asset.EUR_USD to Asset.EUR_USD.basePrice,
        Asset.GBP_USD to Asset.GBP_USD.basePrice,
        Asset.USD_JPY to Asset.USD_JPY.basePrice,
        Asset.BTC_USD to Asset.BTC_USD.basePrice
    )

    override fun getCurrentPrice(asset: Asset): Double {
        return assetPrices[asset] ?: asset.basePrice
    }

    override fun updateAssetPrice(asset: Asset, newPrice: Double) {
        assetPrices[asset] = newPrice
    }

    override fun resetVirtualBalance(newBalance: Double) {
        _virtualBalance.value = newBalance
        _paperTrades.value = emptyList()
    }

    override fun addVirtualFunds(amount: Double) {
        _virtualBalance.value += amount
    }

    override fun placePaperTrade(
        asset: Asset,
        direction: SignalDirection,
        stake: Double,
        expiryMinutes: Int,
        payoutPercentage: Double
    ): Boolean {
        if (_virtualBalance.value < stake) return false

        _virtualBalance.value -= stake
        val currentPrice = getCurrentPrice(asset)
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val newTrade = PaperTrade(
            id = UUID.randomUUID().toString().take(8),
            asset = asset,
            direction = direction,
            entryPrice = currentPrice,
            stake = stake,
            payoutPercentage = payoutPercentage,
            expiryMinutes = expiryMinutes,
            remainingSeconds = expiryMinutes * 60,
            totalSeconds = expiryMinutes * 60,
            startTimeFormatted = timeFormat.format(Date()),
            status = PaperTradeStatus.ACTIVE
        )

        _paperTrades.value = listOf(newTrade) + _paperTrades.value
        return true
    }

    override fun tickActiveTrades() {
        val currentList = _paperTrades.value.toMutableList()
        var updated = false
        var balanceDelta = 0.0

        for (i in currentList.indices) {
            val trade = currentList[i]
            if (trade.status == PaperTradeStatus.ACTIVE) {
                val newRemaining = trade.remainingSeconds - 1
                if (newRemaining <= 0) {
                    // Settle trade at expiry
                    val currentPrice = getCurrentPrice(trade.asset)
                    val priceDelta = currentPrice - trade.entryPrice
                    val won = if (trade.direction == SignalDirection.CALL) {
                        priceDelta > 0.000001
                    } else {
                        priceDelta < -0.000001
                    }

                    val finalStatus = if (won) PaperTradeStatus.WON else PaperTradeStatus.LOST
                    val pnl = if (won) {
                        trade.stake * (trade.payoutPercentage / 100.0)
                    } else {
                        -trade.stake
                    }

                    if (won) {
                        balanceDelta += trade.stake + pnl
                    }

                    currentList[i] = trade.copy(
                        remainingSeconds = 0,
                        status = finalStatus,
                        exitPrice = currentPrice,
                        pnl = pnl
                    )
                    updated = true
                } else {
                    currentList[i] = trade.copy(remainingSeconds = newRemaining)
                    updated = true
                }
            }
        }

        if (updated) {
            _paperTrades.value = currentList
            if (balanceDelta > 0) {
                _virtualBalance.value += balanceDelta
            }
        }
    }

    override fun updateIndicatorParameters(params: IndicatorParameters) {
        _indicatorParams.value = params
        // Refresh prebuilt strategies with new parameter values
        val customStrategies = _strategies.value.filter { !it.isPrebuilt }
        val updatedPrebuilt = StrategyEngine.getPrebuiltStrategies(params)
        _strategies.value = updatedPrebuilt + customStrategies
        _signals.value = generateDynamicSignals()
    }

    override fun resetIndicatorParameters() {
        updateIndicatorParameters(IndicatorParameters())
    }

    override fun saveStrategy(strategy: TradingStrategy) {
        val current = _strategies.value.toMutableList()
        val index = current.indexOfFirst { it.id == strategy.id }
        if (index >= 0) {
            current[index] = strategy
        } else {
            current.add(0, strategy)
        }
        _strategies.value = current
    }

    override fun deleteStrategy(strategyId: String) {
        _strategies.value = _strategies.value.filter { it.id != strategyId }
    }

    override fun generateCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle> {
        val candles = historicalDataSource.fetchCandles(asset, timeframe, count)
        candles.lastOrNull()?.let { updateAssetPrice(asset, it.close) }
        return candles
    }

    override fun runBacktest(config: BacktestConfig): BacktestResult {
        val strategy = _strategies.value.find { it.id == config.strategyId }
            ?: _strategies.value.first()
        return BacktestEngine.executeBacktest(config, strategy)
    }

    // Generate dynamic technical signals based on live indicator calculations across all assets
    fun generateDynamicSignals(): List<SignalItem> {
        val signalsList = mutableListOf<SignalItem>()
        val params = _indicatorParams.value

        Asset.values().forEachIndexed { index, asset ->
            val candles = historicalDataSource.fetchCandles(asset, Timeframe.M5, 60)
            if (candles.size >= 30) {
                val lastIdx = candles.size - 1
                val rsi = TechnicalIndicators.calculateRSI(candles, params.rsiPeriod).getOrNull(lastIdx) ?: 50.0
                val emaFast = TechnicalIndicators.calculateEMA(candles, params.emaFastPeriod).getOrNull(lastIdx) ?: 0.0
                val emaSlow = TechnicalIndicators.calculateEMA(candles, params.emaSlowPeriod).getOrNull(lastIdx) ?: 0.0
                val macd = TechnicalIndicators.calculateMACD(candles, params.macdFast, params.macdSlow, params.macdSignal)
                val supertrend = TechnicalIndicators.calculateSupertrend(candles, params.supertrendPeriod, params.supertrendMultiplier)
                val isBullishSt = supertrend.isBullish.getOrNull(lastIdx) == true

                val isCall = (emaFast > emaSlow && rsi > params.rsiMidline) || isBullishSt
                val direction = if (isCall) SignalDirection.CALL else SignalDirection.PUT
                val conditions = mutableListOf<String>()

                if (emaFast > emaSlow) {
                    conditions.add("EMA ${params.emaFastPeriod} (${"%.4f".format(emaFast)}) > EMA ${params.emaSlowPeriod}")
                } else {
                    conditions.add("EMA ${params.emaFastPeriod} (${"%.4f".format(emaFast)}) < EMA ${params.emaSlowPeriod}")
                }

                conditions.add("RSI ${params.rsiPeriod} @ ${"%.1f".format(rsi)} (${if (rsi > params.rsiMidline) "Bullish Momentum" else "Bearish Drift"})")

                if (isBullishSt) {
                    conditions.add("Supertrend Bullish Support (Multiplier ${params.supertrendMultiplier})")
                } else {
                    conditions.add("Supertrend Bearish Resistance (Multiplier ${params.supertrendMultiplier})")
                }

                if ((macd.histogram.getOrNull(lastIdx) ?: 0.0) > 0) {
                    conditions.add("MACD Histogram expanding positive")
                } else {
                    conditions.add("MACD Histogram below zero line")
                }

                val score = 70 + (rsi.toInt() % 25)
                val sampleCount = 200 + (index * 65)
                val winRate = 64.0 + ((score * 17) % 130) / 10.0

                signalsList.add(
                    SignalItem(
                        id = "sig_${asset.name.lowercase()}",
                        asset = asset,
                        direction = direction,
                        expiryMinutes = if (index % 2 == 0) 5 else 3,
                        score = score.coerceIn(60, 95),
                        conditions = conditions,
                        sampleCount = sampleCount,
                        historicalWinRate = winRate,
                        timestampFormatted = "${index * 3 + 1} mins ago",
                        currentPrice = candles.last().close,
                        status = SignalStatus.ACTIVE
                    )
                )
            }
        }

        return signalsList
    }
}

