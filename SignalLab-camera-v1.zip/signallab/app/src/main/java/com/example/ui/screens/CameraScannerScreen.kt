package com.example.ui.screens

import android.annotation.SuppressLint
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.*
import java.util.concurrent.Executors
import kotlin.math.max

private data class CandleBox(val left: Float, val top: Float, val right: Float, val bottom: Float, val bullish: Boolean)

private class ChartFrameAnalyzer(private val onResult: (List<CandleBox>, Int, Float) -> Unit) : ImageAnalysis.Analyzer {
  override fun analyze(image: androidx.camera.core.ImageProxy) {
    try {
      val plane = image.planes.firstOrNull() ?: return
      val buffer = plane.buffer
      val w = image.width
      val h = image.height
      if (w < 200 || h < 150) return
      // Fast V1 detector: search the central chart ROI for saturated red/green candle pixels.
      // This intentionally avoids claiming OHLC accuracy; it only produces visual candidates.
      val stepX = max(2, w / 480)
      val stepY = max(2, h / 360)
      val columns = BooleanArray(w / stepX + 1)
      val bullish = BooleanArray(columns.size)
      val rgb = ByteArray(3)
      val yRow = (h * 0.10).toInt()..(h * 0.90).toInt()
      var qualitySamples = 0
      var qualityGood = 0
      for (y in yRow step stepY) {
        for (x in (w * 0.05).toInt() until (w * 0.95).toInt() step stepX) {
          // ImageProxy YUV planes are not trivial to sample correctly across devices.
          // V1 therefore uses the Y plane for structure/quality and reserves colour extraction
          // for a later YUV->RGB optimized analyzer.
          val row = y * plane.rowStride
          val idx = row + x * plane.pixelStride
          if (idx < buffer.limit()) {
            val lum = buffer.get(idx).toInt() and 0xff
            qualitySamples++
            if (lum in 35..245) qualityGood++
            if (lum > 0) columns[(x / stepX).coerceIn(columns.indices)] = true
          }
        }
      }
      // Convert contiguous high-information columns into candidate candle regions.
      val boxes = mutableListOf<CandleBox>()
      var start = -1
      for (i in columns.indices) {
        if (columns[i] && start < 0) start = i
        val end = !columns[i] || i == columns.lastIndex
        if (end && start >= 0) {
          val len = i - start
          if (len in 2..max(12, columns.size / 20)) {
            val l = start.toFloat() / columns.size
            val r = i.toFloat() / columns.size
            boxes += CandleBox(l, 0.18f, r, 0.82f, bullish.getOrElse(start){true})
          }
          start = -1
        }
      }
      val q = if (qualitySamples == 0) 0f else qualityGood.toFloat() / qualitySamples
      onResult(boxes.takeLast(80), boxes.size, q)
    } finally { image.close() }
  }
}

@SuppressLint("UnsafeOptInUsageError")
@Composable
fun CameraScannerScreen(modifier: Modifier = Modifier) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val previewView = remember { PreviewView(context) }
  val executor = remember { Executors.newSingleThreadExecutor() }
  var boxes by remember { mutableStateOf(emptyList<CandleBox>()) }
  var count by remember { mutableIntStateOf(0) }
  var quality by remember { mutableFloatStateOf(0f) }

  DisposableEffect(Unit) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
    cameraProviderFuture.addListener({
      val provider = cameraProviderFuture.get()
      val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
      val analysis = ImageAnalysis.Builder()
        .setTargetResolution(Size(1280, 720))
        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        .build()
        .also { it.setAnalyzer(executor, ChartFrameAnalyzer { b, c, q ->
          boxes = b; count = c; quality = q
        }) }
      try {
        provider.unbindAll()
        provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
      } catch (_: Exception) { }
    }, ContextCompat.getMainExecutor(context))
    onDispose { executor.shutdown() }
  }

  Box(modifier.fillMaxSize().background(TerminalBg)) {
    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
    Box(modifier = Modifier.fillMaxSize().padding(18.dp)) {
      Column(modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)) {
        Card(colors = CardDefaults.cardColors(containerColor = TerminalBlack.copy(alpha = .88f)), shape = RoundedCornerShape(12.dp)) {
          Column(Modifier.padding(14.dp)) {
            Text("CAMERA SCANNER V1", color = TerminalCyan, style = MaterialTheme.typography.titleMedium)
            Text("Point the rear camera at the chart. V1 only detects visual candidates; it does not generate trades.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text("CHART REGION: CENTRAL AREA", color = TextPrimary, style = MaterialTheme.typography.labelMedium)
            Text("CANDIDATE COLUMNS: $count    FRAME QUALITY: ${(quality * 100).toInt()}%", color = if (quality > .55f) NeonGreen else TerminalAmber, style = MaterialTheme.typography.labelMedium)
          }
        }
      }
      Box(Modifier.fillMaxWidth(.9f).fillMaxHeight(.64f).align(Alignment.Center).border(2.dp, TerminalCyan, RoundedCornerShape(8.dp)))
      Text("CALIBRATION AREA", color = TerminalCyan, modifier = Modifier.align(Alignment.Center).background(TerminalBlack.copy(alpha=.55f)).padding(6.dp))
      Card(colors = CardDefaults.cardColors(containerColor = TerminalBlack.copy(alpha=.9f)), modifier = Modifier.align(Alignment.BottomCenter)) {
        Text("V1 TEST: verify the detection overlay before adding OHLC or signals.", color = TextSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp))
      }
    }
  }
}
