package com.example.data.engine

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.model.Asset
import java.util.Locale
import java.util.regex.Pattern

/**
 * Read-only terminal bridge. It watches the visible accessibility tree of the
 * Olymp Trade web terminal and forwards quote text to TerminalBridgeFeed.
 *
 * This service deliberately contains no click/gesture/order functionality.
 * It cannot place a trade; it only observes visible quote information.
 */
class OlympTradeAccessibilityService : AccessibilityService() {
    companion object {
        val feed: TerminalBridgeFeed = TerminalBridgeFeed()
        private val pricePattern = Pattern.compile("(?<!\\d)(\\d{2,8}\\.\\d{2,8})(?!\\d)")

        fun assetFromText(text: String): Asset? {
            val t = text.uppercase(Locale.US)
            return when {
                "CRYPTO COMPOSITE" in t || "CRYPTO_X" in t -> Asset.CRYPTO_COMPOSITE
                "ASIA COMPOSITE" in t || "ASIA_X" in t -> Asset.ASIA_COMPOSITE
                "EUROPE COMPOSITE" in t || "EUROPE_X" in t -> Asset.EUROPE_COMPOSITE
                "COMPOUND INDEX" in t || "COMPOUND_X" in t -> Asset.COMPOUND_INDEX
                else -> null
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        feed.connect()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return
        val texts = ArrayList<String>(128)
        collectText(root, texts)
        val joined = texts.joinToString(" | ")
        val asset = assetFromText(joined) ?: return
        val price = extractCandidatePrice(texts, asset) ?: return
        feed.submitTick(LiveTick(asset, System.currentTimeMillis(), price, "Olymp Trade accessibility feed"))
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectText(child, out)
                child.recycle()
            }
        }
    }

    private fun extractCandidatePrice(texts: List<String>, asset: Asset): Double? {
        val candidates = mutableListOf<Double>()
        for (text in texts) {
            val matcher = pricePattern.matcher(text.replace(",", ""))
            while (matcher.find()) {
                val value = matcher.group(1).toDoubleOrNull() ?: continue
                if (value in 0.00001..100_000_000.0) candidates += value
            }
        }
        // Prefer values close to the known instrument scale. This prevents an
        // account balance or percentage from becoming the quote.
        return candidates.minByOrNull { kotlin.math.abs(it - asset.basePrice) }
    }

    override fun onInterrupt() {
        feed.disconnect()
    }
}
