package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.RectF
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size as ComposeSize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.*
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Camera Scanner V2
 *
 * Purpose:
 * - Read a chart displayed on another screen through the phone camera.
 * - Detect likely green/red candle pixels in a chart ROI.
 * - Track candidate candle columns and show a verification overlay.
 *
 * Important: V2 deliberately does NOT manufacture OHLC values or trading signals.
 * It is a vision calibration layer. False positives are expected until the chart
 * geometry, colors and device rotation are stable.
 */
private data class CandleCandidate(
  val left: Float,
  val top: Float,
  val right: Float,
  val bottom: Float,
  val bullish: Boolean,
  val confidence: Float
)

private data class ScanResult(
  val candles: List<CandleCandidate>,
  val coloredPixels: Int,
  val quality: Float,
  val rotation: Int
)

private class ChartFrameAnalyzer(
  private val onResult: (ScanResult) -> Unit
) : ImageAnalysis.Analyzer {

  override fun analyze(image: ImageProxy) {
    try {
      val result = analyzeFrame(image)
      onResult(result)
    } finally {
      image.close()
    }
  }

  private fun analyzeFrame(image: ImageProxy): ScanResult {
    val width = image.width
    val height = image.height
    if (width < 200 || height < 150) {
      return ScanResult(emptyList(), 0, 0f, image.imageInfo.rotationDegrees)
    }

    // Keep the same broad central region shown by the UI calibration box.
    val x0 = (width * 0.06f).toInt()
    val x1 = (width * 0.94f).toInt()
    val y0 = (height * 0.12f).toInt()
    val y1 = (height * 0.82f).toInt()

    val step = max(2, min(width, height) / 360)
    val bins = BooleanArray(((x1 - x0) / step) + 1)
    val green = IntArray(bins.size)
    val red = IntArray(bins.size)
    val top = IntArray(bins.size) { height }
    val bottom = IntArray(bins.size) { -1 }

    var samples = 0
    var validSamples = 0
    var colored = 0

    for (y in y0 until y1 step step) {
      for (x in x0 until x1 step step) {
        samples++
        val rgb = readRgb(image, x, y) ?: continue
        validSamples++

        val r = rgb[0]
        val g = rgb[1]
        val b = rgb[2]
        val maxC = max(r, max(g, b))
        val minC = min(r, min(g, b))
        val spread = maxC - minC

        // Screen charts commonly use saturated green/red candle bodies/wicks.
        // Require both saturation and channel dominance so grid/text is ignored.
        val isGreen = g > 105 && g > r * 1.22f && g > b * 1.12f && spread > 35
        val isRed = r > 105 && r > g * 1.22f && r > b * 1.12f && spread > 35

        if (!isGreen && !isRed) continue

        colored++
        val bin = ((x - x0) / step).coerceIn(bins.indices)
        bins[bin] = true
        if (isGreen) green[bin]++ else red[bin]++
        top[bin] = min(top[bin], y)
        bottom[bin] = max(bottom[bin], y)
      }
    }

    // Fill tiny gaps caused by anti-aliasing / camera noise.
    val bridged = bins.copyOf()
    for (i in 1 until bins.lastIndex) {
      if (!bins[i] && bins[i - 1] && bins[i + 1]) bridged[i] = true
    }

    val candidates = mutableListOf<CandleCandidate>()
    var start = -1

    fun emit(endExclusive: Int) {
      if (start < 0) return
      val end = endExclusive - 1
      val widthBins = end - start + 1
      val pixelCount = green.slice(start..end).sum() + red.slice(start..end).sum()

      // A single candle should be relatively narrow. Long runs are more likely
      // to be moving-average lines or chart decorations.
      if (widthBins in 1..max(10, bins.size / 45) && pixelCount >= 2) {
        var t = height
        var bot = -1
        var g = 0
        var r = 0
        for (i in start..end) {
          t = min(t, top[i])
          bot = max(bot, bottom[i])
          g += green[i]
          r += red[i]
        }

        if (bot > t) {
          val total = (g + r).coerceAtLeast(1)
          val confidence = (pixelCount / 18f).coerceIn(0f, 1f) *
            (1f - (min(g, r).toFloat() / total) * 0.45f)

          candidates += CandleCandidate(
            left = ((x0 + start * step).toFloat() / width).coerceIn(0f, 1f),
            top = (t.toFloat() / height).coerceIn(0f, 1f),
            right = ((x0 + (end + 1) * step).toFloat() / width).coerceIn(0f, 1f),
            bottom = (bot.toFloat() / height).coerceIn(0f, 1f),
            bullish = g >= r,
            confidence = confidence
          )
        }
      }
      start = -1
    }

    for (i in bridged.indices) {
      if (bridged[i] && start < 0) start = i
      if ((!bridged[i] || i == bridged.lastIndex) && start >= 0) {
        emit(if (!bridged[i]) i else i + 1)
      }
    }

    // Frame quality measures whether the camera buffer could be sampled reliably;
    // it is intentionally separate from candle detection density.
    val quality = if (samples == 0) 0f
    else (validSamples.toFloat() / samples).coerceIn(0f, 1f)

    // CameraX may deliver a rotated analysis buffer. Keep the rotation in the
    // result so the overlay can map analyzer coordinates to the portrait preview.
    return ScanResult(
      candles = candidates.takeLast(100),
      coloredPixels = colored,
      quality = quality,
      rotation = image.imageInfo.rotationDegrees
    )
  }

  /**
   * Convert one YUV_420_888 sample to RGB while respecting row/pixel strides.
   * This is intentionally sampled sparsely for real-time phone performance.
   */
  private fun readRgb(image: ImageProxy, x: Int, y: Int): IntArray? {
    val planes = image.planes
    if (planes.size < 3) return null

    val yPlane = planes[0]
    val uPlane = planes[1]
    val vPlane = planes[2]

    val yi = y * yPlane.rowStride + x * yPlane.pixelStride
    val ux = x / 2
    val uy = y / 2
    val ui = uy * uPlane.rowStride + ux * uPlane.pixelStride
    val vi = uy * vPlane.rowStride + ux * vPlane.pixelStride

    if (yi >= yPlane.buffer.limit() || ui >= uPlane.buffer.limit() || vi >= vPlane.buffer.limit()) {
      return null
    }

    val yy = (yPlane.buffer.get(yi).toInt() and 0xff).toFloat()
    val u = (uPlane.buffer.get(ui).toInt() and 0xff).toFloat() - 128f
    val v = (vPlane.buffer.get(vi).toInt() and 0xff).toFloat() - 128f

    val r = (yy + 1.402f * v).coerceIn(0f, 255f).toInt()
    val g = (yy - 0.344136f * u - 0.714136f * v).coerceIn(0f, 255f).toInt()
    val b = (yy + 1.772f * u).coerceIn(0f, 255f).toInt()

    return intArrayOf(r, g, b)
  }
}

private fun mapToPreview(
  left: Float, top: Float, right: Float, bottom: Float, rotation: Int
): RectF {
  // Analyzer coordinates are normalized to the camera buffer. PreviewView is
  // portrait on the phone, so rotate normalized coordinates for 90/270 degree data.
  return when ((rotation % 360 + 360) % 360) {
    90 -> RectF(1f - bottom, left, 1f - top, right)
    270 -> RectF(top, 1f - right, bottom, 1f - left)
    180 -> RectF(1f - right, 1f - bottom, 1f - left, 1f - top)
    else -> RectF(left, top, right, bottom)
  }
}

@SuppressLint("UnsafeOptInUsageError")
@Composable
fun CameraScannerScreen(modifier: Modifier = Modifier) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val previewView = remember { PreviewView(context) }
  val executor = remember { Executors.newSingleThreadExecutor() }

  var candidates by remember { mutableStateOf(emptyList<CandleCandidate>()) }
  var quality by remember { mutableFloatStateOf(0f) }
  var rotation by remember { mutableIntStateOf(0) }

  DisposableEffect(Unit) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
    cameraProviderFuture.addListener({
      val provider = cameraProviderFuture.get()
      val preview = Preview.Builder()
        .build()
        .also { it.surfaceProvider = previewView.surfaceProvider }

      val analysis = ImageAnalysis.Builder()
        .setTargetResolution(Size(1280, 720))
        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        .build()
        .also {
          it.setAnalyzer(executor, ChartFrameAnalyzer { result ->
            candidates = result.candles
            quality = result.quality
            rotation = result.rotation
          })
        }

      try {
        provider.unbindAll()
        provider.bindToLifecycle(
          lifecycleOwner,
          CameraSelector.DEFAULT_BACK_CAMERA,
          preview,
          analysis
        )
      } catch (_: Exception) {
        // Camera errors are surfaced by the lack of scan results; the app remains usable.
      }
    }, ContextCompat.getMainExecutor(context))

    onDispose {
      executor.shutdown()
      runCatching { previewView.release() }
    }
  }

  Box(modifier.fillMaxSize().background(TerminalBg)) {
    AndroidView(
      factory = { previewView },
      modifier = Modifier.fillMaxSize()
    )

    // Visual verification overlay. This is deliberately independent from the
    // trading engine so we can validate vision before creating OHLC/signals.
    Canvas(Modifier.fillMaxSize()) {
      candidates.forEach { c ->
        val r = mapToPreview(c.left, c.top, c.right, c.bottom, rotation)
        val left = r.left * size.width
        val top = r.top * size.height
        val right = r.right * size.width
        val bottom = r.bottom * size.height

        drawRect(
          color = if (c.bullish) NeonGreen else NeonRed,
          topLeft = Offset(left, top),
          size = ComposeSize(
            (right - left).coerceAtLeast(2f),
            (bottom - top).coerceAtLeast(2f)
          ),
          style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
        )
      }
    }

    Box(modifier = Modifier.fillMaxSize().padding(18.dp)) {
      Column(modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)) {
        Card(
          colors = CardDefaults.cardColors(containerColor = TerminalBlack.copy(alpha = .90f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(Modifier.padding(14.dp)) {
            Text("CAMERA SCANNER V2", color = TerminalCyan, style = MaterialTheme.typography.titleMedium)
            Text(
              "Point the rear camera at the chart. V2 detects likely candle pixels and draws a verification box around them.",
              color = TextSecondary,
              style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Text("CHART REGION: CENTRAL AREA", color = TextPrimary, style = MaterialTheme.typography.labelMedium)
            Text(
              "CANDLES: ${candidates.size}    FRAME QUALITY: ${(quality * 100).toInt()}%    ROTATION: ${rotation}°",
              color = if (quality > .55f) NeonGreen else TerminalAmber,
              style = MaterialTheme.typography.labelMedium
            )
          }
        }
      }

      Box(
        Modifier
          .fillMaxWidth(.90f)
          .fillMaxHeight(.64f)
          .align(Alignment.Center)
          .border(2.dp, TerminalCyan, RoundedCornerShape(8.dp))
      )

      Text(
        "CAMERA CALIBRATION AREA",
        color = TerminalCyan,
        modifier = Modifier
          .align(Alignment.Center)
          .background(TerminalBlack.copy(alpha = .55f))
          .padding(6.dp)
      )

      Card(
        colors = CardDefaults.cardColors(containerColor = TerminalBlack.copy(alpha = .90f)),
        modifier = Modifier.align(Alignment.BottomCenter)
      ) {
        Text(
          "V2 TEST: green/red boxes = detected candle candidates. OHLC and signals come later.",
          color = TextSecondary,
          style = MaterialTheme.typography.bodySmall,
          modifier = Modifier.padding(12.dp)
        )
      }
    }
  }
}
