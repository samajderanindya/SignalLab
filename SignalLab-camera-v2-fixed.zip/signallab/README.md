<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/51044001-bae5-4827-97d0-f61e221a7a6c

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Fast-market / Olymp Trade terminal bridge

This build adds the requested fast-market model:

- Composite assets: `ASIA_X`, `CRYPTO_X`, `EUROPE_X`, `COMPOUND_X`
- Chart intervals: `5s`, `15s`, `30s`
- Signal expiries: `15s`, `30s`, `45s`
- A read-only `OlympTradeAccessibilityService` and `TerminalBridgeFeed` are included.

### Important

Olymp Trade's own legal documentation states that the reliable quote source is its server/Trading Terminal, and that the displayed Asset Rate is determined by the company. Therefore the app must not substitute Binance/forex/exchange prices for a Composite Index quote. See the official policy: https://olymptrade.com/pages/about/legal/trading-transactions-policy-part-two/

To connect live quotes on Android, enable **SignalLab Olymp Trade Feed** under Android Accessibility settings, open the Olymp Trade web terminal in Chrome, select one of the supported Composite Indexes, and keep the terminal visible. The bridge is read-only: it does not click Up/Down or place orders.

Until the accessibility tree actually supplies a quote, SignalLab continues to mark generated data as DEMO and will not claim a verified live feed.

## Phone-only build path

A computer is not required. The project includes a GitHub Actions workflow at `.github/workflows/android-build.yml` that builds a debug APK on a GitHub-hosted runner and uploads the APK as an artifact. The workflow does not require a Gemini API key for the basic build.


## Camera Scanner V2
The camera scanner uses sampled YUV-to-RGB analysis to detect likely red/green candle pixels from a chart displayed on another screen. V2 is a vision-calibration layer only: it does not infer OHLC or generate trading signals until detection is validated.
