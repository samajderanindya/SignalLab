# SignalLab — Fast Market Build

## Implemented

- Added composite-index assets:
  - ASIA_X — Asia Composite Index
  - CRYPTO_X — Crypto Composite Index
  - EUROPE_X — Europe Composite Index
  - COMPOUND_X — Compound Index
- Added chart timeframes: 5s, 15s, 30s.
- Added paper-trade expiries: 15s, 30s, 45s.
- Added causal fast-market signal scoring using EMA, RSI, MACD, Supertrend and ADX.
- Added rolling strategy ranking for EMA+RSI, MACD crossover, and Supertrend+ADX.
- Added a read-only Android Accessibility bridge for visible Olymp Trade quote text.
- Added a terminal tick store and live-candle aggregator.
- Added hybrid data routing: use terminal-feed candles when enough verified terminal ticks are available; otherwise remain on clearly labelled demo data.
- Removed fabricated historical win-rate claims when no sample exists; rolling sample metrics are explicitly labelled.

## Important limitation

The build does not reverse engineer or hard-code a private Olymp Trade WebSocket/API endpoint. Olymp Trade's official policy says the company's server/Trading Terminal is the reliable quote source. The included Android accessibility bridge is therefore deliberately read-only and does not place orders.

The app will not claim a verified live feed until the accessibility bridge actually receives quote text from the terminal.

## Android setup for live quote observation

1. Install the debug APK from Android Studio.
2. Android Settings → Accessibility → Installed/Downloaded apps.
3. Enable `SignalLab Olymp Trade Feed`.
4. Open Olymp Trade in Chrome and select a supported Composite Index.
5. Keep the terminal visible while collecting ticks.
6. SignalLab will use those terminal quotes once enough ticks have arrived to form candles.

No Up/Down button is automated by this bridge.
