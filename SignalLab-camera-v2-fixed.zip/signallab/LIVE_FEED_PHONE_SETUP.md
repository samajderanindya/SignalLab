# SignalLab — Live Olymp Trade Feed (Phone Only)

This version does **not** generate fake candles in the Markets screen. It builds OHLC candles only from quotes observed from the visible Olymp Trade terminal through Android Accessibility.

## On the phone

1. Install the new SignalLab APK.
2. Open **SignalLab → Settings → OPEN ACCESSIBILITY SETTINGS**.
3. Enable **SignalLab Olymp Trade Feed**.
4. Open Olymp Trade and keep the instrument you want visible.
5. In SignalLab, select the same instrument and timeframe.
6. Leave Olymp Trade visible long enough for ticks to accumulate. The 5s chart will build one candle for each 5-second bucket.

## Important limitation

The accessibility bridge can observe the quote currently exposed by the terminal, but it cannot recover old candle history from an inaccessible chart canvas. Therefore, the chart starts empty/partial and builds real candles as quotes are observed. This is intentional: the app no longer mixes simulated history with live quotes.

For Olymp Trade OTC/composite instruments, only the terminal's own visible quote can be used if exact platform matching is required. A generic BTC/USD or forex API will not necessarily produce the same candles.
