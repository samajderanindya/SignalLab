package com.example

import android.content.Context
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Asset
import com.example.data.model.BacktestConfig
import com.example.data.model.Timeframe
import com.example.ui.viewmodel.SignalLabViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SignalLab", appName)
    }

    @Test
    fun `launch main activity`() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                assertNotNull(activity)
            }
        }
    }

    @Test
    fun `test ViewModel parameter changes and deterministic backtest flow`() {
        val viewModel = SignalLabViewModel()

        // 1. Parameter update should not block and should update state immediately
        val newConfig = BacktestConfig(
            asset = Asset.GBP_USD,
            timeframe = Timeframe.M15,
            startingBalance = 10000.0,
            stakeAmount = 500.0
        )
        viewModel.updateBacktestConfig(newConfig)
        assertEquals(Asset.GBP_USD, viewModel.backtestConfig.value.asset)
        assertEquals(Timeframe.M15, viewModel.backtestConfig.value.timeframe)
        assertEquals(500.0, viewModel.backtestConfig.value.stakeAmount, 0.001)

        // 2. Run backtest manually
        viewModel.runBacktest()

        // 3. Update stake from 500 to 1000
        viewModel.updateBacktestConfig(newConfig.copy(stakeAmount = 1000.0))
        assertEquals(1000.0, viewModel.backtestConfig.value.stakeAmount, 0.001)
    }
}
