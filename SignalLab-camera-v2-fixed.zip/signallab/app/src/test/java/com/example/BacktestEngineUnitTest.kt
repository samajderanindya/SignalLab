package com.example

import com.example.data.engine.BacktestEngine
import com.example.data.engine.StrategyEngine
import com.example.data.engine.HistoricalDataEngine
import com.example.data.model.Asset
import com.example.data.model.BacktestConfig
import com.example.data.model.ExecutionRule
import com.example.data.model.IndicatorParameters
import com.example.data.model.Timeframe
import com.example.data.model.TradeOutcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BacktestEngineUnitTest {

    private val prebuiltStrategies = StrategyEngine.getPrebuiltStrategies(IndicatorParameters())
    private val strategyA = prebuiltStrategies.find { it.id == "strat_ema_rsi_call" } ?: prebuiltStrategies[0]
    private val strategyB = prebuiltStrategies.find { it.id == "strat_macd_ema_call" } ?: prebuiltStrategies[1]
    private val strategyC = prebuiltStrategies.find { it.id == "strat_bb_rsi_call" } ?: prebuiltStrategies[2]

    @Test
    fun testHistoricalRangeCountsMatchRequestedDuration() {
        val dayMs = 24L * 60L * 60L * 1000L
        val sevenDaysM5 = HistoricalDataEngine.getCandleCountForRange("Last 7 Days", Timeframe.M5)
        val thirtyDaysM5 = HistoricalDataEngine.getCandleCountForRange("Last 30 Days", Timeframe.M5)
        val ninetyDaysM1 = HistoricalDataEngine.getCandleCountForRange("Last 90 Days", Timeframe.M1)

        assertTrue(sevenDaysM5 >= (7L * dayMs / (5L * 60_000L)).toInt())
        assertTrue(thirtyDaysM5 >= (30L * dayMs / (5L * 60_000L)).toInt())
        assertTrue(ninetyDaysM1 >= (90L * dayMs / 60_000L).toInt())
    }


    @Test
    fun testPrebuiltStrategyIdsAreCurrent() {
        val ids = prebuiltStrategies.map { it.id }.toSet()
        assertTrue(ids.contains("strat_ema_rsi_call"))
        assertTrue(ids.contains("strat_ema_rsi_put"))
        assertTrue(ids.contains("strat_macd_ema_call"))
        assertTrue(ids.contains("strat_macd_ema_put"))
        assertTrue(ids.contains("strat_bb_rsi_call"))
        assertTrue(ids.contains("strat_bb_rsi_put"))
        assertTrue(ids.contains("strat_supertrend_adx_call"))
        assertTrue(ids.contains("strat_supertrend_adx_put"))
    }

    @Test
    fun testHistoricalWindowsShareTheSameRecentDemoHistory() {
        val endTime = 1_777_000_000_000L
        val thirtyDays = HistoricalDataEngine.generateCandles(
            Asset.EUR_USD, Timeframe.M5,
            HistoricalDataEngine.getCandleCountForRange("Last 30 Days", Timeframe.M5),
            endTime
        )
        val ninetyDays = HistoricalDataEngine.generateCandles(
            Asset.EUR_USD, Timeframe.M5,
            HistoricalDataEngine.getCandleCountForRange("Last 90 Days", Timeframe.M5),
            endTime
        )

        assertTrue(thirtyDays.isNotEmpty())
        assertTrue(ninetyDays.size > thirtyDays.size)
        val suffix = ninetyDays.takeLast(thirtyDays.size)
        assertEquals(thirtyDays, suffix)
    }
    @Test
    fun testTestCaseA_GbpUsd_15m_30mExpiry_StrategyB_NextOpen() {
        val config = BacktestConfig(
            asset = Asset.GBP_USD,
            timeframe = Timeframe.M15,
            expiryMinutes = 30,
            executionRule = ExecutionRule.NEXT_CANDLE_OPEN,
            strategyId = strategyB.id,
            startingBalance = 10000.0,
            stakeAmount = 100.0
        )

        val result = BacktestEngine.executeBacktest(config, strategyB)

        assertNotNull(result)
        assertTrue(result.validationPassed)
        assertEquals(10000.0, result.startingBalance, 0.001)
        assertEquals(result.startingBalance + result.netPnl, result.finalBalance, 0.001)
        assertEquals(result.wins + result.losses + result.draws, result.totalTrades)

        // Verify that trade ledger entries use strictly NEXT_CANDLE_OPEN
        result.trades.forEach { trade ->
            assertEquals(ExecutionRule.NEXT_CANDLE_OPEN, trade.executionRule)
            assertTrue(trade.entryTimestamp >= trade.signalTimestamp)
            assertTrue(trade.expiryTimestamp > trade.entryTimestamp)
            assertTrue(trade.stake == 100.0)
        }

        // Verify audit info
        assertTrue(result.auditInfo.candlesLoaded > 0)
        assertTrue(result.auditInfo.validIndicatorCandles > 0)
        assertTrue(result.auditInfo.lookaheadProtectionVerified)
    }

    @Test
    fun testTestCaseB_GbpUsd_1m_3mExpiry_StrategyA_NextOpen() {
        val config = BacktestConfig(
            asset = Asset.GBP_USD,
            timeframe = Timeframe.M1,
            expiryMinutes = 3,
            executionRule = ExecutionRule.NEXT_CANDLE_OPEN,
            strategyId = strategyA.id,
            startingBalance = 10000.0,
            stakeAmount = 500.0
        )

        val result = BacktestEngine.executeBacktest(config, strategyA)

        assertNotNull(result)
        assertTrue(result.validationPassed)
        assertEquals(result.wins + result.losses + result.draws, result.totalTrades)
        assertEquals(result.equityCurve.size, result.totalTrades + 1)
        assertEquals(result.equityCurve.first(), 10000.0, 0.001)
        assertEquals(result.equityCurve.last(), result.finalBalance, 0.001)
    }

    @Test
    fun testTestCaseC_UsdJpy_15m_30mExpiry_StrategyC_NextOpen() {
        val config = BacktestConfig(
            asset = Asset.USD_JPY,
            timeframe = Timeframe.M15,
            expiryMinutes = 30,
            executionRule = ExecutionRule.NEXT_CANDLE_OPEN,
            strategyId = strategyC.id,
            startingBalance = 10000.0,
            stakeAmount = 100.0
        )

        val result = BacktestEngine.executeBacktest(config, strategyC)

        assertNotNull(result)
        assertTrue(result.validationPassed)
        assertEquals(10000.0, result.startingBalance, 0.001)
        assertEquals(result.wins + result.losses + result.draws, result.totalTrades)
    }

    @Test
    fun testDeterministicExecutionRepeatability() {
        val config = BacktestConfig(
            asset = Asset.EUR_USD,
            timeframe = Timeframe.M5,
            expiryMinutes = 5,
            executionRule = ExecutionRule.NEXT_CANDLE_OPEN,
            startingBalance = 10000.0,
            stakeAmount = 500.0
        )

        val result1 = BacktestEngine.executeBacktest(config, strategyA)
        val result2 = BacktestEngine.executeBacktest(config, strategyA)

        // Exact determinism verification: same inputs must produce exact same outputs
        assertEquals(result1.totalTrades, result2.totalTrades)
        assertEquals(result1.wins, result2.wins)
        assertEquals(result1.losses, result2.losses)
        assertEquals(result1.draws, result2.draws)
        assertEquals(result1.netPnl, result2.netPnl, 0.0001)
        assertEquals(result1.winRate, result2.winRate, 0.0001)
        assertEquals(result1.maxDrawdownPercentage, result2.maxDrawdownPercentage, 0.0001)
    }

    @Test
    fun testExecutionRuleCandleCloseVsNextOpen() {
        val configNextOpen = BacktestConfig(
            asset = Asset.EUR_USD,
            executionRule = ExecutionRule.NEXT_CANDLE_OPEN,
            startingBalance = 10000.0,
            stakeAmount = 500.0
        )

        val configCandleClose = BacktestConfig(
            asset = Asset.EUR_USD,
            executionRule = ExecutionRule.SIGNAL_CANDLE_CLOSE,
            startingBalance = 10000.0,
            stakeAmount = 500.0
        )

        val resultNextOpen = BacktestEngine.executeBacktest(configNextOpen, strategyA)
        val resultCandleClose = BacktestEngine.executeBacktest(configCandleClose, strategyA)

        assertTrue(resultNextOpen.validationPassed)
        assertTrue(resultCandleClose.validationPassed)

        resultNextOpen.trades.forEach { trade ->
            assertEquals(ExecutionRule.NEXT_CANDLE_OPEN, trade.executionRule)
        }
        resultCandleClose.trades.forEach { trade ->
            assertEquals(ExecutionRule.SIGNAL_CANDLE_CLOSE, trade.executionRule)
        }
    }

    @Test
    fun testMathematicalReconciliationOfLedgerAndMetrics() {
        val config = BacktestConfig(
            asset = Asset.EUR_USD,
            startingBalance = 10000.0,
            stakeAmount = 500.0,
            payoutPercentage = 85.0
        )

        val result = BacktestEngine.executeBacktest(config, strategyA)

        if (result.totalTrades > 0) {
            val sumLedgerPnl = result.trades.sumOf { it.pnl }
            assertEquals(sumLedgerPnl, result.netPnl, 0.001)

            val calculatedEndingBalance = result.startingBalance + sumLedgerPnl
            assertEquals(calculatedEndingBalance, result.finalBalance, 0.001)

            val winningPnls = result.trades.filter { it.outcome == TradeOutcome.WIN }.sumOf { it.pnl }
            val losingPnls = result.trades.filter { it.outcome == TradeOutcome.LOSS }.sumOf { abs(it.pnl) }

            assertEquals(winningPnls, result.grossProfit, 0.001)
            assertEquals(losingPnls, result.grossLoss, 0.001)
            assertEquals(winningPnls - losingPnls, result.netPnl, 0.001)

            // Win rate check excluding draws
            val decisionalTrades = result.wins + result.losses
            val expectedWinRate = if (decisionalTrades > 0) (result.wins.toDouble() / decisionalTrades) * 100.0 else 0.0
            assertEquals(expectedWinRate, result.winRate, 0.001)
        }
    }
}
