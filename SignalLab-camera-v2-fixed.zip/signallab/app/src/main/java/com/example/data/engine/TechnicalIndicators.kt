package com.example.data.engine

import com.example.data.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * High-performance technical indicators calculation engine.
 * Strictly calculates values based only on past and current candles (no lookahead bias).
 */
object TechnicalIndicators {

    data class MacdResult(
        val macdLine: List<Double>,
        val signalLine: List<Double>,
        val histogram: List<Double>
    )

    data class BollingerBandsResult(
        val upper: List<Double>,
        val middle: List<Double>,
        val lower: List<Double>
    )

    data class AdxResult(
        val adx: List<Double>,
        val plusDI: List<Double>,
        val minusDI: List<Double>
    )

    data class StochasticResult(
        val k: List<Double>,
        val d: List<Double>
    )

    data class SupertrendResult(
        val values: List<Double>,
        val isBullish: List<Boolean>
    )

    // 1. Exponential Moving Average (EMA)
    fun calculateEMA(candles: List<Candle>, period: Int): List<Double> {
        if (candles.isEmpty()) return emptyList()
        val p = max(1, period)
        val k = 2.0 / (p + 1)
        val result = ArrayList<Double>(candles.size)

        var ema = candles.first().close
        result.add(ema)

        for (i in 1 until candles.size) {
            ema = (candles[i].close * k) + (ema * (1.0 - k))
            result.add(ema)
        }
        return result
    }

    // Helper for EMA of a generic Double list
    private fun calculateEmaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val p = max(1, period)
        val k = 2.0 / (p + 1)
        val result = ArrayList<Double>(values.size)

        var ema = values.first()
        result.add(ema)

        for (i in 1 until values.size) {
            ema = (values[i] * k) + (ema * (1.0 - k))
            result.add(ema)
        }
        return result
    }

    // 2. Simple Moving Average (SMA)
    fun calculateSMA(candles: List<Candle>, period: Int): List<Double> {
        if (candles.isEmpty()) return emptyList()
        val p = max(1, period)
        val result = ArrayList<Double>(candles.size)

        var rollingSum = 0.0
        for (i in candles.indices) {
            rollingSum += candles[i].close
            if (i >= p) {
                rollingSum -= candles[i - p].close
            }
            val count = min(i + 1, p)
            result.add(rollingSum / count)
        }
        return result
    }

    // 3. Relative Strength Index (RSI) - Wilder's Smoothing
    fun calculateRSI(candles: List<Candle>, period: Int = 14): List<Double> {
        if (candles.isEmpty()) return emptyList()
        val p = max(1, period)
        val result = ArrayList<Double>(candles.size)

        if (candles.size == 1) {
            result.add(50.0)
            return result
        }

        var avgGain = 0.0
        var avgLoss = 0.0

        for (i in candles.indices) {
            if (i == 0) {
                result.add(50.0)
                continue
            }

            val change = candles[i].close - candles[i - 1].close
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) abs(change) else 0.0

            if (i <= p) {
                avgGain += gain
                avgLoss += loss
                if (i == p) {
                    avgGain /= p
                    avgLoss /= p
                    val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
                    val rsi = 100.0 - (100.0 / (1.0 + rs))
                    result.add(rsi.coerceIn(0.0, 100.0))
                } else {
                    result.add(50.0)
                }
            } else {
                avgGain = (avgGain * (p - 1) + gain) / p
                avgLoss = (avgLoss * (p - 1) + loss) / p
                val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
                val rsi = 100.0 - (100.0 / (1.0 + rs))
                result.add(rsi.coerceIn(0.0, 100.0))
            }
        }
        return result
    }

    // 4. Moving Average Convergence Divergence (MACD)
    fun calculateMACD(
        candles: List<Candle>,
        fastPeriod: Int = 12,
        slowPeriod: Int = 26,
        signalPeriod: Int = 9
    ): MacdResult {
        if (candles.isEmpty()) {
            return MacdResult(emptyList(), emptyList(), emptyList())
        }

        val fastEma = calculateEMA(candles, fastPeriod)
        val slowEma = calculateEMA(candles, slowPeriod)

        val macdLine = ArrayList<Double>(candles.size)
        for (i in candles.indices) {
            macdLine.add(fastEma[i] - slowEma[i])
        }

        val signalLine = calculateEmaSeries(macdLine, signalPeriod)
        val histogram = ArrayList<Double>(candles.size)
        for (i in candles.indices) {
            histogram.add(macdLine[i] - signalLine[i])
        }

        return MacdResult(macdLine, signalLine, histogram)
    }

    // 5. Bollinger Bands (BB)
    fun calculateBollingerBands(
        candles: List<Candle>,
        period: Int = 20,
        multiplier: Double = 2.0
    ): BollingerBandsResult {
        if (candles.isEmpty()) {
            return BollingerBandsResult(emptyList(), emptyList(), emptyList())
        }

        val p = max(1, period)
        val middle = calculateSMA(candles, p)
        val upper = ArrayList<Double>(candles.size)
        val lower = ArrayList<Double>(candles.size)

        for (i in candles.indices) {
            val start = max(0, i - p + 1)
            val sub = candles.subList(start, i + 1)
            val mean = middle[i]
            val variance = sub.map { (it.close - mean) * (it.close - mean) }.average()
            val stdDev = sqrt(variance)

            upper.add(mean + (multiplier * stdDev))
            lower.add(mean - (multiplier * stdDev))
        }

        return BollingerBandsResult(upper, middle, lower)
    }

    // 6. Average True Range (ATR)
    fun calculateATR(candles: List<Candle>, period: Int = 14): List<Double> {
        if (candles.isEmpty()) return emptyList()
        val p = max(1, period)
        val result = ArrayList<Double>(candles.size)

        val trList = ArrayList<Double>(candles.size)
        for (i in candles.indices) {
            if (i == 0) {
                trList.add(candles[0].high - candles[0].low)
            } else {
                val h = candles[i].high
                val l = candles[i].low
                val prevClose = candles[i - 1].close
                val tr = max(h - l, max(abs(h - prevClose), abs(l - prevClose)))
                trList.add(tr)
            }
        }

        var atr = 0.0
        for (i in trList.indices) {
            if (i < p) {
                atr += trList[i]
                if (i == p - 1) {
                    atr /= p
                    result.add(atr)
                } else {
                    result.add(trList[i])
                }
            } else {
                atr = (atr * (p - 1) + trList[i]) / p
                result.add(atr)
            }
        }
        return result
    }

    // 7. Average Directional Index (ADX)
    fun calculateADX(candles: List<Candle>, period: Int = 14): AdxResult {
        if (candles.isEmpty()) return AdxResult(emptyList(), emptyList(), emptyList())
        val p = max(1, period)
        val size = candles.size

        val plusDM = DoubleArray(size)
        val minusDM = DoubleArray(size)
        val tr = DoubleArray(size)

        for (i in 1 until size) {
            val upMove = candles[i].high - candles[i - 1].high
            val downMove = candles[i - 1].low - candles[i].low

            plusDM[i] = if (upMove > downMove && upMove > 0) upMove else 0.0
            minusDM[i] = if (downMove > upMove && downMove > 0) downMove else 0.0

            val h = candles[i].high
            val l = candles[i].low
            val prevC = candles[i - 1].close
            tr[i] = max(h - l, max(abs(h - prevC), abs(l - prevC)))
        }

        // Wilder's smoothing for TR, +DM, -DM
        var smoothTR = 0.0
        var smoothPlusDM = 0.0
        var smoothMinusDM = 0.0

        val plusDI = ArrayList<Double>(size)
        val minusDI = ArrayList<Double>(size)
        val dx = DoubleArray(size)

        for (i in 0 until size) {
            if (i < p) {
                smoothTR += tr[i]
                smoothPlusDM += plusDM[i]
                smoothMinusDM += minusDM[i]
                plusDI.add(0.0)
                minusDI.add(0.0)
                dx[i] = 0.0
            } else {
                if (i == p) {
                    // First initial average
                } else {
                    smoothTR = smoothTR - (smoothTR / p) + tr[i]
                    smoothPlusDM = smoothPlusDM - (smoothPlusDM / p) + plusDM[i]
                    smoothMinusDM = smoothMinusDM - (smoothMinusDM / p) + minusDM[i]
                }

                val pdi = if (smoothTR == 0.0) 0.0 else (smoothPlusDM / smoothTR) * 100.0
                val mdi = if (smoothTR == 0.0) 0.0 else (smoothMinusDM / smoothTR) * 100.0
                plusDI.add(pdi)
                minusDI.add(mdi)

                val sum = pdi + mdi
                val diff = abs(pdi - mdi)
                dx[i] = if (sum == 0.0) 0.0 else (diff / sum) * 100.0
            }
        }

        // ADX is smoothed DX
        val adx = ArrayList<Double>(size)
        var smoothDX = 0.0
        for (i in 0 until size) {
            if (i < p * 2 - 1) {
                if (i >= p) smoothDX += dx[i]
                adx.add(20.0) // baseline before full period
            } else if (i == p * 2 - 1) {
                smoothDX += dx[i]
                smoothDX /= p
                adx.add(smoothDX.coerceIn(0.0, 100.0))
            } else {
                smoothDX = (smoothDX * (p - 1) + dx[i]) / p
                adx.add(smoothDX.coerceIn(0.0, 100.0))
            }
        }

        return AdxResult(adx, plusDI, minusDI)
    }

    // 8. Stochastic Oscillator (%K, %D)
    fun calculateStochastic(
        candles: List<Candle>,
        kPeriod: Int = 14,
        dPeriod: Int = 3,
        smooth: Int = 3
    ): StochasticResult {
        if (candles.isEmpty()) return StochasticResult(emptyList(), emptyList())
        val size = candles.size
        val fastK = DoubleArray(size)

        for (i in 0 until size) {
            val start = max(0, i - kPeriod + 1)
            val sub = candles.subList(start, i + 1)
            val highestHigh = sub.maxOf { it.high }
            val lowestLow = sub.minOf { it.low }
            val diff = highestHigh - lowestLow

            fastK[i] = if (diff == 0.0) 50.0 else ((candles[i].close - lowestLow) / diff) * 100.0
        }

        // Smooth %K
        val kList = ArrayList<Double>(size)
        for (i in 0 until size) {
            val start = max(0, i - smooth + 1)
            var sum = 0.0
            for (j in start..i) sum += fastK[j]
            kList.add((sum / (i - start + 1)).coerceIn(0.0, 100.0))
        }

        // %D is SMA of %K
        val dList = ArrayList<Double>(size)
        for (i in 0 until size) {
            val start = max(0, i - dPeriod + 1)
            val sub = kList.subList(start, i + 1)
            dList.add(sub.average().coerceIn(0.0, 100.0))
        }

        return StochasticResult(kList, dList)
    }

    // 9. Supertrend Indicator
    fun calculateSupertrend(
        candles: List<Candle>,
        period: Int = 10,
        multiplier: Double = 3.0
    ): SupertrendResult {
        if (candles.isEmpty()) return SupertrendResult(emptyList(), emptyList())
        val atr = calculateATR(candles, period)
        val size = candles.size

        val values = ArrayList<Double>(size)
        val isBullish = ArrayList<Boolean>(size)

        var prevUpper = 0.0
        var prevLower = 0.0
        var prevTrend = true // true = bullish, false = bearish

        for (i in 0 until size) {
            val c = candles[i]
            val currentAtr = atr[i]
            val hl2 = (c.high + c.low) / 2.0

            val basicUpper = hl2 + (multiplier * currentAtr)
            val basicLower = hl2 - (multiplier * currentAtr)

            val finalUpper = if (i > 0 && (basicUpper < prevUpper || candles[i - 1].close > prevUpper)) basicUpper else if (i == 0) basicUpper else prevUpper
            val finalLower = if (i > 0 && (basicLower > prevLower || candles[i - 1].close < prevLower)) basicLower else if (i == 0) basicLower else prevLower

            val trend = when {
                c.close > finalUpper -> true
                c.close < finalLower -> false
                else -> prevTrend
            }

            val supertrendValue = if (trend) finalLower else finalUpper
            values.add(supertrendValue)
            isBullish.add(trend)

            prevUpper = finalUpper
            prevLower = finalLower
            prevTrend = trend
        }

        return SupertrendResult(values, isBullish)
    }
}
