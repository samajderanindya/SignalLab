package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun EquityCurveChart(
    equityCurve: List<Double>,
    initialBalance: Double,
    modifier: Modifier = Modifier
) {
    if (equityCurve.isEmpty()) return

    val minBal = equityCurve.minOrNull() ?: initialBalance
    val maxBal = equityCurve.maxOrNull() ?: initialBalance
    val finalBal = equityCurve.lastOrNull() ?: initialBalance
    val isNetProfit = finalBal >= initialBalance

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "EQUITY GROWTH SIMULATION",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    fontSize = 10.sp
                )
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "Final: ₹%,.0f".format(finalBal),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (isNetProfit) NeonGreen else NeonRed
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (size.width <= 0f || size.height <= 0f) return@Canvas
                val width = size.width
                val height = size.height
                val padY = 16f

                val range = if (maxBal - minBal > 0.001) maxBal - minBal else 1.0

                fun valToY(v: Double): Float {
                    val norm = ((v - minBal) / range).coerceIn(0.0, 1.0)
                    return (height - padY - (norm * (height - (2 * padY)))).toFloat()
                }

                // Baseline dashed line
                val baseLineY = valToY(initialBalance)
                val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                drawLine(
                    color = TerminalBorderSubtle,
                    start = Offset(0f, baseLineY),
                    end = Offset(width, baseLineY),
                    strokeWidth = 1.5f,
                    pathEffect = dash
                )

                // Fill gradient under curve
                val path = Path()
                val fillPath = Path()
                val stepX = if (equityCurve.size > 1) width / (equityCurve.size - 1) else width

                equityCurve.forEachIndexed { i, balance ->
                    val x = i * stepX
                    val y = valToY(balance)
                    if (i == 0) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, height)
                        fillPath.lineTo(x, y)
                    } else {
                        path.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                }
                if (equityCurve.size == 1) {
                    val singleY = valToY(equityCurve.first())
                    path.lineTo(width, singleY)
                    fillPath.lineTo(width, singleY)
                }
                fillPath.lineTo(width, height)
                fillPath.close()

                val curveColor = if (isNetProfit) NeonGreen else NeonRed
                val fillBrush = Brush.verticalGradient(
                    listOf(curveColor.copy(alpha = 0.25f), Color.Transparent),
                    startY = 0f,
                    endY = height
                )

                drawPath(path = fillPath, brush = fillBrush)
                drawPath(path = path, color = curveColor, style = Stroke(width = 2.5f))
            }
        }
    }
}
