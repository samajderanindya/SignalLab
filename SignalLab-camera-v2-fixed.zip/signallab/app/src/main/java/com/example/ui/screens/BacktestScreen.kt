package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.data.model.BacktestConfig
import com.example.data.model.BacktestResult
import com.example.data.model.ExecutionRule
import com.example.data.model.SignalDirection
import com.example.data.model.Timeframe
import com.example.data.model.TradeOutcome
import com.example.data.model.TradingStrategy
import com.example.ui.components.DemoDataBanner
import com.example.ui.components.DirectionBadge
import com.example.ui.components.EquityCurveChart
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBlack
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceHighlight
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BacktestScreen(
    config: BacktestConfig,
    strategies: List<TradingStrategy>,
    isBacktesting: Boolean,
    result: BacktestResult?,
    onConfigChange: (BacktestConfig) -> Unit,
    onRunBacktest: () -> Unit,
    modifier: Modifier = Modifier
) {
    var strategyDropdownExpanded by remember { mutableStateOf(false) }
    var auditExpanded by remember { mutableStateOf(false) }
    var tradeLedgerViewMode by remember { mutableStateOf("CARDS") } // "CARDS" (lazy virtualized) or "TABLE" (paginated)
    var tablePage by remember { mutableStateOf(0) }

    val selectedStrategy = strategies.find { it.id == config.strategyId } ?: strategies.firstOrNull()

    var startingBalanceInput by remember(config.startingBalance) {
        mutableStateOf(config.startingBalance.toInt().toString())
    }
    var stakeAmountInput by remember(config.stakeAmount) {
        mutableStateOf(config.stakeAmount.toInt().toString())
    }

    val appStatusText = when {
        isBacktesting -> "APP STATUS: RUNNING"
        result?.errorMessage != null && result.totalTrades == 0 -> "APP STATUS: ERROR"
        else -> "APP STATUS: READY"
    }
    val appStatusColor = when {
        isBacktesting -> TerminalCyan
        result?.errorMessage != null && result.totalTrades == 0 -> NeonRed
        else -> NeonGreen
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_backtest"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Diagnostic Status Indicator & DEMO DATA Banner
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TerminalSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, appStatusColor.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(appStatusColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = appStatusText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = appStatusColor,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        Text(
                            text = "ZERO LOOKAHEAD ENGINE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }

                DemoDataBanner(
                    isRealData = result?.isRealData ?: false,
                    label = result?.dataBadgeLabel ?: "DEMO DATA ONLY",
                    description = if (result?.isRealData == true) "Genuine Historical Market Ticks" else "Deterministic Simulated OHLCV Candle Dataset (Auditable)"
                )
            }
        }

        // Configuration Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("backtest_config_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "BACKTEST PARAMETERS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TerminalSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle)
                        ) {
                            Text(
                                text = "Payout: ${config.payoutPercentage.toInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalCyan,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 1. Asset Selection
                    Text(
                        text = "ASSET",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Asset.values().forEach { ast ->
                            val isSel = ast == config.asset
                            Surface(
                                onClick = { onConfigChange(config.copy(asset = ast)) },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) TerminalCyan else TerminalSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSel) TerminalCyan else TerminalBorderSubtle
                                )
                            ) {
                                Text(
                                    text = ast.code,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TerminalBlack else TextPrimary,
                                        fontSize = 11.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Timeframe Selection
                    Text(
                        text = "TIMEFRAME",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Timeframe.values().filter { it.seconds >= 60 }.forEach { tf ->
                            val isSel = tf == config.timeframe
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) TerminalCyan else TerminalSurfaceVariant)
                                    .border(1.dp, if (isSel) TerminalCyan else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable {
                                        val supportedExpiries = listOf(1, 3, 5, 15, 30, 60).filter { it % tf.minutes == 0 }
                                        val expiry = if (config.expiryMinutes in supportedExpiries) {
                                            config.expiryMinutes
                                        } else {
                                            supportedExpiries.firstOrNull() ?: tf.minutes
                                        }
                                        onConfigChange(config.copy(timeframe = tf, expiryMinutes = expiry))
                                    }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = tf.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TerminalBlack else TextPrimary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 3. Expiry Duration Selector
                    Text(
                        text = "EXPIRY DURATION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val expiries = listOf(1, 3, 5, 15, 30, 60).filter { it % config.timeframe.minutes == 0 }
                        expiries.forEach { exp ->
                            val isSel = exp == config.expiryMinutes
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) NeonGreen else TerminalSurfaceVariant)
                                    .border(1.dp, if (isSel) NeonGreen else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { onConfigChange(config.copy(expiryMinutes = exp)) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${exp}m",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TerminalBlack else TextPrimary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. Execution Rule Selector (Lookahead Bias Avoidance)
                    Text(
                        text = "EXECUTION RULE (LOOKAHEAD BIAS AVOIDANCE)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ExecutionRule.values().forEach { rule ->
                            val isSel = rule == config.executionRule
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) TerminalCyan else TerminalSurfaceVariant)
                                    .border(1.dp, if (isSel) TerminalCyan else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { onConfigChange(config.copy(executionRule = rule)) }
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = rule.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TerminalBlack else TextPrimary,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 5. Strategy Selection Dropdown
                    Text(
                        text = "STRATEGY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(
                        expanded = strategyDropdownExpanded,
                        onExpandedChange = { strategyDropdownExpanded = !strategyDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedStrategy?.name ?: "Select Strategy",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = strategyDropdownExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalCyan,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = TerminalSurfaceVariant,
                                unfocusedContainerColor = TerminalSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = strategyDropdownExpanded,
                            onDismissRequest = { strategyDropdownExpanded = false },
                            modifier = Modifier.background(TerminalSurfaceVariant)
                        ) {
                            strategies.forEach { strat ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(text = strat.name, color = TextPrimary, fontWeight = FontWeight.Bold)
                                            Text(text = "${strat.action.label} • Default: ${strat.expiryMinutes}m", color = TextMuted, fontSize = 11.sp)
                                        }
                                    },
                                    onClick = {
                                        val supportedExpiries = listOf(1, 3, 5, 15, 30, 60).filter { it % config.timeframe.minutes == 0 }
                                        val strategyExpiry = if (strat.expiryMinutes in supportedExpiries) {
                                            strat.expiryMinutes
                                        } else {
                                            supportedExpiries.firstOrNull() ?: config.timeframe.minutes
                                        }
                                        onConfigChange(config.copy(strategyId = strat.id, expiryMinutes = strategyExpiry))
                                        strategyDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 6. Date Range Selector
                    Text(
                        text = "HISTORICAL DATE RANGE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val ranges = listOf("Last 7 Days", "Last 30 Days", "Last 90 Days")
                        ranges.forEach { range ->
                            val isSel = range == config.dateRangeLabel
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) TerminalSurfaceHighlight else TerminalSurfaceVariant)
                                    .border(1.dp, if (isSel) TerminalCyan else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { onConfigChange(config.copy(dateRangeLabel = range)) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = range,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TerminalCyan else TextSecondary,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 7. Stake & Starting Balance Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "STARTING BAL (₹)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            OutlinedTextField(
                                value = startingBalanceInput,
                                onValueChange = { str ->
                                    val digitsOnly = str.filter { it.isDigit() }
                                    startingBalanceInput = digitsOnly
                                    val num = digitsOnly.toDoubleOrNull()
                                    if (num != null && num > 0) {
                                        onConfigChange(config.copy(startingBalance = num))
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.testTag("input_starting_balance"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TerminalCyan,
                                    unfocusedBorderColor = TerminalBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedContainerColor = TerminalSurfaceVariant,
                                    unfocusedContainerColor = TerminalSurfaceVariant
                                )
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "STAKE / TRADE (₹)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            OutlinedTextField(
                                value = stakeAmountInput,
                                onValueChange = { str ->
                                    val digitsOnly = str.filter { it.isDigit() }
                                    stakeAmountInput = digitsOnly
                                    val num = digitsOnly.toDoubleOrNull()
                                    if (num != null && num > 0) {
                                        onConfigChange(config.copy(stakeAmount = num))
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.testTag("input_stake_amount"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TerminalCyan,
                                    unfocusedBorderColor = TerminalBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedContainerColor = TerminalSurfaceVariant,
                                    unfocusedContainerColor = TerminalSurfaceVariant
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Run Backtest Action Button
                    Button(
                        onClick = onRunBacktest,
                        enabled = !isBacktesting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TerminalCyan,
                            contentColor = TerminalBlack
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_backtest_button")
                    ) {
                        if (isBacktesting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = TerminalBlack,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Simulating Historical Candles...", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                        } else {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RUN BACKTEST SIMULATION", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Backtest Results Area
        if (result != null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BACKTEST RESULTS • ${result.strategyName}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (result.validationPassed) NeonGreen.copy(alpha = 0.15f) else NeonRed.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (result.validationPassed) NeonGreen else NeonRed)
                    ) {
                        Text(
                            text = if (result.validationPassed) "AUDITED ✓" else "VALIDATION ISSUE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (result.validationPassed) NeonGreen else NeonRed,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (result.totalTrades == 0) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "SIMULATION STATUS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalAmber,
                                    fontSize = 11.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = result.errorMessage ?: "No trade signals generated for selected parameters in this historical dataset.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                            )
                        }
                    }
                }
            } else {
                // Results Performance Summary Cards
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Starting & Ending Balance Card
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "STARTING BALANCE",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TextMuted,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "₹%,.2f".format(result.startingBalance),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            color = TextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = TerminalCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "ENDING BALANCE",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TextMuted,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "₹%,.2f".format(result.finalBalance),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            color = if (result.finalBalance >= result.startingBalance) NeonGreen else NeonRed,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }

                        // Row 1: Net P&L + Win Rate
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricStatCard(
                                title = "Net P&L",
                                value = "${if (result.netPnl >= 0) "+" else ""}₹%,.2f".format(result.netPnl),
                                subtitle = "${if (result.roiPercentage >= 0) "+" else ""}%.2f%% ROI".format(result.roiPercentage),
                                valueColor = if (result.netPnl >= 0) NeonGreen else NeonRed,
                                icon = if (result.netPnl >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                modifier = Modifier.weight(1f)
                            )
                            MetricStatCard(
                                title = "Win Rate",
                                value = "%.1f%%".format(result.winRate),
                                subtitle = "${result.wins}W / ${result.losses}L / ${result.draws}P (${result.totalTrades} total)",
                                valueColor = if (result.winRate >= 60.0) NeonGreen else TerminalAmber,
                                icon = Icons.Default.AutoGraph,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Row 2: Max Drawdown + Profit Factor
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricStatCard(
                                title = "Max Drawdown",
                                value = "%.2f%%".format(result.maxDrawdownPercentage),
                                subtitle = "Peak-to-trough balance drop",
                                valueColor = if (result.maxDrawdownPercentage < 15.0) TerminalCyan else NeonRed,
                                modifier = Modifier.weight(1f)
                            )
                            val pfText = when {
                                result.profitFactor.isInfinite() -> "∞"
                                result.profitFactor == 0.0 && result.grossProfit == 0.0 -> "0.00"
                                else -> "%.2f".format(result.profitFactor)
                            }
                            val pfSub = when {
                                result.profitFactor.isInfinite() -> "No losing trades"
                                else -> "Gross Gain / Loss"
                            }
                            MetricStatCard(
                                title = "Profit Factor",
                                value = pfText,
                                subtitle = pfSub,
                                valueColor = if (result.profitFactor > 1.2 || result.profitFactor.isInfinite()) NeonGreen else TextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Row 3: Streaks + Avg Trade P&L
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricStatCard(
                                title = "Max Streaks",
                                value = "${result.maxWinningStreak}W / ${result.maxLosingStreak}L",
                                subtitle = "Best win / Worst loss streak",
                                valueColor = if (result.maxWinningStreak >= result.maxLosingStreak) NeonGreen else TerminalAmber,
                                modifier = Modifier.weight(1f)
                            )
                            MetricStatCard(
                                title = "Avg P&L / Trade",
                                value = "${if (result.avgPnlPerTrade >= 0) "+" else ""}₹%,.2f".format(result.avgPnlPerTrade),
                                subtitle = "Gross: +₹%,.0f / -₹%,.0f".format(result.grossProfit, result.grossLoss),
                                valueColor = if (result.avgPnlPerTrade >= 0) NeonGreen else NeonRed,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Payout Assumption Note
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TerminalSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = TerminalCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Payout Model: %.0f%% (Win: +₹%,.2f | Loss: -₹%,.2f per ₹%,.2f stake | Push: ₹0 refund)".format(
                                        result.config.payoutPercentage,
                                        result.config.stakeAmount * (result.config.payoutPercentage / 100.0),
                                        result.config.stakeAmount,
                                        result.config.stakeAmount
                                    ),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }
                }

                // Equity Curve Chart
                item {
                    EquityCurveChart(
                        equityCurve = result.equityCurve,
                        initialBalance = result.config.startingBalance
                    )
                }

                // Expandable Backtest Audit & Verification Section
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCyan.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { auditExpanded = !auditExpanded },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = TerminalCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "BACKTEST AUDIT & DIAGNOSTICS",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    )
                                }
                                IconButton(
                                    onClick = { auditExpanded = !auditExpanded },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = if (auditExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = if (auditExpanded) "Collapse" else "Expand",
                                        tint = TerminalCyan
                                    )
                                }
                            }

                            AnimatedVisibility(visible = auditExpanded) {
                                Column(
                                    modifier = Modifier.padding(top = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Audit Grid
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        AuditMetricBadge("Candles Loaded", "${result.auditInfo.candlesLoaded}", Modifier.weight(1f))
                                        AuditMetricBadge("Valid Indicator Candles", "${result.auditInfo.validIndicatorCandles}", Modifier.weight(1f))
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        AuditMetricBadge("Signals Generated", "${result.auditInfo.signalsGenerated}", Modifier.weight(1f))
                                        AuditMetricBadge("Executed Trades", "${result.auditInfo.tradesExecuted}", Modifier.weight(1f))
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        AuditMetricBadge("CALL / PUT Signals", "${result.auditInfo.callSignalsCount} CALL / ${result.auditInfo.putSignalsCount} PUT", Modifier.weight(1f))
                                        AuditMetricBadge("PUSH / TIE Results", "${result.auditInfo.pushResultsCount}", Modifier.weight(1f))
                                    }

                                    // Timestamps
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = TerminalSurfaceVariant,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text(
                                                text = "Dataset Window: ${result.auditInfo.firstCandleTime} → ${result.auditInfo.lastCandleTime}",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontFamily = FontFamily.Monospace,
                                                    color = TextMuted,
                                                    fontSize = 10.sp
                                                )
                                            )
                                            Text(
                                                text = "Execution: ${result.config.executionRule.displayName}",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontFamily = FontFamily.Monospace,
                                                    color = TerminalCyan,
                                                    fontSize = 10.sp
                                                )
                                            )
                                        }
                                    }

                                    // Skipped Signals Reasons
                                    if (result.auditInfo.skippedSignals > 0) {
                                        Text(
                                            text = "SKIPPED SIGNALS (${result.auditInfo.skippedSignals}):",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = TerminalAmber,
                                                fontSize = 10.sp
                                            )
                                        )
                                        result.auditInfo.skippedReasons.forEach { (reason, count) ->
                                            Text(
                                                text = "• $reason: $count times",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                            )
                                        }
                                    }

                                    // Validation checks
                                    Text(
                                        text = "AUDIT VERIFICATION CHECKS:",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            fontSize = 10.sp
                                        )
                                    )
                                    result.auditInfo.validationChecks.forEach { check ->
                                        Text(
                                            text = check,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontFamily = FontFamily.Monospace,
                                                color = if (check.startsWith("✓")) NeonGreen else if (check.startsWith("✗")) NeonRed else TextMuted,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Detailed Trade History Ledger Header & Mode Toggle
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TRADE HISTORY LEDGER (${result.trades.size})",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Surface(
                                onClick = { tradeLedgerViewMode = "TABLE" },
                                shape = RoundedCornerShape(4.dp),
                                color = if (tradeLedgerViewMode == "TABLE") TerminalCyan else TerminalSurfaceVariant
                            ) {
                                Text(
                                    text = "TABLE",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (tradeLedgerViewMode == "TABLE") TerminalBlack else TextPrimary,
                                        fontSize = 9.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Surface(
                                onClick = { tradeLedgerViewMode = "CARDS" },
                                shape = RoundedCornerShape(4.dp),
                                color = if (tradeLedgerViewMode == "CARDS") TerminalCyan else TerminalSurfaceVariant
                            ) {
                                Text(
                                    text = "CARDS",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (tradeLedgerViewMode == "CARDS") TerminalBlack else TextPrimary,
                                        fontSize = 9.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                // Table or Card Ledger View
                if (result.trades.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No trades executed during this simulation period.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                )
                            }
                        }
                    }
                } else if (tradeLedgerViewMode == "TABLE") {
                    // Table Card Container with safe pagination (15 trades per page)
                    item {
                        val pageSize = 15
                        val totalPages = kotlin.math.max(1, kotlin.math.ceil(result.trades.size.toDouble() / pageSize).toInt())
                        val currentPage = tablePage.coerceIn(0, totalPages - 1)
                        val pageTrades = result.trades.drop(currentPage * pageSize).take(pageSize)

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val horizontalScroll = rememberScrollState()
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                            ) {
                                // Horizontal scrollable table container
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(horizontalScroll)
                                ) {
                                    // Table Header
                                    Row(
                                        modifier = Modifier
                                            .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TableCell("#", width = 36.dp, isHeader = true)
                                        TableCell("Asset", width = 72.dp, isHeader = true)
                                        TableCell("TF", width = 40.dp, isHeader = true)
                                        TableCell("Signal", width = 64.dp, isHeader = true)
                                        TableCell("Rule", width = 76.dp, isHeader = true)
                                        TableCell("Entry Time", width = 88.dp, isHeader = true)
                                        TableCell("Entry Price", width = 88.dp, isHeader = true)
                                        TableCell("Expiry Time", width = 88.dp, isHeader = true)
                                        TableCell("Expiry Price", width = 88.dp, isHeader = true)
                                        TableCell("Stake", width = 64.dp, isHeader = true)
                                        TableCell("Payout", width = 64.dp, isHeader = true)
                                        TableCell("Result", width = 64.dp, isHeader = true)
                                        TableCell("P&L", width = 80.dp, isHeader = true)
                                        TableCell("Balance After", width = 96.dp, isHeader = true)
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    // Table Rows for current page
                                    pageTrades.forEach { trade ->
                                        val outcomeColor = when (trade.outcome) {
                                            TradeOutcome.WIN -> NeonGreen
                                            TradeOutcome.LOSS -> NeonRed
                                            TradeOutcome.DRAW -> TerminalAmber
                                        }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TableCell("#${trade.id}", width = 36.dp)
                                            TableCell(trade.asset.code, width = 72.dp)
                                            TableCell(trade.timeframe.label, width = 40.dp)
                                            TableCell(trade.direction.label, width = 64.dp, color = if (trade.direction.isCall) NeonGreen else NeonRed)
                                            TableCell(trade.executionRule.shortLabel, width = 76.dp)
                                            TableCell(trade.entryTimeFormatted, width = 88.dp)
                                            TableCell("%.5f".format(trade.entryPrice), width = 88.dp)
                                            TableCell(trade.expiryTimeFormatted, width = 88.dp)
                                            TableCell("%.5f".format(trade.exitPrice), width = 88.dp)
                                            TableCell("₹%.0f".format(trade.stake), width = 64.dp)
                                            TableCell("₹%.0f".format(trade.payout), width = 64.dp)
                                            TableCell(trade.outcome.name, width = 64.dp, color = outcomeColor, isBold = true)
                                            TableCell("${if (trade.pnl > 0) "+" else ""}₹%,.2f".format(trade.pnl), width = 80.dp, color = outcomeColor, isBold = true)
                                            TableCell("₹%,.2f".format(trade.balanceAfter), width = 96.dp, isBold = true)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Pagination Bar
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        onClick = { if (currentPage > 0) tablePage = currentPage - 1 },
                                        enabled = currentPage > 0,
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (currentPage > 0) TerminalSurfaceVariant else TerminalSurface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle)
                                    ) {
                                        Text(
                                            text = "◀ PREV",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (currentPage > 0) TerminalCyan else TextMuted,
                                                fontSize = 10.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    Text(
                                        text = "Page ${currentPage + 1} of $totalPages (${result.trades.size} trades)",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            color = TextSecondary,
                                            fontSize = 10.sp
                                        )
                                    )

                                    Surface(
                                        onClick = { if (currentPage < totalPages - 1) tablePage = currentPage + 1 },
                                        enabled = currentPage < totalPages - 1,
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (currentPage < totalPages - 1) TerminalSurfaceVariant else TerminalSurface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle)
                                    ) {
                                        Text(
                                            text = "NEXT ▶",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (currentPage < totalPages - 1) TerminalCyan else TextMuted,
                                                fontSize = 10.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Card View (Lazily Composed Items)
                    items(result.trades, key = { it.id }) { trade ->
                        val outcomeColor = when (trade.outcome) {
                            TradeOutcome.WIN -> NeonGreen
                            TradeOutcome.LOSS -> NeonRed
                            TradeOutcome.DRAW -> TerminalAmber
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(TerminalSurface)
                                .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    DirectionBadge(direction = trade.direction)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "#${trade.id} • ${trade.asset.code} (${trade.timeframe.label}) • ${trade.entryTimeFormatted}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = TextMuted,
                                                fontSize = 11.sp
                                            )
                                        )
                                        Text(
                                            text = "In: %.5f → Exp: %.5f (%s)".format(trade.entryPrice, trade.exitPrice, trade.expiryTimeFormatted),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = FontFamily.Monospace,
                                                color = TextSecondary,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${if (trade.pnl > 0) "+" else ""}₹%,.2f".format(trade.pnl),
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = outcomeColor
                                        )
                                    )
                                    Text(
                                        text = "${trade.outcome.name} (Bal: ₹%,.0f)".format(trade.balanceAfter),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = outcomeColor,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoGraph,
                            contentDescription = null,
                            tint = TerminalCyan,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "READY FOR ZERO-LOOKAHEAD SIMULATION",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Configure parameters above and press RUN BACKTEST SIMULATION to evaluate historical performance with zero lookahead bias.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextMuted,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    color: androidx.compose.ui.graphics.Color = TextPrimary,
    isBold: Boolean = false
) {
    Box(
        modifier = Modifier
            .width(width)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isHeader || isBold) FontWeight.Bold else FontWeight.Normal,
                color = if (isHeader) TextMuted else color,
                fontSize = if (isHeader) 10.sp else 11.sp
            ),
            maxLines = 1
        )
    }
}

@Composable
private fun AuditMetricBadge(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = TerminalSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorderSubtle),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextMuted,
                    fontSize = 9.sp
                )
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 11.sp
                )
            )
        }
    }
}
