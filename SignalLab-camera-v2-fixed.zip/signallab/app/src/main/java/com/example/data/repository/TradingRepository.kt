package com.example.data.repository

import com.example.data.engine.BacktestEngine
import com.example.data.engine.HistoricalDataEngine
import com.example.data.engine.FastSignalEngine
import com.example.data.engine.FastStrategyRanker
import com.example.data.engine.StrategyEngine
import com.example.data.engine.TechnicalIndicators
import com.example.data.model.Asset
import com.example.data.model.BacktestConfig
import com.example.data.model.BacktestResult
import com.example.data.model.Candle
import com.example.data.model.IndicatorParameters
import com.example.data.model.PaperTrade
import com.example.data.model.PaperTradeStatus
import com.example.data.model.SignalDirection
import com.example.data.model.SignalItem
import com.example.data.model.SignalStatus
import com.example.data.model.Timeframe
import com.example.data.model.TradingStrategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Data Source Interface for Historical OHLCV Candles.
 * Allows seamless switching between Demo Data generation and future live exchange/broker APIs.
 */
interface HistoricalDataSource {
    fun fetchCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle>
    fun isDemoData(): Boolean
}

class DeterministicDemoHistoricalDataSource : HistoricalDataSource {
    override fun fetchCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle> {
        return HistoricalDataEngine.generateCandles(asset, timeframe, count)
    }

    override fun isDemoData(): Boolean = true
}

/**
 * Terminal-first historical source. It never mixes generated demo candles into
 * the live chart. Until the terminal bridge has observed enough quotes, the
 * returned list is simply empty/partial and the UI can say that history is
 * still being built.
 */
class HybridTerminalHistoricalDataSource : HistoricalDataSource {
    override fun fetchCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle> {
        val feed = com.example.data.engine.OlympTradeAccessibilityService.feed
        return feed.snapshot(asset, timeframe, count)
    }

    override fun isDemoData(): Boolean = false
}

/**
 * Clean Trading Repository Interface for SignalLab.
 */
interface ITradingRepository {
    val virtualBalance: StateFlow<Double>
    val paperTrades: StateFlow<List<PaperTrade>>
    val strategies: StateFlow<List<TradingStrategy>>
    val signals: StateFlow<List<SignalItem>>
    val indicatorParams: StateFlow<IndicatorParameters>

    fun getCurrentPrice(asset: Asset): Double
    fun updateAssetPrice(asset: Asset, newPrice: Double)
    fun resetVirtualBalance(newBalance: Double)
    fun addVirtualFunds(amount: Double)
    fun placePaperTrade(asset: Asset, direction: SignalDirection, stake: Double, expirySeconds: Int, payoutPercentage: Double): Boolean
    fun tickActiveTrades()
    fun saveStrategy(strategy: TradingStrategy)
    fun deleteStrategy(strategyId: String)
    fun updateIndicatorParameters(params: IndicatorParameters)
    fun resetIndicatorParameters()
    fun generateCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle>
    fun runBacktest(config: BacktestConfig): BacktestResult
    fun refreshSignals()
}

class TradingRepository(
    private val historicalDataSource: HistoricalDataSource = HybridTerminalHistoricalDataSource()
) : ITradingRepository {

    private val _virtualBalance = MutableStateFlow(10000.0)
    override val virtualBalance: StateFlow<Double> = _virtualBalance.asStateFlow()

    private val _paperTrades = MutableStateFlow<List<PaperTrade>>(emptyList())
    override val paperTrades: StateFlow<List<PaperTrade>> = _paperTrades.asStateFlow()

    private val _indicatorParams = MutableStateFlow(IndicatorParameters())
    override val indicatorParams: StateFlow<IndicatorParameters> = _indicatorParams.asStateFlow()

    private val _strategies = MutableStateFlow<List<TradingStrategy>>(
        StrategyEngine.getPrebuiltStrategies(_indicatorParams.value)
    )
    override val strategies: StateFlow<List<TradingStrategy>> = _strategies.asStateFlow()

    private val _signals = MutableStateFlow<List<SignalItem>>(generateDynamicSignals())
    override val signals: StateFlow<List<SignalItem>> = _signals.asStateFlow()

    // Live asset prices cache
    private val assetPrices = mutableMapOf(
        Asset.EUR_USD to Asset.EUR_USD.basePrice,
        Asset.GBP_USD to Asset.GBP_USD.basePrice,
        Asset.USD_JPY to Asset.USD_JPY.basePrice,
        Asset.BTC_USD to Asset.BTC_USD.basePrice,
        Asset.ASIA_COMPOSITE to Asset.ASIA_COMPOSITE.basePrice,
        Asset.CRYPTO_COMPOSITE to Asset.CRYPTO_COMPOSITE.basePrice,
        Asset.EUROPE_COMPOSITE to Asset.EUROPE_COMPOSITE.basePrice,
        Asset.COMPOUND_INDEX to Asset.COMPOUND_INDEX.basePrice
    )

    override fun getCurrentPrice(asset: Asset): Double {
        val livePrice = com.example.data.engine.OlympTradeAccessibilityService.feed.latestPrice(asset)
        return livePrice ?: (assetPrices[asset] ?: asset.basePrice)
    }

    override fun updateAssetPrice(asset: Asset, newPrice: Double) {
        assetPrices[asset] = newPrice
    }

    override fun resetVirtualBalance(newBalance: Double) {
        _virtualBalance.value = newBalance
        _paperTrades.value = emptyList()
    }

    override fun addVirtualFunds(amount: Double) {
        _virtualBalance.value += amount
    }

    override fun placePaperTrade(
        asset: Asset,
        direction: SignalDirection,
        stake: Double,
        expirySeconds: Int,
        payoutPercentage: Double
    ): Boolean {
        if (_virtualBalance.value < stake) return false

        _virtualBalance.value -= stake
        val currentPrice = getCurrentPrice(asset)
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val newTrade = PaperTrade(
            id = UUID.randomUUID().toString().take(8),
            asset = asset,
            direction = direction,
            entryPrice = currentPrice,
            stake = stake,
            payoutPercentage = payoutPercentage,
            expiryMinutes = kotlin.math.ceil(expirySeconds / 60.0).toInt(),
            expirySeconds = expirySeconds,
            remainingSeconds = expirySeconds,
            totalSeconds = expirySeconds,
            startTimeFormatted = timeFormat.format(Date()),
            status = PaperTradeStatus.ACTIVE
        )

        _paperTrades.value = listOf(newTrade) + _paperTrades.value
        return true
    }

    override fun tickActiveTrades() {
        val currentList = _paperTrades.value.toMutableList()
        var updated = false
        var balanceDelta = 0.0

        for (i in currentList.indices) {
            val trade = currentList[i]
            if (trade.status == PaperTradeStatus.ACTIVE) {
                val newRemaining = trade.remainingSeconds - 1
                if (newRemaining <= 0) {
                    // Settle trade at expiry
                    val currentPrice = getCurrentPrice(trade.asset)
                    val priceDelta = currentPrice - trade.entryPrice
                    val won = if (trade.direction == SignalDirection.CALL) {
                        priceDelta > 0.000001
                    } else {
                        priceDelta < -0.000001
                    }

                    val finalStatus = if (won) PaperTradeStatus.WON else PaperTradeStatus.LOST
                    val pnl = if (won) {
                        trade.stake * (trade.payoutPercentage / 100.0)
                    } else {
                        -trade.stake
                    }

                    if (won) {
                        balanceDelta += trade.stake + pnl
                    }

                    currentList[i] = trade.copy(
                        remainingSeconds = 0,
                        status = finalStatus,
                        exitPrice = currentPrice,
                        pnl = pnl
                    )
                    updated = true
                } else {
                    currentList[i] = trade.copy(remainingSeconds = newRemaining)
                    updated = true
                }
            }
        }

        if (updated) {
            _paperTrades.value = currentList
            if (balanceDelta > 0) {
                _virtualBalance.value += balanceDelta
            }
        }
    }

    override fun updateIndicatorParameters(params: IndicatorParameters) {
        _indicatorParams.value = params
        // Refresh prebuilt strategies with new parameter values
        val customStrategies = _strategies.value.filter { !it.isPrebuilt }
        val updatedPrebuilt = StrategyEngine.getPrebuiltStrategies(params)
        _strategies.value = updatedPrebuilt + customStrategies
        _signals.value = generateDynamicSignals()
    }

    override fun resetIndicatorParameters() {
        updateIndicatorParameters(IndicatorParameters())
    }

    override fun saveStrategy(strategy: TradingStrategy) {
        val current = _strategies.value.toMutableList()
        val index = current.indexOfFirst { it.id == strategy.id }
        if (index >= 0) {
            current[index] = strategy
        } else {
            current.add(0, strategy)
        }
        _strategies.value = current
    }

    override fun deleteStrategy(strategyId: String) {
        _strategies.value = _strategies.value.filter { it.id != strategyId }
    }

    override fun generateCandles(asset: Asset, timeframe: Timeframe, count: Int): List<Candle> {
        val candles = historicalDataSource.fetchCandles(asset, timeframe, count)
        candles.lastOrNull()?.let { updateAssetPrice(asset, it.close) }
        return candles
    }

    override fun runBacktest(config: BacktestConfig): BacktestResult {
        val strategy = _strategies.value.find { it.id == config.strategyId }
            ?: _strategies.value.first()
        return BacktestEngine.executeBacktest(config, strategy)
    }

    override fun refreshSignals() {
        _signals.value = generateDynamicSignals()
    }

    // Generate dynamic technical signals based on the fast-market confluence engine.
    fun generateDynamicSignals(): List<SignalItem> {
        val signalsList = mutableListOf<SignalItem>()
        val params = _indicatorParams.value
        val fastEngine = FastSignalEngine(params)

        Asset.values().forEachIndexed { index, asset ->
            val preferredTimeframe = when (asset.category) {
                "Composite Index" -> when (index % 3) {
                    0 -> Timeframe.S5
                    1 -> Timeframe.S15
                    else -> Timeframe.S30
                }
                else -> Timeframe.S15
            }
            val candles = historicalDataSource.fetchCandles(asset, preferredTimeframe, 80)
            val isLive = !historicalDataSource.isDemoData() && candles.isNotEmpty()
            val evaluation = fastEngine.evaluate(
                asset,
                preferredTimeframe,
                candles,
                if (isLive) "OLYMP TRADE TERMINAL FEED" else "DEMO QUOTE ENGINE"
            )
            val direction = evaluation.direction ?: return@forEachIndexed
            val price = candles.lastOrNull()?.close ?: asset.basePrice
            val score = evaluation.score
            val ranked = FastStrategyRanker(params).rank(candles)
            val best = ranked.firstOrNull()

            val rankedReason = if (best != null) {
                "Best rolling strategy: ${best.name} (${"%.1f".format(best.hitRate)}% / ${best.samples} samples)"
            } else {
                "Strategy ranking needs more quote history"
            }

            signalsList.add(
                SignalItem(
                    id = "sig_${asset.name.lowercase()}_${preferredTimeframe.name}",
                    asset = asset,
                    direction = direction,
                    expiryMinutes = 1,
                    expirySeconds = evaluation.expirySeconds,
                    score = score,
                    conditions = listOf(rankedReason) + evaluation.reasons,
                    sampleCount = best?.samples ?: 0,
                    historicalWinRate = best?.hitRate ?: 0.0,
                    timestampFormatted = "just now",
                    currentPrice = price,
                    sourceLabel = when {
                        isLive && candles.size >= 35 -> "OLYMP TRADE TERMINAL FEED"
                        isLive -> "LIVE FEED — BUILDING HISTORY"
                        else -> "DEMO DATA ONLY"
                    },
                    status = SignalStatus.ACTIVE
                )
            )
        }

        return signalsList.sortedByDescending { it.score }

    }
}

