package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.data.model.SignalDirection
import com.example.data.model.SignalItem
import com.example.ui.components.DemoDataBanner
import com.example.ui.components.SignalCard
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBlack
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SignalsScreen(
    signals: List<SignalItem>,
    onSimulateSignal: (SignalItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDirectionFilter by remember { mutableStateOf<SignalDirection?>(null) }
    var selectedAssetFilter by remember { mutableStateOf<Asset?>(null) }

    val filteredSignals = signals.filter { signal ->
        (selectedDirectionFilter == null || signal.direction == selectedDirectionFilter) &&
        (selectedAssetFilter == null || signal.asset == selectedAssetFilter)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_signals"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // DEMO DATA Warning
        item {
            DemoDataBanner()
        }

        // Section Title & Overview
        item {
            Column {
                Text(
                    text = "ALGORITHMIC SIGNAL RADAR",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "Live multi-indicator technical confluence scans across fixed-time intervals.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                )
            }
        }

        // Filter Bar (Direction Filters: ALL, CALL, PUT)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // ALL
                Surface(
                    onClick = {
                        selectedDirectionFilter = null
                        selectedAssetFilter = null
                    },
                    shape = RoundedCornerShape(8.dp),
                    color = if (selectedDirectionFilter == null && selectedAssetFilter == null) TerminalCyan else TerminalSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier.testTag("filter_all")
                ) {
                    Text(
                        text = "ALL SIGNALS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (selectedDirectionFilter == null && selectedAssetFilter == null) TerminalBlack else TextPrimary,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // CALL ONLY
                Surface(
                    onClick = { selectedDirectionFilter = if (selectedDirectionFilter == SignalDirection.CALL) null else SignalDirection.CALL },
                    shape = RoundedCornerShape(8.dp),
                    color = if (selectedDirectionFilter == SignalDirection.CALL) NeonGreen else TerminalSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier.testTag("filter_call")
                ) {
                    Text(
                        text = "CALL ONLY ↗",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (selectedDirectionFilter == SignalDirection.CALL) TerminalBlack else NeonGreen,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // PUT ONLY
                Surface(
                    onClick = { selectedDirectionFilter = if (selectedDirectionFilter == SignalDirection.PUT) null else SignalDirection.PUT },
                    shape = RoundedCornerShape(8.dp),
                    color = if (selectedDirectionFilter == SignalDirection.PUT) NeonRed else TerminalSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier.testTag("filter_put")
                ) {
                    Text(
                        text = "PUT ONLY ↘",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (selectedDirectionFilter == SignalDirection.PUT) TerminalBlack else NeonRed,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // Asset quick filters
                Asset.values().forEach { asset ->
                    val isSel = selectedAssetFilter == asset
                    Surface(
                        onClick = { selectedAssetFilter = if (isSel) null else asset },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) TerminalCyan else TerminalSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
                    ) {
                        Text(
                            text = asset.code,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) TerminalBlack else TextPrimary,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Signals Feed List
        if (filteredSignals.isEmpty()) {
            item {
                Text(
                    text = "No signals match the active filters.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        } else {
            items(filteredSignals, key = { it.id }) { signal ->
                SignalCard(
                    signal = signal,
                    onSimulateClick = { onSimulateSignal(signal) }
                )
            }
        }
    }
}
