package com.example.data.engine

import com.example.data.model.Candle
import com.example.data.model.IndicatorParameters
import com.example.data.model.SignalDirection

/**
 * Rolling, causal ranking for the fast-market presets. It measures the historical
 * direction hit-rate on the supplied candle stream using only information available
 * before each evaluated bar. It is a research metric, not a guarantee.
 */
data class StrategyRank(
    val name: String,
    val hitRate: Double,
    val samples: Int
)

class FastStrategyRanker(private val params: IndicatorParameters = IndicatorParameters()) {
    fun rank(candles: List<Candle>): List<StrategyRank> {
        if (candles.size < 45) return emptyList()
        val emaFast = TechnicalIndicators.calculateEMA(candles, params.emaFastPeriod)
        val emaSlow = TechnicalIndicators.calculateEMA(candles, params.emaSlowPeriod)
        val rsi = TechnicalIndicators.calculateRSI(candles, params.rsiPeriod)
        val macd = TechnicalIndicators.calculateMACD(candles, params.macdFast, params.macdSlow, params.macdSignal)
        val st = TechnicalIndicators.calculateSupertrend(candles, params.supertrendPeriod, params.supertrendMultiplier)
        val adx = TechnicalIndicators.calculateADX(candles, params.adxPeriod)

        data class Rule(val name: String, val signal: (Int) -> SignalDirection?)
        val rules = listOf(
            Rule("EMA + RSI", { i ->
                when {
                    emaFast[i] > emaSlow[i] && rsi[i] > 50 -> SignalDirection.CALL
                    emaFast[i] < emaSlow[i] && rsi[i] < 50 -> SignalDirection.PUT
                    else -> null
                }
            }),
            Rule("MACD Crossover", { i ->
                if (i < 1) null else when {
                    macd.macdLine[i] > macd.signalLine[i] && macd.macdLine[i-1] <= macd.signalLine[i-1] -> SignalDirection.CALL
                    macd.macdLine[i] < macd.signalLine[i] && macd.macdLine[i-1] >= macd.signalLine[i-1] -> SignalDirection.PUT
                    else -> null
                }
            }),
            Rule("Supertrend + ADX", { i ->
                when {
                    st.isBullish[i] && adx.adx[i] >= params.adxThreshold -> SignalDirection.CALL
                    !st.isBullish[i] && adx.adx[i] >= params.adxThreshold -> SignalDirection.PUT
                    else -> null
                }
            })
        )

        return rules.map { rule ->
            var wins = 0
            var samples = 0
            for (i in 1 until candles.lastIndex) {
                val direction = rule.signal(i) ?: continue
                val next = candles[i + 1]
                val won = if (direction == SignalDirection.CALL) next.close > candles[i].close else next.close < candles[i].close
                if (won) wins++
                samples++
            }
            StrategyRank(rule.name, if (samples == 0) 0.0 else wins.toDouble() / samples * 100.0, samples)
        }.sortedByDescending { it.hitRate }
    }
}
