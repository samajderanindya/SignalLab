package com.example.ui.navigation

import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.PaperTradeDialog
import com.example.ui.components.SignalLabTopHeader
import com.example.ui.screens.BacktestScreen
import com.example.ui.screens.CameraScannerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MarketsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SignalsScreen
import com.example.ui.screens.StrategiesScreen
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceHighlight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.SignalLabViewModel

enum class ScreenTab(val title: String, val icon: ImageVector, val tag: String) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard, "tab_dashboard"),
    MARKETS("Markets", Icons.Default.ShowChart, "tab_markets"),
    CAMERA("Camera", Icons.Default.CameraAlt, "tab_camera"),
    BACKTEST("Backtest", Icons.Default.AutoGraph, "tab_backtest"),
    STRATEGIES("Strategies", Icons.Default.Psychology, "tab_strategies"),
    SIGNALS("Signals", Icons.Default.SignalCellularAlt, "tab_signals"),
    SETTINGS("Settings", Icons.Default.Settings, "tab_settings")
}

@Composable
fun SignalLabApp(
    viewModel: SignalLabViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(ScreenTab.DASHBOARD) }
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // State collections
    val virtualBalance by viewModel.virtualBalance.collectAsState()
    val dashboardStats by viewModel.dashboardStats.collectAsState()
    val signals by viewModel.signals.collectAsState()
    val paperTrades by viewModel.paperTrades.collectAsState()
    val strategies by viewModel.strategies.collectAsState()
    val indicatorParams by viewModel.indicatorParams.collectAsState()

    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val activeIndicators by viewModel.activeIndicators.collectAsState()
    val candles by viewModel.candles.collectAsState()

    val backtestConfig by viewModel.backtestConfig.collectAsState()
    val isBacktesting by viewModel.isBacktesting.collectAsState()
    val backtestResult by viewModel.backtestResult.collectAsState()

    val builderName by viewModel.builderStrategyName.collectAsState()
    val builderDesc by viewModel.builderDescription.collectAsState()
    val builderAction by viewModel.builderAction.collectAsState()
    val builderExpiry by viewModel.builderExpiry.collectAsState()
    val builderConditions by viewModel.builderConditions.collectAsState()

    // Trade Dialog State
    val tradeDialogAsset by viewModel.tradeDialogAsset.collectAsState()
    val tradeDialogDirection by viewModel.tradeDialogDirection.collectAsState()
    val tradeDialogStake by viewModel.tradeDialogStake.collectAsState()
    val tradeDialogExpiry by viewModel.tradeDialogExpiry.collectAsState()

    val toastMessage by viewModel.tradeToastMessage.collectAsState()

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBg),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            SignalLabTopHeader(
                virtualBalance = virtualBalance,
                onBalanceClick = { currentTab = ScreenTab.SETTINGS },
                modifier = Modifier.statusBarsPadding()
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = TerminalSurface,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder)
            ) {
                ScreenTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (currentTab != tab) {
                                android.util.Log.d("SignalLab", "[SignalLab] NAVIGATION_TAB_CHANGED: to ${tab.name}")
                                currentTab = tab
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TerminalCyan,
                            selectedTextColor = TerminalCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = TerminalSurfaceHighlight
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalBg)
        ) {
            Crossfade(targetState = currentTab, label = "screen_transition") { tab ->
                when (tab) {
                    ScreenTab.DASHBOARD -> DashboardScreen(
                        stats = dashboardStats,
                        topSignals = signals,
                        activeTrades = paperTrades,
                        onNavigateToBacktest = { currentTab = ScreenTab.BACKTEST },
                        onNavigateToSignals = { currentTab = ScreenTab.SIGNALS },
                        onNavigateToMarkets = { currentTab = ScreenTab.MARKETS },
                        onSimulateSignal = { sig ->
                            viewModel.openTradeDialog(sig.asset, sig.direction, sig.expirySeconds)
                        },
                        onResetBalance = { viewModel.resetBalance(10000.0) },
                        onAddFunds = { viewModel.addFunds(5000.0) }
                    )

                    ScreenTab.MARKETS -> MarketsScreen(
                        selectedAsset = selectedAsset,
                        selectedTimeframe = selectedTimeframe,
                        candles = candles,
                        activeIndicators = activeIndicators,
                        onSelectAsset = viewModel::selectAsset,
                        onSelectTimeframe = viewModel::selectTimeframe,
                        onToggleIndicator = viewModel::toggleIndicator,
                        onOpenTradeDialog = { asset, dir -> viewModel.openTradeDialog(asset, dir, 45) }
                    )

                    ScreenTab.CAMERA -> CameraScannerScreen()

                    ScreenTab.BACKTEST -> BacktestScreen(
                        config = backtestConfig,
                        strategies = strategies,
                        isBacktesting = isBacktesting,
                        result = backtestResult,
                        onConfigChange = viewModel::updateBacktestConfig,
                        onRunBacktest = viewModel::runBacktest
                    )

                    ScreenTab.STRATEGIES -> StrategiesScreen(
                        strategies = strategies,
                        indicatorParams = indicatorParams,
                        builderName = builderName,
                        builderDescription = builderDesc,
                        builderAction = builderAction,
                        builderExpiry = builderExpiry,
                        builderConditions = builderConditions,
                        onNameChange = viewModel::setBuilderName,
                        onDescriptionChange = viewModel::setBuilderDescription,
                        onActionChange = viewModel::setBuilderAction,
                        onExpiryChange = viewModel::setBuilderExpiry,
                        onAddCondition = viewModel::addBuilderCondition,
                        onRemoveCondition = viewModel::removeBuilderCondition,
                        onUpdateCondition = viewModel::updateBuilderCondition,
                        onSaveStrategy = { viewModel.saveBuilderStrategy() },
                        onTestInBacktest = { stratId ->
                            viewModel.updateBacktestConfig(backtestConfig.copy(strategyId = stratId))
                            currentTab = ScreenTab.BACKTEST
                        },
                        onDeleteStrategy = viewModel::deleteStrategy,
                        onUpdateIndicatorParams = viewModel::updateIndicatorParameters,
                        onResetIndicatorParams = viewModel::resetIndicatorParameters
                    )

                    ScreenTab.SIGNALS -> SignalsScreen(
                        signals = signals,
                        onSimulateSignal = { sig ->
                            viewModel.openTradeDialog(sig.asset, sig.direction, sig.expirySeconds)
                        }
                    )

                    ScreenTab.SETTINGS -> SettingsScreen(
                        virtualBalance = virtualBalance,
                        onResetBalance = viewModel::resetBalance,
                        onAddFunds = viewModel::addFunds
                    )
                }
            }

            // Paper Trade Simulated Execution Sheet
            if (tradeDialogAsset != null) {
                PaperTradeDialog(
                    asset = tradeDialogAsset!!,
                    currentPrice = viewModel.candles.value.lastOrNull()?.close ?: tradeDialogAsset!!.basePrice,
                    direction = tradeDialogDirection,
                    stakeText = tradeDialogStake,
                    expirySeconds = tradeDialogExpiry,
                    virtualBalance = virtualBalance,
                    payoutPercentage = 85.0,
                    onDirectionChange = viewModel::setTradeDialogDirection,
                    onStakeChange = viewModel::setTradeDialogStake,
                    onExpiryChange = viewModel::setTradeDialogExpiry,
                    onExecuteTrade = viewModel::executeSimulatedTrade,
                    onDismiss = viewModel::closeTradeDialog
                )
            }
        }
    }
}
