package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed

enum class Asset(
    val code: String,
    val displayName: String,
    val basePrice: Double,
    val decimals: Int,
    val category: String,
    val dailyChange: Double
) {
    EUR_USD("EUR/USD", "Euro / US Dollar", 1.08450, 5, "Forex Major", +0.32),
    GBP_USD("GBP/USD", "British Pound / USD", 1.27180, 5, "Forex Major", -0.18),
    USD_JPY("USD/JPY", "US Dollar / Japanese Yen", 154.620, 3, "Forex Major", +0.45),
    BTC_USD("BTC/USD", "Bitcoin / USD", 68420.00, 2, "Crypto", +2.84),
    ASIA_COMPOSITE("ASIA_X", "Asia Composite Index", 1000.00, 2, "Composite Index", 0.0),
    CRYPTO_COMPOSITE("CRYPTO_X", "Crypto Composite Index", 32125.00, 2, "Composite Index", 0.0),
    EUROPE_COMPOSITE("EUROPE_X", "Europe Composite Index", 1000.00, 2, "Composite Index", 0.0),
    COMPOUND_INDEX("COMPOUND_X", "Compound Index", 1000.00, 2, "Composite Index", 0.0);

    fun formatPrice(price: Double): String {
        return "%.${decimals}f".format(price)
    }
}

enum class Timeframe(val label: String, val minutes: Int, val seconds: Int) {
    S5("5s", 0, 5),
    S15("15s", 0, 15),
    S30("30s", 0, 30),
    M1("1m", 1, 60),
    M5("5m", 5, 300),
    M15("15m", 15, 900),
    M30("30m", 30, 1800),
    H1("1H", 60, 3600)
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val isBullish: Boolean get() = close >= open
    val color: Color get() = if (isBullish) NeonGreen else NeonRed
}

enum class IndicatorType(val label: String, val shortName: String, val isOscillator: Boolean) {
    EMA("Exponential MA", "EMA", false),
    SMA("Simple MA", "SMA", false),
    RSI("Relative Strength Index", "RSI", true),
    MACD("MACD", "MACD", true),
    BOLLINGER("Bollinger Bands", "BB", false),
    ADX("Average Directional Index", "ADX", true),
    STOCHASTIC("Stochastic Oscillator", "STOCH", true),
    SUPERTREND("Supertrend", "ST", false)
}

enum class SignalDirection(val label: String, val arrow: String) {
    CALL("CALL", "↗"),
    PUT("PUT", "↘");

    val isCall: Boolean get() = this == CALL
}

enum class SignalStatus {
    ACTIVE,
    TRIGGERED,
    EXPIRED
}

data class SignalItem(
    val id: String,
    val asset: Asset,
    val direction: SignalDirection,
    val expiryMinutes: Int,
    val expirySeconds: Int = expiryMinutes * 60,
    val score: Int, // 0-100
    val conditions: List<String>,
    val sampleCount: Int,
    val historicalWinRate: Double,
    val timestampFormatted: String,
    val currentPrice: Double,
    val sourceLabel: String = "DEMO DATA ONLY",
    val status: SignalStatus = SignalStatus.ACTIVE
)

enum class ConditionOperator(val displayName: String, val symbol: String) {
    ABOVE("ABOVE", ">"),
    BELOW("BELOW", "<"),
    CROSSES_ABOVE("CROSSES ABOVE", "⤊"),
    CROSSES_BELOW("CROSSES BELOW", "⤋"),
    BETWEEN("BETWEEN", "⇋")
}

data class StrategyCondition(
    val id: String,
    val indicatorA: String, // e.g. "EMA 9", "RSI 14"
    val operator: ConditionOperator,
    val indicatorB: String // e.g. "EMA 21", "50", "30", "Supertrend"
)

data class IndicatorParameters(
    val emaFastPeriod: Int = 9,
    val emaSlowPeriod: Int = 21,
    val smaPeriod: Int = 20,
    val rsiPeriod: Int = 14,
    val rsiOverbought: Double = 70.0,
    val rsiOversold: Double = 30.0,
    val rsiMidline: Double = 50.0,
    val macdFast: Int = 12,
    val macdSlow: Int = 26,
    val macdSignal: Int = 9,
    val bollingerPeriod: Int = 20,
    val bollingerMultiplier: Double = 2.0,
    val adxPeriod: Int = 14,
    val adxThreshold: Double = 25.0,
    val supertrendPeriod: Int = 10,
    val supertrendMultiplier: Double = 3.0,
    val defaultExpiryMinutes: Int = 5
)

enum class ExecutionRule(val displayName: String, val shortLabel: String) {
    NEXT_CANDLE_OPEN("Next Candle Open (Zero Lookahead)", "Next Open"),
    SIGNAL_CANDLE_CLOSE("Signal Candle Close", "Candle Close");

    val label: String get() = shortLabel
}

data class TradingStrategy(
    val id: String,
    val name: String,
    val description: String,
    val conditions: List<StrategyCondition>,
    val action: SignalDirection,
    val expiryMinutes: Int,
    val isPrebuilt: Boolean = false,
    val winRateEstimate: Double = 65.0,
    val customParams: IndicatorParameters = IndicatorParameters()
)

data class BacktestConfig(
    val asset: Asset = Asset.EUR_USD,
    val timeframe: Timeframe = Timeframe.M5,
    val expiryMinutes: Int = 5,
    val expirySeconds: Int? = null,
    val dateRangeLabel: String = "Last 30 Days",
    val strategyId: String = "strat_ema_rsi_call",
    val startingBalance: Double = 10000.0,
    val stakeAmount: Double = 500.0,
    val payoutPercentage: Double = 85.0,
    val executionRule: ExecutionRule = ExecutionRule.NEXT_CANDLE_OPEN
)

enum class TradeOutcome(val label: String) {
    WIN("WIN"),
    LOSS("LOSS"),
    DRAW("DRAW");

    companion object {
        val TIE = DRAW
    }
}

data class BacktestTrade(
    val id: Int,
    val asset: Asset = Asset.EUR_USD,
    val timeframe: Timeframe = Timeframe.M5,
    val strategy: String = "",
    val direction: SignalDirection,
    val executionRule: ExecutionRule = ExecutionRule.NEXT_CANDLE_OPEN,
    val signalTimestamp: Long = 0L,
    val signalTimeFormatted: String = "",
    val entryTimestamp: Long = 0L,
    val entryTimeFormatted: String = "",
    val entryPrice: Double,
    val expiryTimestamp: Long = 0L,
    val expiryTimeFormatted: String = "",
    val exitPrice: Double,
    val stake: Double,
    val payoutRate: Double = 0.85,
    val payout: Double,
    val pnl: Double,
    val outcome: TradeOutcome,
    val balanceAfter: Double,
    val expiryMinutes: Int = 5,
    val expirySeconds: Int? = null,
    val timeFormatted: String = "",
    val indicators: Map<String, Double> = emptyMap(),
    val reasons: List<String> = emptyList()
) {
    val timestamp: Long get() = entryTimestamp
    val result: TradeOutcome get() = outcome
}

data class BacktestAuditInfo(
    val candlesLoaded: Int = 0,
    val firstCandleTime: String = "",
    val lastCandleTime: String = "",
    val validIndicatorCandles: Int = 0,
    val signalsGenerated: Int = 0,
    val tradesExecuted: Int = 0,
    val skippedSignals: Int = 0,
    val skippedReasons: Map<String, Int> = emptyMap(),
    val callSignalsCount: Int = 0,
    val putSignalsCount: Int = 0,
    val pushResultsCount: Int = 0,
    val validationChecks: List<String> = emptyList(),
    val lookaheadProtectionVerified: Boolean = true
)

data class BacktestResult(
    val config: BacktestConfig,
    val strategyName: String,
    val startDateMs: Long = 0L,
    val endDateMs: Long = 0L,
    val isRealData: Boolean = false,
    val dataBadgeLabel: String = if (isRealData) "HISTORICAL DATA" else "DEMO DATA ONLY",
    val startingBalance: Double = config.startingBalance,
    val finalBalance: Double = config.startingBalance,
    val totalTrades: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val winRate: Double,
    val grossProfit: Double = 0.0,
    val grossLoss: Double = 0.0,
    val netPnl: Double,
    val netPnlPercentage: Double,
    val roiPercentage: Double = netPnlPercentage,
    val maxDrawdownPercentage: Double,
    val maxWinningStreak: Int = 0,
    val maxLosingStreak: Int = 0,
    val avgPnlPerTrade: Double = 0.0,
    val avgWinningTrade: Double = 0.0,
    val avgLosingTrade: Double = 0.0,
    val profitFactor: Double,
    val returnPercent: Double = netPnlPercentage,
    val equityCurve: List<Double>,
    val trades: List<BacktestTrade>,
    val auditInfo: BacktestAuditInfo = BacktestAuditInfo(),
    val validationPassed: Boolean = true,
    val errorMessage: String? = null
) {
    val winningTrades: Int get() = wins
    val losingTrades: Int get() = losses
    val drawTrades: Int get() = draws
    val ties: Int get() = draws
    val pushes: Int get() = draws
    val averagePnL: Double get() = avgPnlPerTrade
    val averageWin: Double get() = avgWinningTrade
    val averageLoss: Double get() = avgLosingTrade
}

enum class PaperTradeStatus {
    ACTIVE,
    WON,
    LOST
}

data class PaperTrade(
    val id: String,
    val asset: Asset,
    val direction: SignalDirection,
    val entryPrice: Double,
    val exitPrice: Double? = null,
    val stake: Double,
    val payoutPercentage: Double,
    val expiryMinutes: Int,
    val expirySeconds: Int = expiryMinutes * 60,
    val remainingSeconds: Int,
    val totalSeconds: Int,
    val startTimeFormatted: String,
    val status: PaperTradeStatus,
    val pnl: Double = 0.0
)
