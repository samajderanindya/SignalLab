package com.example.data.engine

import com.example.data.model.Asset
import com.example.data.model.IndicatorParameters
import com.example.data.model.SignalDirection
import com.example.data.model.Timeframe
import kotlin.math.roundToInt

/** Result of one fast-market evaluation. */
data class FastSignal(
    val asset: Asset,
    val timeframe: Timeframe,
    val expirySeconds: Int,
    val direction: SignalDirection?,
    val score: Int,
    val reasons: List<String>,
    val source: String
)

/**
 * Conservative multi-indicator scorer for 5/15/30-second markets.
 * It deliberately returns null direction when confluence is weak; it is not a
 * guarantee of profitability and should only be promoted to LIVE after validation
 * against the broker's own quote stream.
 */
class FastSignalEngine(private val params: IndicatorParameters = IndicatorParameters()) {
    fun evaluate(asset: Asset, timeframe: Timeframe, candles: List<com.example.data.model.Candle>, source: String): FastSignal {
        if (candles.size < 35) {
            return FastSignal(asset, timeframe, expiryFor(timeframe), null, 0,
                listOf("Insufficient candles for a stable fast-market decision"), source)
        }
        val i = candles.lastIndex
        val emaFast = TechnicalIndicators.calculateEMA(candles, params.emaFastPeriod)
        val emaSlow = TechnicalIndicators.calculateEMA(candles, params.emaSlowPeriod)
        val rsi = TechnicalIndicators.calculateRSI(candles, params.rsiPeriod)
        val macd = TechnicalIndicators.calculateMACD(candles, params.macdFast, params.macdSlow, params.macdSignal)
        val st = TechnicalIndicators.calculateSupertrend(candles, params.supertrendPeriod, params.supertrendMultiplier)
        val adx = TechnicalIndicators.calculateADX(candles, params.adxPeriod)

        var bull = 0
        var bear = 0
        val reasons = mutableListOf<String>()
        if ((emaFast[i] ?: 0.0) > (emaSlow[i] ?: 0.0)) { bull++; reasons += "EMA trend bullish" } else { bear++; reasons += "EMA trend bearish" }
        if ((rsi[i] ?: 50.0) >= 50.0) { bull++; reasons += "RSI momentum above 50" } else { bear++; reasons += "RSI momentum below 50" }
        if ((macd.histogram[i] ?: 0.0) > 0.0) { bull++; reasons += "MACD histogram positive" } else { bear++; reasons += "MACD histogram negative" }
        if (st.isBullish[i] == true) { bull++; reasons += "Supertrend bullish" } else { bear++; reasons += "Supertrend bearish" }
        if ((adx.adx[i] ?: 0.0) >= params.adxThreshold) reasons += "ADX confirms trend strength"

        val edge = kotlin.math.abs(bull - bear)
        val score = (50 + edge * 10 + if ((adx.adx[i] ?: 0.0) >= params.adxThreshold) 5 else 0).coerceIn(0, 95)
        val direction = when {
            bull >= 3 && bull > bear -> SignalDirection.CALL
            bear >= 3 && bear > bull -> SignalDirection.PUT
            else -> null
        }
        return FastSignal(asset, timeframe, expiryFor(timeframe), direction, score, reasons, source)
    }

    private fun expiryFor(timeframe: Timeframe): Int = when (timeframe) {
        Timeframe.S5 -> 15
        Timeframe.S15 -> 30
        Timeframe.S30 -> 45
        else -> 60
    }
}
