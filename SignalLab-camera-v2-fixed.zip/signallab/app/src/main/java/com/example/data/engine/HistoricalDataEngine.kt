package com.example.data.engine

import com.example.data.model.Asset
import com.example.data.model.Candle
import com.example.data.model.Timeframe
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Clean data provider abstraction for obtaining OHLCV historical candles.
 */
interface HistoricalDataProvider {
    val name: String
    val isRealData: Boolean

    fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        count: Int,
        endTimeMs: Long = System.currentTimeMillis()
    ): List<Candle>

    fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        startDateMs: Long,
        endDateMs: Long
    ): List<Candle>
}

/**
 * Deterministic Demo Historical Data Provider.
 * Generates continuous, realistic OHLCV market candle series using deterministic mathematical seed paths.
 * Explicitly designated as DEMO DATA ONLY.
 */
class DeterministicDemoHistoricalDataProvider : HistoricalDataProvider {
    override val name: String = "Deterministic Demo Simulation Engine"
    override val isRealData: Boolean = false

    private fun stableHash(value: String): Long {
        var hash = 1125899906842597L
        for (ch in value) hash = hash * 31L + ch.code
        return hash
    }

    private fun gaussian(random: Random): Double {
        val u1 = random.nextDouble().coerceAtLeast(1e-12)
        val u2 = random.nextDouble()
        return sqrt(-2.0 * kotlin.math.ln(u1)) * cos(2.0 * Math.PI * u2)
    }

    override fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        count: Int,
        endTimeMs: Long
    ): List<Candle> {
        if (count <= 0) return emptyList()

        val stepMs = timeframe.seconds * 1000L
        val maxCount = HistoricalDataEngine.getCandleCountForRange("Last 90 Days", timeframe)
        val generatedCount = if (count < 5_000) count else max(count, maxCount)
        val dayAnchor = endTimeMs / (24L * 60L * 60L * 1000L)
        val seed = stableHash(asset.name) * 31L +
                stableHash(timeframe.name) * 17L +
                dayAnchor * 7L
        val random = Random(seed)

        val baseVolatility = when (asset) {
            Asset.BTC_USD -> 160.0
            Asset.USD_JPY -> 0.15
            Asset.GBP_USD -> 0.00075
            Asset.EUR_USD -> 0.00055
            Asset.ASIA_COMPOSITE, Asset.CRYPTO_COMPOSITE, Asset.EUROPE_COMPOSITE, Asset.COMPOUND_INDEX -> 2.5
        }
        val volatility = baseVolatility * kotlin.math.sqrt(timeframe.seconds.toDouble() / 60.0)

        // Generate one common deterministic history and return its suffix. This makes
        // Last 7/30/90 Days comparable: the shorter windows are genuine suffixes of
        // the same demo history instead of completely different seeded datasets.
        var currentPrice = asset.basePrice
        var previousReturn = 0.0
        var regime = if (random.nextBoolean()) 1.0 else -1.0
        val allCandles = ArrayList<Candle>(generatedCount)

        repeat(generatedCount) { i ->
            // Slow regime changes create realistic clustering without making the
            // next candle deterministically inferable from an indicator crossover.
            if (i > 0 && random.nextDouble() < (1.0 / 180.0)) {
                regime *= -1.0
            }

            val drift = regime * volatility * 0.10
            val shock = gaussian(random) * volatility * 0.65
            val returnComponent = previousReturn * 0.20 + drift + shock

            val open = currentPrice
            val close = (open + returnComponent).coerceAtLeast(0.00001)
            val upperWick = abs(gaussian(random)) * volatility * 0.45
            val lowerWick = abs(gaussian(random)) * volatility * 0.45
            val high = max(open, close) + upperWick
            val low = (min(open, close) - lowerWick).coerceAtLeast(0.00001)

            val baseVolume = when (asset) {
                Asset.BTC_USD -> 450.0
                Asset.USD_JPY -> 1200.0
                Asset.ASIA_COMPOSITE, Asset.CRYPTO_COMPOSITE, Asset.EUROPE_COMPOSITE, Asset.COMPOUND_INDEX -> 1500.0
                else -> 800.0
            }
            val volumeMultiplier = if (random.nextDouble() > 0.88) {
                2.2 + random.nextDouble() * 1.8
            } else {
                0.6 + random.nextDouble() * 0.8
            }

            allCandles.add(
                Candle(
                    timestamp = endTimeMs - (generatedCount - 1L - i) * stepMs,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = baseVolume * volumeMultiplier
                )
            )

            currentPrice = close
            previousReturn = returnComponent
        }

        return allCandles.takeLast(count)
    }

    override fun fetchCandles(
        asset: Asset,
        timeframe: Timeframe,
        startDateMs: Long,
        endDateMs: Long
    ): List<Candle> {
        val stepMs = timeframe.seconds * 1000L
        val count = max(10, ((endDateMs - startDateMs) / stepMs).toInt() + 1)
        return fetchCandles(asset, timeframe, count, endDateMs)
    }
}

/**
 * Historical Data Engine singleton that coordinates market data providers.
 */
object HistoricalDataEngine {

    private var currentProvider: HistoricalDataProvider = DeterministicDemoHistoricalDataProvider()

    fun setProvider(provider: HistoricalDataProvider) {
        currentProvider = provider
    }

    fun getProvider(): HistoricalDataProvider = currentProvider

    fun generateCandles(
        asset: Asset,
        timeframe: Timeframe,
        count: Int = 200,
        endTimeMs: Long = System.currentTimeMillis()
    ): List<Candle> {
        return currentProvider.fetchCandles(asset, timeframe, count, endTimeMs)
    }

    fun getCandleCountForRange(rangeLabel: String, timeframe: Timeframe): Int {
        // The previous implementation returned a few hundred candles for a
        // "7/30/90 day" range (for example, only 380 M5 candles for 30 days).
        // That made the UI label a dataset as 30 days while it actually
        // represented less than 32 hours. Generate the requested duration.
        val durationMs = getRangeDurationMs(rangeLabel)
        val stepMs = timeframe.seconds * 1000L
        return ((durationMs + stepMs - 1L) / stepMs).toInt() + 1
    }

    fun getRangeDurationMs(rangeLabel: String): Long {
        val dayMs = 24 * 60 * 60 * 1000L
        return when (rangeLabel) {
            "Last 7 Days" -> 7 * dayMs
            "Last 30 Days" -> 30 * dayMs
            "Last 90 Days" -> 90 * dayMs
            else -> 30 * dayMs
        }
    }
}
