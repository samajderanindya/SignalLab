package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.data.model.Candle
import com.example.data.model.IndicatorType
import com.example.ui.theme.IndicatorBollinger
import com.example.ui.theme.IndicatorEmaFast
import com.example.ui.theme.IndicatorEmaSlow
import com.example.ui.theme.IndicatorRsi
import com.example.ui.theme.IndicatorSupertrendGreen
import com.example.ui.theme.IndicatorSupertrendRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    candles: List<Candle>,
    asset: Asset,
    activeIndicators: Set<IndicatorType>,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(TerminalSurface),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading chart...", color = TextMuted)
        }
        return
    }

    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }
    val displayCandle = selectedCandleIndex?.let { candles.getOrNull(it) } ?: candles.lastOrNull()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        // Chart Live Details / OHLC Header
        if (displayCandle != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = asset.formatPrice(displayCandle.close),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (displayCandle.isBullish) NeonGreen else NeonRed
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OhlcItem(label = "O", value = asset.formatPrice(displayCandle.open))
                    Spacer(modifier = Modifier.width(6.dp))
                    OhlcItem(label = "H", value = asset.formatPrice(displayCandle.high))
                    Spacer(modifier = Modifier.width(6.dp))
                    OhlcItem(label = "L", value = asset.formatPrice(displayCandle.low))
                    Spacer(modifier = Modifier.width(6.dp))
                    OhlcItem(label = "C", value = asset.formatPrice(displayCandle.close))
                }
            }
        }

        // Active Indicator Pills
        if (activeIndicators.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                activeIndicators.forEach { ind ->
                    val color = when (ind) {
                        IndicatorType.EMA -> IndicatorEmaFast
                        IndicatorType.SMA -> IndicatorEmaSlow
                        IndicatorType.RSI -> IndicatorRsi
                        IndicatorType.BOLLINGER -> IndicatorBollinger
                        IndicatorType.SUPERTREND -> IndicatorSupertrendGreen
                        else -> TerminalCyan
                    }
                    Text(
                        text = "• ${ind.shortName}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = color,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Candlestick Canvas
        val showOscillator = activeIndicators.contains(IndicatorType.RSI) || activeIndicators.contains(IndicatorType.MACD) || activeIndicators.contains(IndicatorType.STOCHASTIC)
        val mainChartHeight = if (showOscillator) 180.dp else 240.dp

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(mainChartHeight)
        ) {
            val currentCandles by rememberUpdatedState(candles)
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val list = currentCandles
                            if (list.isNotEmpty()) {
                                val candleWidth = size.width / list.size
                                val index = (offset.x / candleWidth).toInt().coerceIn(0, list.size - 1)
                                selectedCandleIndex = index
                            }
                        }
                    }
            ) {
                drawMainCandlesticks(
                    candles = candles,
                    activeIndicators = activeIndicators,
                    selectedIndex = selectedCandleIndex
                )
            }
        }

        // Sub-chart for Oscillators (RSI / MACD)
        if (showOscillator) {
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(65.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurfaceVariant)
                    .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(6.dp))
                    .padding(4.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRsiSubchart(candles)
                }
            }
        }
    }
}

@Composable
private fun OhlcItem(label: String, value: String) {
    Row {
        Text(text = "$label:", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
        Spacer(modifier = Modifier.width(1.dp))
        Text(text = value, style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
    }
}

private fun DrawScope.drawMainCandlesticks(
    candles: List<Candle>,
    activeIndicators: Set<IndicatorType>,
    selectedIndex: Int?
) {
    if (candles.isEmpty()) return

    val minPrice = candles.minOf { it.low }
    val maxPrice = candles.maxOf { it.high }
    val priceRange = if (maxPrice - minPrice > 0) maxPrice - minPrice else 1.0

    val width = size.width
    val height = size.height
    val numCandles = candles.size
    val candleWidth = width / numCandles
    val bodyWidth = (candleWidth * 0.7f).coerceAtLeast(3f)

    fun priceToY(price: Double): Float {
        val normalized = (price - minPrice) / priceRange
        return (height - (normalized * (height - 20f) + 10f)).toFloat()
    }

    // Grid lines (horizontal)
    val gridSteps = 4
    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
    for (i in 0..gridSteps) {
        val y = (height / gridSteps) * i
        drawLine(
            color = TerminalBorderSubtle,
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = 1f,
            pathEffect = dashEffect
        )
    }

    // Indicator calculations: EMA 9 & EMA 21
    if (activeIndicators.contains(IndicatorType.EMA)) {
        drawEmaLine(candles, 9, IndicatorEmaFast, ::priceToY, candleWidth)
        drawEmaLine(candles, 21, IndicatorEmaSlow, ::priceToY, candleWidth)
    }

    // Bollinger Bands
    if (activeIndicators.contains(IndicatorType.BOLLINGER)) {
        drawBollingerOverlay(candles, ::priceToY, candleWidth)
    }

    // Candlesticks
    candles.forEachIndexed { i, candle ->
        val centerX = (i * candleWidth) + (candleWidth / 2f)
        val openY = priceToY(candle.open)
        val closeY = priceToY(candle.close)
        val highY = priceToY(candle.high)
        val lowY = priceToY(candle.low)

        val color = candle.color

        // Draw Wick
        drawLine(
            color = color,
            start = Offset(centerX, highY),
            end = Offset(centerX, lowY),
            strokeWidth = 1.5f
        )

        // Draw Body
        val bodyTop = min(openY, closeY)
        val bodyBottom = max(openY, closeY)
        val bodyHeight = max(2f, bodyBottom - bodyTop)

        drawRect(
            color = color,
            topLeft = Offset(centerX - (bodyWidth / 2f), bodyTop),
            size = Size(bodyWidth, bodyHeight)
        )

        // Selected candle highlight
        if (selectedIndex == i) {
            drawLine(
                color = TerminalCyan.copy(alpha = 0.5f),
                start = Offset(centerX, 0f),
                end = Offset(centerX, height),
                strokeWidth = 1f,
                pathEffect = dashEffect
            )
        }
    }

    // Current Price line
    val lastCandle = candles.last()
    val currentY = priceToY(lastCandle.close)
    drawLine(
        color = if (lastCandle.isBullish) NeonGreen else NeonRed,
        start = Offset(0f, currentY),
        end = Offset(width, currentY),
        strokeWidth = 1.5f,
        pathEffect = dashEffect
    )
}

private fun DrawScope.drawEmaLine(
    candles: List<Candle>,
    period: Int,
    color: Color,
    priceToY: (Double) -> Float,
    candleWidth: Float
) {
    if (candles.isEmpty()) return
    val k = 2.0 / (period + 1)
    var ema = candles.first().close
    val path = Path()

    candles.forEachIndexed { i, candle ->
        ema = (candle.close * k) + (ema * (1 - k))
        val x = (i * candleWidth) + (candleWidth / 2f)
        val y = priceToY(ema)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }

    drawPath(path = path, color = color, style = Stroke(width = 2f))
}

private fun DrawScope.drawBollingerOverlay(
    candles: List<Candle>,
    priceToY: (Double) -> Float,
    candleWidth: Float
) {
    if (candles.size < 5) return
    val upperPath = Path()
    val lowerPath = Path()

    val period = 14
    for (i in candles.indices) {
        val start = max(0, i - period + 1)
        val sub = candles.subList(start, i + 1)
        val mean = sub.map { it.close }.average()
        val variance = sub.map { (it.close - mean) * (it.close - mean) }.average()
        val std = kotlin.math.sqrt(variance)

        val upper = mean + (2.0 * std)
        val lower = mean - (2.0 * std)

        val x = (i * candleWidth) + (candleWidth / 2f)
        if (i == 0) {
            upperPath.moveTo(x, priceToY(upper))
            lowerPath.moveTo(x, priceToY(lower))
        } else {
            upperPath.lineTo(x, priceToY(upper))
            lowerPath.lineTo(x, priceToY(lower))
        }
    }

    drawPath(path = upperPath, color = IndicatorBollinger, style = Stroke(width = 1.5f))
    drawPath(path = lowerPath, color = IndicatorBollinger, style = Stroke(width = 1.5f))
}

private fun DrawScope.drawRsiSubchart(candles: List<Candle>) {
    if (candles.size < 2) return
    val width = size.width
    val height = size.height

    // Draw 70 Overbought and 30 Oversold reference lines
    val y70 = height * (1f - 0.70f)
    val y30 = height * (1f - 0.30f)
    val y50 = height * 0.5f

    val dash = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
    drawLine(color = NeonRed.copy(alpha = 0.5f), start = Offset(0f, y70), end = Offset(width, y70), strokeWidth = 1f, pathEffect = dash)
    drawLine(color = TextMuted.copy(alpha = 0.3f), start = Offset(0f, y50), end = Offset(width, y50), strokeWidth = 1f, pathEffect = dash)
    drawLine(color = NeonGreen.copy(alpha = 0.5f), start = Offset(0f, y30), end = Offset(width, y30), strokeWidth = 1f, pathEffect = dash)

    // Calculate synthetic RSI
    val rsiPath = Path()
    val candleWidth = width / candles.size
    var gains = 0.0
    var losses = 0.0
    val period = 14

    for (i in candles.indices) {
        val change = if (i > 0) candles[i].close - candles[i - 1].close else 0.0
        val gain = if (change > 0) change else 0.0
        val loss = if (change < 0) kotlin.math.abs(change) else 0.0

        val rsiVal: Double
        if (i < period) {
            gains += gain
            losses += loss
            rsiVal = 50.0
        } else {
            gains = (gains * (period - 1) + gain) / period
            losses = (losses * (period - 1) + loss) / period
            val rs = if (losses == 0.0) 100.0 else gains / losses
            rsiVal = (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
        }

        val x = (i * candleWidth) + (candleWidth / 2f)
        val y = height * (1f - (rsiVal.toFloat() / 100f))
        if (i == 0) rsiPath.moveTo(x, y) else rsiPath.lineTo(x, y)
    }

    drawPath(path = rsiPath, color = IndicatorRsi, style = Stroke(width = 2f))
}
