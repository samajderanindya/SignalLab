package com.example.data.engine

import com.example.data.model.Asset
import com.example.data.model.Candle
import com.example.data.model.Timeframe
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/**
 * Canonical tick emitted by a broker/terminal adapter.
 * Prices are intentionally kept as the broker quote; no external market is substituted.
 */
data class LiveTick(
    val asset: Asset,
    val timestampMs: Long,
    val price: Double,
    val source: String
)

enum class FeedState { DISCONNECTED, CONNECTING, LIVE, ERROR }

data class FeedStatus(
    val state: FeedState = FeedState.DISCONNECTED,
    val source: String = "No verified broker feed",
    val lastTickMs: Long = 0L,
    val message: String = "Waiting for a verified Olymp Trade quote stream"
)

/**
 * Adapter boundary for the real quote source. The UI/strategy layer only consumes
 * this interface, so a verified terminal feed can be connected without rewriting the app.
 */
interface LiveMarketFeed {
    val status: FeedStatus
    fun connect()
    fun disconnect()
    fun submitTick(tick: LiveTick)
    fun latestPrice(asset: Asset): Double?
    fun snapshot(asset: Asset, timeframe: Timeframe, count: Int): List<Candle>
}

/**
 * In-memory feed used by the terminal bridge. It never invents a price: a candle only
 * changes when submitTick() receives an actual quote. Until a verified adapter is attached,
 * status remains DISCONNECTED and the app must not label generated data as live.
 */
class TerminalBridgeFeed : LiveMarketFeed {
    @Volatile
    private var _status = FeedStatus()
    override val status: FeedStatus get() = _status

    private val ticks = ConcurrentHashMap<Asset, MutableList<LiveTick>>()

    override fun connect() {
        _status = FeedStatus(FeedState.CONNECTING, "Terminal bridge", message = "Connecting to terminal quote bridge…")
    }

    override fun disconnect() {
        _status = FeedStatus(FeedState.DISCONNECTED, "Terminal bridge", message = "Terminal quote bridge disconnected")
    }

    override fun submitTick(tick: LiveTick) {
        val list = ticks.getOrPut(tick.asset) { mutableListOf() }
        synchronized(list) {
            list.add(tick)
            while (list.size > 20_000) list.removeAt(0)
        }
        _status = FeedStatus(FeedState.LIVE, tick.source, tick.timestampMs, "Live broker quote received")
    }

    override fun latestPrice(asset: Asset): Double? {
        val source = ticks[asset] ?: return null
        return synchronized(source) { source.lastOrNull()?.price }
    }

    override fun snapshot(asset: Asset, timeframe: Timeframe, count: Int): List<Candle> {
        val source = ticks[asset] ?: return emptyList()
        val copy = synchronized(source) { source.toList() }
            .sortedBy { it.timestampMs }
        if (copy.isEmpty()) return emptyList()

        val bucketMs = timeframe.seconds * 1000L
        val buckets = LinkedHashMap<Long, MutableList<LiveTick>>()
        for (tick in copy) {
            val bucket = (tick.timestampMs / bucketMs) * bucketMs
            buckets.getOrPut(bucket) { mutableListOf() }.add(tick)
        }

        return buckets.entries.takeLast(max(1, count)).map { (bucket, group) ->
            val first = group.first().price
            val last = group.last().price
            Candle(
                timestamp = bucket,
                open = first,
                high = group.maxOf { it.price },
                low = group.minOf { it.price },
                close = last,
                volume = group.size.toDouble()
            )
        }
    }
}
