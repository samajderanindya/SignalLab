package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal Dark Theme Palette
val TerminalBlack = Color(0xFF07090E)
val TerminalBg = Color(0xFF0B0F17)
val TerminalSurface = Color(0xFF121824)
val TerminalSurfaceVariant = Color(0xFF1A2332)
val TerminalSurfaceHighlight = Color(0xFF243044)
val TerminalBorder = Color(0xFF26354A)
val TerminalBorderSubtle = Color(0xFF1E2B3E)

// Trading Action Colors
val NeonGreen = Color(0xFF00E676)
val NeonGreenDark = Color(0xFF00B050)
val NeonGreenGlow = Color(0x3300E676)

val NeonRed = Color(0xFFFF3B56)
val NeonRedDark = Color(0xFFD32F2F)
val NeonRedGlow = Color(0x33FF3B56)

val TerminalCyan = Color(0xFF00E5FF)
val TerminalCyanGlow = Color(0x3300E5FF)

val TerminalAmber = Color(0xFFFFB300)
val TerminalPurple = Color(0xFF9D4EDD)
val TerminalBlue = Color(0xFF2979FF)

// Text Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextDisabled = Color(0xFF475569)

// Chart Indicator Line Colors
val IndicatorEmaFast = Color(0xFF00E5FF)
val IndicatorEmaSlow = Color(0xFFFFB300)
val IndicatorRsi = Color(0xFFB388FF)
val IndicatorMacd = Color(0xFF00E676)
val IndicatorMacdSignal = Color(0xFFFF3B56)
val IndicatorBollinger = Color(0x8829B6F6)
val IndicatorSupertrendGreen = Color(0xFF00E676)
val IndicatorSupertrendRed = Color(0xFFFF3B56)
