package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Asset
import com.example.data.model.BacktestConfig
import com.example.data.model.BacktestResult
import com.example.data.model.Candle
import com.example.data.model.ConditionOperator
import com.example.data.model.IndicatorParameters
import com.example.data.model.IndicatorType
import com.example.data.model.PaperTrade
import com.example.data.model.PaperTradeStatus
import com.example.data.model.SignalDirection
import com.example.data.model.SignalItem
import com.example.data.model.StrategyCondition
import com.example.data.model.Timeframe
import com.example.data.model.TradingStrategy
import com.example.data.repository.TradingRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID
import kotlin.random.Random

data class DashboardStats(
    val virtualBalance: Double,
    val todayPnl: Double,
    val todayPnlPercentage: Double,
    val winRate: Double,
    val totalTradesCount: Int,
    val activeTradesCount: Int
)

class SignalLabViewModel(
    private val repository: TradingRepository = TradingRepository()
) : ViewModel() {

    // Virtual Balance & Trades
    val virtualBalance: StateFlow<Double> = repository.virtualBalance
    val paperTrades: StateFlow<List<PaperTrade>> = repository.paperTrades
    val strategies: StateFlow<List<TradingStrategy>> = repository.strategies
    val signals: StateFlow<List<SignalItem>> = repository.signals
    val indicatorParams: StateFlow<IndicatorParameters> = repository.indicatorParams

    // Markets Screen State
    private val _selectedAsset = MutableStateFlow(Asset.CRYPTO_COMPOSITE)
    val selectedAsset: StateFlow<Asset> = _selectedAsset.asStateFlow()

    private val _selectedTimeframe = MutableStateFlow(Timeframe.S5)
    val selectedTimeframe: StateFlow<Timeframe> = _selectedTimeframe.asStateFlow()

    private val _activeIndicators = MutableStateFlow(setOf(IndicatorType.EMA, IndicatorType.RSI, IndicatorType.SUPERTREND))
    val activeIndicators: StateFlow<Set<IndicatorType>> = _activeIndicators.asStateFlow()

    private val _candles = MutableStateFlow<List<Candle>>(emptyList())
    val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

    // Backtest Screen State
    private val _backtestConfig = MutableStateFlow(BacktestConfig())
    val backtestConfig: StateFlow<BacktestConfig> = _backtestConfig.asStateFlow()

    private val _isBacktesting = MutableStateFlow(false)
    val isBacktesting: StateFlow<Boolean> = _isBacktesting.asStateFlow()

    private val _backtestResult = MutableStateFlow<BacktestResult?>(null)
    val backtestResult: StateFlow<BacktestResult?> = _backtestResult.asStateFlow()

    // Strategy Builder State
    private val _builderStrategyName = MutableStateFlow("Custom Momentum Flow")
    val builderStrategyName: StateFlow<String> = _builderStrategyName.asStateFlow()

    private val _builderDescription = MutableStateFlow("High probability custom setup based on multi-indicator alignment.")
    val builderDescription: StateFlow<String> = _builderDescription.asStateFlow()

    private val _builderAction = MutableStateFlow(SignalDirection.CALL)
    val builderAction: StateFlow<SignalDirection> = _builderAction.asStateFlow()

    private val _builderExpiry = MutableStateFlow(5)
    val builderExpiry: StateFlow<Int> = _builderExpiry.asStateFlow()

    private val _builderConditions = MutableStateFlow<List<StrategyCondition>>(
        listOf(
            StrategyCondition("b1", "EMA 9", ConditionOperator.ABOVE, "EMA 21"),
            StrategyCondition("b2", "RSI 14", ConditionOperator.ABOVE, "50")
        )
    )
    val builderConditions: StateFlow<List<StrategyCondition>> = _builderConditions.asStateFlow()

    // Trade Dialog State
    private val _tradeDialogAsset = MutableStateFlow<Asset?>(null)
    val tradeDialogAsset: StateFlow<Asset?> = _tradeDialogAsset.asStateFlow()

    private val _tradeDialogDirection = MutableStateFlow(SignalDirection.CALL)
    val tradeDialogDirection: StateFlow<SignalDirection> = _tradeDialogDirection.asStateFlow()

    private val _tradeDialogStake = MutableStateFlow("500")
    val tradeDialogStake: StateFlow<String> = _tradeDialogStake.asStateFlow()

    private val _tradeDialogExpiry = MutableStateFlow(45)
    val tradeDialogExpiry: StateFlow<Int> = _tradeDialogExpiry.asStateFlow()

    private val _tradeToastMessage = MutableStateFlow<String?>(null)
    val tradeToastMessage: StateFlow<String?> = _tradeToastMessage.asStateFlow()

    // Aggregated Dashboard Stats
    val dashboardStats: StateFlow<DashboardStats> = combine(
        virtualBalance,
        paperTrades
    ) { balance, trades ->
        val finishedTrades = trades.filter { it.status != PaperTradeStatus.ACTIVE }
        val wonTrades = finishedTrades.count { it.status == PaperTradeStatus.WON }
        val winRate = if (finishedTrades.isNotEmpty()) (wonTrades.toDouble() / finishedTrades.size) * 100.0 else 68.4
        val totalPnl = finishedTrades.sumOf { it.pnl }
        val initialBal = 10000.0
        val pnlPct = if (initialBal > 0) (totalPnl / initialBal) * 100.0 else 0.0

        DashboardStats(
            virtualBalance = balance,
            todayPnl = if (finishedTrades.isEmpty()) 1450.0 else totalPnl,
            todayPnlPercentage = if (finishedTrades.isEmpty()) 14.5 else pnlPct,
            winRate = winRate,
            totalTradesCount = if (finishedTrades.isEmpty()) 19 else trades.size,
            activeTradesCount = trades.count { it.status == PaperTradeStatus.ACTIVE }
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DashboardStats(10000.0, 1450.0, 14.5, 68.4, 19, 0)
    )

    // Backtest Job & Generation ID for Cancellation
    private var backtestJob: Job? = null
    private var backtestRunId: Long = 0L

    init {
        com.example.data.engine.OlympTradeAccessibilityService.setRequestedAsset(_selectedAsset.value)
        loadMarketData()
        startRealtimeTicker()
    }

    private fun startRealtimeTicker() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                // 1. Tick paper trade timers
                repository.tickActiveTrades()

                // 2. Update the selected market. Never synthesize price movement
                // when a verified Olymp Trade terminal feed is active.
                val currentAsset = _selectedAsset.value
                val feed = com.example.data.engine.OlympTradeAccessibilityService.feed
                val livePrice = feed.latestPrice(currentAsset)
                // Never manufacture a price in live-terminal mode. The only
                // authoritative market price is the quote observed from the
                // Olymp Trade terminal accessibility bridge.
                if (livePrice != null) {
                    repository.updateAssetPrice(currentAsset, livePrice)
                }

                // Rebuild the visible candles directly from the observed
                // terminal ticks. This keeps OHLC aggregation consistent with
                // the quote stream and never injects synthetic prices.
                if (livePrice != null) {
                    _candles.value = feed.snapshot(
                        currentAsset,
                        _selectedTimeframe.value,
                        45
                    )
                }
                if (System.currentTimeMillis() % 3_000L < 1_100L) {
                    repository.refreshSignals()
                }
            }
        }
    }

    fun selectAsset(asset: Asset) {
        _selectedAsset.value = asset
        com.example.data.engine.OlympTradeAccessibilityService.setRequestedAsset(asset)
        loadMarketData()
    }

    fun selectTimeframe(timeframe: Timeframe) {
        _selectedTimeframe.value = timeframe
        loadMarketData()
    }

    fun toggleIndicator(indicator: IndicatorType) {
        val current = _activeIndicators.value.toMutableSet()
        if (current.contains(indicator)) {
            current.remove(indicator)
        } else {
            current.add(indicator)
        }
        _activeIndicators.value = current
    }

    fun loadMarketData() {
        val asset = _selectedAsset.value
        val tf = _selectedTimeframe.value
        com.example.data.engine.OlympTradeAccessibilityService.setRequestedAsset(asset)
        _candles.value = repository.generateCandles(asset, tf, 45)
    }

    // Backtest actions
    fun updateBacktestConfig(newConfig: BacktestConfig) {
        android.util.Log.d("SignalLab", "[SignalLab] parameters changed: asset=${newConfig.asset.code}, tf=${newConfig.timeframe.label}, expiry=${newConfig.expiryMinutes}m, rule=${newConfig.executionRule.label}, strat=${newConfig.strategyId}, range=${newConfig.dateRangeLabel}, stake=${newConfig.stakeAmount}, bal=${newConfig.startingBalance}")
        _backtestConfig.value = newConfig
    }

    fun runBacktest() {
        android.util.Log.d("SignalLab", "[SignalLab] BACKTEST_BUTTON_CLICK")
        if (_isBacktesting.value) {
            android.util.Log.d("SignalLab", "[SignalLab] BACKTEST_IGNORED - execution already in progress")
            return
        }

        // Cancel any previous in-flight backtest
        backtestJob?.cancel()
        val currentRunId = ++backtestRunId

        backtestJob = viewModelScope.launch {
            _isBacktesting.value = true
            android.util.Log.d("SignalLab", "[SignalLab] BACKTEST_STARTED (runId=$currentRunId)")
            try {
                // Hard timeout mechanism (8 seconds max)
                withTimeout(30000L) {
                    val currentConfig = _backtestConfig.value
                    // Offload heavy calculation to Dispatchers.Default (background thread pool)
                    val res = withContext(Dispatchers.Default) {
                        repository.runBacktest(currentConfig)
                    }

                    if (currentRunId == backtestRunId) {
                        _backtestResult.value = res
                        android.util.Log.d("SignalLab", "[SignalLab] BACKTEST_STATE_UPDATED - trades=${res.totalTrades}, winRate=${"%.1f".format(res.winRate)}%, netPnl=${res.netPnl}")
                        if (res.errorMessage != null && res.totalTrades == 0) {
                            _tradeToastMessage.value = res.errorMessage
                        }
                    }
                }
            } catch (e: TimeoutCancellationException) {
                if (currentRunId == backtestRunId) {
                    android.util.Log.e("SignalLab", "[SignalLab] BACKTEST_TIMEOUT")
                    _tradeToastMessage.value = "Backtest timed out after 30 seconds. Try a shorter date range or timeframe."
                }
            } catch (e: CancellationException) {
                // Cleanly aborted by a newer run request
            } catch (e: Exception) {
                if (currentRunId == backtestRunId) {
                    android.util.Log.e("SignalLab", "[SignalLab] BACKTEST_ERROR: ${e.message}")
                    _tradeToastMessage.value = e.message ?: "Backtest simulation failed. Please retry."
                }
            } finally {
                // Guaranteed cleanup so button is never stuck
                if (currentRunId == backtestRunId) {
                    _isBacktesting.value = false
                    android.util.Log.d("SignalLab", "[SignalLab] BACKTEST_BUTTON_ENABLED")
                }
            }
        }
    }

    // Strategy Builder actions
    fun setBuilderName(name: String) { _builderStrategyName.value = name }
    fun setBuilderDescription(desc: String) { _builderDescription.value = desc }
    fun setBuilderAction(action: SignalDirection) { _builderAction.value = action }
    fun setBuilderExpiry(minutes: Int) { _builderExpiry.value = minutes }

    fun addBuilderCondition() {
        val newCondition = StrategyCondition(
            id = UUID.randomUUID().toString().take(6),
            indicatorA = "RSI 14",
            operator = ConditionOperator.ABOVE,
            indicatorB = "50"
        )
        _builderConditions.value = _builderConditions.value + newCondition
    }

    fun removeBuilderCondition(conditionId: String) {
        if (_builderConditions.value.size > 1) {
            _builderConditions.value = _builderConditions.value.filter { it.id != conditionId }
        }
    }

    fun updateBuilderCondition(index: Int, condition: StrategyCondition) {
        val list = _builderConditions.value.toMutableList()
        if (index in list.indices) {
            list[index] = condition
            _builderConditions.value = list
        }
    }

    fun saveBuilderStrategy(): String {
        val strategy = TradingStrategy(
            id = "strat_custom_${System.currentTimeMillis()}",
            name = _builderStrategyName.value.ifBlank { "Custom Strategy" },
            description = _builderDescription.value.ifBlank { "Custom user visual condition strategy." },
            conditions = _builderConditions.value,
            action = _builderAction.value,
            expiryMinutes = _builderExpiry.value,
            isPrebuilt = false,
            winRateEstimate = (62 + Random.nextInt(12)).toDouble()
        )
        repository.saveStrategy(strategy)
        _tradeToastMessage.value = "Strategy '${strategy.name}' saved successfully!"
        return strategy.id
    }

    fun updateIndicatorParameters(params: IndicatorParameters) {
        repository.updateIndicatorParameters(params)
    }

    fun resetIndicatorParameters() {
        repository.resetIndicatorParameters()
    }

    fun deleteStrategy(id: String) {
        repository.deleteStrategy(id)
    }

    // Paper trade actions
    fun openTradeDialog(asset: Asset, defaultDirection: SignalDirection = SignalDirection.CALL, defaultExpirySeconds: Int = 45) {
        _tradeDialogAsset.value = asset
        _tradeDialogDirection.value = defaultDirection
        _tradeDialogExpiry.value = defaultExpirySeconds
    }

    fun closeTradeDialog() {
        _tradeDialogAsset.value = null
    }

    fun setTradeDialogStake(stake: String) {
        _tradeDialogStake.value = stake.filter { it.isDigit() }
    }

    fun setTradeDialogDirection(direction: SignalDirection) {
        _tradeDialogDirection.value = direction
    }

    fun setTradeDialogExpiry(expirySeconds: Int) {
        _tradeDialogExpiry.value = expirySeconds
    }

    fun executeSimulatedTrade() {
        val asset = _tradeDialogAsset.value ?: return
        val stake = _tradeDialogStake.value.toDoubleOrNull() ?: 500.0
        val success = repository.placePaperTrade(
            asset = asset,
            direction = _tradeDialogDirection.value,
            stake = stake,
            expirySeconds = _tradeDialogExpiry.value,
            payoutPercentage = 85.0
        )
        if (success) {
            _tradeToastMessage.value = "Simulated ${_tradeDialogDirection.value.label} trade placed for ₹${stake.toInt()} on ${asset.code}"
            closeTradeDialog()
        } else {
            _tradeToastMessage.value = "Insufficient virtual balance for ₹${stake.toInt()} stake"
        }
    }

    fun resetBalance(newBalance: Double = 10000.0) {
        repository.resetVirtualBalance(newBalance)
        _tradeToastMessage.value = "Virtual balance reset to ₹${newBalance.toInt()}"
    }

    fun addFunds(amount: Double = 5000.0) {
        repository.addVirtualFunds(amount)
        _tradeToastMessage.value = "Added ₹${amount.toInt()} demo funds"
    }

    fun clearToast() {
        _tradeToastMessage.value = null
    }
}
