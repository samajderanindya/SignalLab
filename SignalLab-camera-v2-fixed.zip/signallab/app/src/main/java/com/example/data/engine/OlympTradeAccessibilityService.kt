package com.example.data.engine

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.model.Asset
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.abs

/**
 * Read-only terminal bridge.
 *
 * It observes the visible quote shown by the Olymp Trade terminal and converts
 * those observed quotes into ticks. It never clicks, swipes, submits orders, or
 * otherwise controls the terminal.
 */
class OlympTradeAccessibilityService : AccessibilityService() {
    companion object {
        val feed: TerminalBridgeFeed = TerminalBridgeFeed()

        @Volatile
        private var requestedAsset: Asset = Asset.CRYPTO_COMPOSITE

        private val pricePattern = Pattern.compile("(?<!\\d)(\\d{1,9}(?:[.,]\\d{1,8})?)(?!\\d)")

        fun setRequestedAsset(asset: Asset) {
            requestedAsset = asset
        }

        fun assetFromText(text: String): Asset? {
            val t = text.uppercase(Locale.US)
            return when {
                "EUR/USD" in t || "EUR_USD" in t || "EURO / US DOLLAR" in t -> Asset.EUR_USD
                "GBP/USD" in t || "GBP_USD" in t || "BRITISH POUND" in t -> Asset.GBP_USD
                "USD/JPY" in t || "USD_JPY" in t || "US DOLLAR / JAPANESE YEN" in t -> Asset.USD_JPY
                "BTC/USD" in t || "BTC_USD" in t || "BITCOIN / USD" in t -> Asset.BTC_USD
                "CRYPTO COMPOSITE" in t || "CRYPTO_X" in t -> Asset.CRYPTO_COMPOSITE
                "ASIA COMPOSITE" in t || "ASIA_X" in t -> Asset.ASIA_COMPOSITE
                "EUROPE COMPOSITE" in t || "EUROPE_X" in t -> Asset.EUROPE_COMPOSITE
                "COMPOUND INDEX" in t || "COMPOUND_X" in t -> Asset.COMPOUND_INDEX
                else -> null
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        feed.connect()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return

        val selected = requestedAsset
        val candidates = ArrayList<String>(128)
        collectText(root, candidates)

        val price = extractSelectedAssetPrice(candidates, selected) ?: return
        feed.submitTick(
            LiveTick(
                asset = selected,
                timestampMs = System.currentTimeMillis(),
                price = price,
                source = "Olymp Trade accessibility feed"
            )
        )
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectText(child, out)
                child.recycle()
            }
        }
    }

    /**
     * Prefer a number occurring in the same accessibility node as the selected
     * instrument. If the terminal exposes the instrument and quote as separate
     * sibling nodes, fall back to a nearby value using the instrument's known
     * price scale. This avoids accidentally ingesting the account balance or
     * payout percentage.
     */
    private fun extractSelectedAssetPrice(texts: List<String>, asset: Asset): Double? {
        val aliases = when (asset) {
            Asset.EUR_USD -> listOf("EUR/USD", "EUR_USD", "EURO / US DOLLAR", "EUR")
            Asset.GBP_USD -> listOf("GBP/USD", "GBP_USD", "BRITISH POUND", "GBP")
            Asset.USD_JPY -> listOf("USD/JPY", "USD_JPY", "JAPANESE YEN", "USD/JPY")
            Asset.BTC_USD -> listOf("BTC/USD", "BTC_USD", "BITCOIN / USD", "BITCOIN")
            Asset.ASIA_COMPOSITE -> listOf("ASIA_X", "ASIA COMPOSITE")
            Asset.CRYPTO_COMPOSITE -> listOf("CRYPTO_X", "CRYPTO COMPOSITE")
            Asset.EUROPE_COMPOSITE -> listOf("EUROPE_X", "EUROPE COMPOSITE")
            Asset.COMPOUND_INDEX -> listOf("COMPOUND_X", "COMPOUND INDEX")
        }

        val upperTexts = texts.map { it.uppercase(Locale.US) }
        val matchingIndices = upperTexts.indices.filter { i ->
            aliases.any { alias -> upperTexts[i].contains(alias) }
        }

        for (i in matchingIndices) {
            val direct = numberFromText(texts[i])
            if (direct != null && looksLikeQuote(direct, asset)) return direct

            for (j in maxOf(0, i - 2)..minOf(texts.lastIndex, i + 2)) {
                val nearby = numberFromText(texts[j])
                if (nearby != null && looksLikeQuote(nearby, asset)) return nearby
            }
        }

        // Some terminals expose all text in one accessibility node. In that
        // case use the quote nearest to the expected instrument scale.
        val candidates = texts.flatMap { text ->
            numberMatches(text).filter { looksLikeQuote(it, asset) }
        }
        return candidates.minByOrNull { abs(it - asset.basePrice) }
    }

    private fun numberFromText(text: String): Double? =
        numberMatches(text).firstOrNull()

    private fun numberMatches(text: String): List<Double> {
        val matcher = pricePattern.matcher(text.replace(",", ""))
        val result = mutableListOf<Double>()
        while (matcher.find()) {
            matcher.group(1).toDoubleOrNull()?.let(result::add)
        }
        return result
    }

    private fun looksLikeQuote(value: Double, asset: Asset): Boolean {
        if (value <= 0.0) return false
        return when (asset) {
            Asset.EUR_USD, Asset.GBP_USD -> value in 0.5..2.5
            Asset.USD_JPY -> value in 50.0..250.0
            Asset.BTC_USD -> value in 1_000.0..200_000.0
            Asset.ASIA_COMPOSITE, Asset.CRYPTO_COMPOSITE, Asset.EUROPE_COMPOSITE, Asset.COMPOUND_INDEX ->
                value in asset.basePrice * 0.25..asset.basePrice * 4.0
        }
    }

    override fun onInterrupt() {
        feed.disconnect()
    }
}
