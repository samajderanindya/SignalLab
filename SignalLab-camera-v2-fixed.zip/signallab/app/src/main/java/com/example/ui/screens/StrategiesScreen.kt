package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConditionOperator
import com.example.data.model.IndicatorParameters
import com.example.data.model.SignalDirection
import com.example.data.model.StrategyCondition
import com.example.data.model.TradingStrategy
import com.example.ui.components.DemoDataBanner
import com.example.ui.components.DirectionBadge
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBlack
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalCyanGlow
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceHighlight
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.RestartAlt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StrategiesScreen(
    strategies: List<TradingStrategy>,
    indicatorParams: IndicatorParameters = IndicatorParameters(),
    builderName: String,
    builderDescription: String,
    builderAction: SignalDirection,
    builderExpiry: Int,
    builderConditions: List<StrategyCondition>,
    onNameChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onActionChange: (SignalDirection) -> Unit,
    onExpiryChange: (Int) -> Unit,
    onAddCondition: () -> Unit,
    onRemoveCondition: (String) -> Unit,
    onUpdateCondition: (Int, StrategyCondition) -> Unit,
    onSaveStrategy: () -> Unit,
    onTestInBacktest: (String) -> Unit,
    onDeleteStrategy: (String) -> Unit,
    onUpdateIndicatorParams: (IndicatorParameters) -> Unit = {},
    onResetIndicatorParams: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showParamsEditor by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_strategies"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // DEMO DATA Banner
        item {
            DemoDataBanner()
        }

        // Technical Indicator Parameters Editor
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("indicator_parameters_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(TerminalSurfaceHighlight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = null,
                                    tint = TerminalCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "GLOBAL STRATEGY PARAMETERS",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "EMA Fast: ${indicatorParams.emaFastPeriod} • Slow: ${indicatorParams.emaSlowPeriod} • RSI: ${indicatorParams.rsiPeriod} • ST: ${indicatorParams.supertrendPeriod}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { showParamsEditor = !showParamsEditor },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCyan.copy(alpha = 0.6f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TerminalCyan)
                        ) {
                            Text(if (showParamsEditor) "Collapse" else "Configure", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (showParamsEditor) {
                        Spacer(modifier = Modifier.height(14.dp))

                        // EMA & RSI Rows
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("EMA FAST PERIOD", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp))
                                Spacer(modifier = Modifier.height(2.dp))
                                OutlinedTextField(
                                    value = indicatorParams.emaFastPeriod.toString(),
                                    onValueChange = { str ->
                                        str.toIntOrNull()?.let { onUpdateIndicatorParams(indicatorParams.copy(emaFastPeriod = it.coerceIn(2, 50))) }
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TerminalCyan,
                                        unfocusedBorderColor = TerminalBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedContainerColor = TerminalSurfaceVariant,
                                        unfocusedContainerColor = TerminalSurfaceVariant
                                    )
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("EMA SLOW PERIOD", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp))
                                Spacer(modifier = Modifier.height(2.dp))
                                OutlinedTextField(
                                    value = indicatorParams.emaSlowPeriod.toString(),
                                    onValueChange = { str ->
                                        str.toIntOrNull()?.let { onUpdateIndicatorParams(indicatorParams.copy(emaSlowPeriod = it.coerceIn(5, 200))) }
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TerminalCyan,
                                        unfocusedBorderColor = TerminalBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedContainerColor = TerminalSurfaceVariant,
                                        unfocusedContainerColor = TerminalSurfaceVariant
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("RSI PERIOD", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp))
                                Spacer(modifier = Modifier.height(2.dp))
                                OutlinedTextField(
                                    value = indicatorParams.rsiPeriod.toString(),
                                    onValueChange = { str ->
                                        str.toIntOrNull()?.let { onUpdateIndicatorParams(indicatorParams.copy(rsiPeriod = it.coerceIn(2, 50))) }
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TerminalCyan,
                                        unfocusedBorderColor = TerminalBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedContainerColor = TerminalSurfaceVariant,
                                        unfocusedContainerColor = TerminalSurfaceVariant
                                    )
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("SUPERTREND MULTIPLIER", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp))
                                Spacer(modifier = Modifier.height(2.dp))
                                OutlinedTextField(
                                    value = indicatorParams.supertrendMultiplier.toString(),
                                    onValueChange = { str ->
                                        str.toDoubleOrNull()?.let { onUpdateIndicatorParams(indicatorParams.copy(supertrendMultiplier = it.coerceIn(1.0, 10.0))) }
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TerminalCyan,
                                        unfocusedBorderColor = TerminalBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedContainerColor = TerminalSurfaceVariant,
                                        unfocusedContainerColor = TerminalSurfaceVariant
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = onResetIndicatorParams,
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                            ) {
                                Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reset Defaults", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Strategy Visual Builder Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCyan.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("strategy_builder_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(TerminalCyanGlow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = TerminalCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "VISUAL STRATEGY BUILDER",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Strategy Name Input
                    Text(
                        text = "STRATEGY NAME",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = builderName,
                        onValueChange = onNameChange,
                        singleLine = true,
                        placeholder = { Text("e.g. EMA & RSI Scalper", color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TerminalCyan,
                            unfocusedBorderColor = TerminalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = TerminalSurfaceVariant,
                            unfocusedContainerColor = TerminalSurfaceVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Conditions List
                    Text(
                        text = "ENTRY CONDITIONS (LOGIC FLOW)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    builderConditions.forEachIndexed { index, condition ->
                        ConditionBuilderRow(
                            index = index,
                            condition = condition,
                            onUpdate = { updated -> onUpdateCondition(index, updated) },
                            onDelete = { onRemoveCondition(condition.id) },
                            canDelete = builderConditions.size > 1
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // Add Condition Button
                    OutlinedButton(
                        onClick = onAddCondition,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TerminalCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCyan.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("add_condition_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Condition (AND / OR)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Trigger Action (THEN CALL / THEN PUT)
                    Text(
                        text = "THEN EXECUTE SIGNAL",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val isCall = builderAction == SignalDirection.CALL
                        Surface(
                            onClick = { onActionChange(SignalDirection.CALL) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isCall) NeonGreen else TerminalSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isCall) NeonGreen else TerminalBorder),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = null,
                                    tint = if (isCall) TerminalBlack else NeonGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "THEN CALL",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCall) TerminalBlack else NeonGreen
                                    )
                                )
                            }
                        }

                        val isPut = builderAction == SignalDirection.PUT
                        Surface(
                            onClick = { onActionChange(SignalDirection.PUT) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isPut) NeonRed else TerminalSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isPut) NeonRed else TerminalBorder),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    tint = if (isPut) TerminalBlack else NeonRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "THEN PUT",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPut) TerminalBlack else NeonRed
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Expiry Selector
                    Text(
                        text = "EXPIRY DURATION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 2, 3, 5, 10, 15).forEach { exp ->
                            val isSel = exp == builderExpiry
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) TerminalCyan else TerminalSurfaceVariant)
                                    .border(1.dp, if (isSel) TerminalCyan else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { onExpiryChange(exp) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${exp}m",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) TerminalBlack else TextPrimary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Save Strategy Button
                    Button(
                        onClick = onSaveStrategy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = TerminalBlack
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("save_strategy_button")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SAVE CUSTOM STRATEGY",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Saved Strategies Header
        item {
            Text(
                text = "SAVED & PREBUILT STRATEGIES (${strategies.size})",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
        }

        // Strategy Cards List
        items(strategies, key = { it.id }) { strategy ->
            StrategyCardItem(
                strategy = strategy,
                onTestClick = { onTestInBacktest(strategy.id) },
                onDeleteClick = { onDeleteStrategy(strategy.id) }
            )
        }
    }
}

@Composable
private fun ConditionBuilderRow(
    index: Int,
    condition: StrategyCondition,
    onUpdate: (StrategyCondition) -> Unit,
    onDelete: () -> Unit,
    canDelete: Boolean
) {
    var indicatorADropdown by remember { mutableStateOf(false) }
    var operatorDropdown by remember { mutableStateOf(false) }
    var indicatorBDropdown by remember { mutableStateOf(false) }

    val indicatorsList = listOf("EMA 9", "EMA 21", "SMA 20", "SMA 50", "RSI 14", "MACD", "Supertrend", "Upper Bollinger Band", "Lower Bollinger Band", "Close", "30", "50", "70")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (index == 0) "IF" else "AND",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TerminalCyan,
                        fontSize = 11.sp
                    )
                )
                if (canDelete) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Indicator A Box
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .clickable { indicatorADropdown = true }
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = condition.indicatorA,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp
                        )
                    )
                }

                // Operator Box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurfaceHighlight)
                        .border(1.dp, TerminalCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .clickable { operatorDropdown = true }
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = condition.operator.displayName,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    )
                }

                // Indicator B Box
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .clickable { indicatorBDropdown = true }
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = condition.indicatorB,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun StrategyCardItem(
    strategy: TradingStrategy,
    onTestClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("strategy_item_${strategy.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strategy.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = if (strategy.isPrebuilt) "Prebuilt Research Model" else "Custom User Strategy",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TerminalCyan,
                            fontSize = 10.sp
                        )
                    )
                }

                DirectionBadge(direction = strategy.action)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = strategy.description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Visual Rule Summary tags
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurfaceVariant)
                    .padding(8.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    strategy.conditions.forEach { cond ->
                        Text(
                            text = "• ${cond.indicatorA} ${cond.operator.displayName} ${cond.indicatorB}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        )
                    }
                    Text(
                        text = "→ THEN ${strategy.action.label} (Expiry ${strategy.expiryMinutes}m)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (strategy.action.isCall) NeonGreen else NeonRed,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Est. Win Rate: ${strategy.winRateEstimate.toInt()}%",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = NeonGreen,
                        fontWeight = FontWeight.Bold
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!strategy.isPrebuilt) {
                        IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(18.dp))
                        }
                    }

                    Button(
                        onClick = onTestClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TerminalCyan,
                            contentColor = TerminalBlack
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("test_strategy_${strategy.id}")
                    ) {
                        Icon(imageVector = Icons.Default.AutoGraph, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Backtest", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}
