package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SignalLabDarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = TerminalBlack,
    primaryContainer = TerminalSurfaceVariant,
    onPrimaryContainer = NeonGreen,
    secondary = TerminalCyan,
    onSecondary = TerminalBlack,
    secondaryContainer = TerminalSurfaceHighlight,
    onSecondaryContainer = TerminalCyan,
    tertiary = TerminalAmber,
    onTertiary = TerminalBlack,
    error = NeonRed,
    onError = TerminalBlack,
    errorContainer = TerminalSurfaceVariant,
    onErrorContainer = NeonRed,
    background = TerminalBg,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderSubtle
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    // Professional Dark Terminal design always uses SignalLab's high-contrast dark color palette
    MaterialTheme(
        colorScheme = SignalLabDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun SignalLabTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MyApplicationTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

