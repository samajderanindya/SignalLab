# SignalLab forensic audit — 30 Aug 2026

## Executive conclusion

The uploaded project is the source behind the screenshots. The backtest accounting is internally reconciled, and the `NEXT_CANDLE_OPEN` execution path is structurally causal. However, the spectacular results in the screenshots are primarily explained by the demo data model and by strategy/test inconsistencies. The project should **not** treat the 99.4% result as evidence of a viable trading edge.

## Findings

### 1. The screenshots are reproducible from the synthetic generator

The project uses `DeterministicDemoHistoricalDataProvider`, not real market OHLC data. The original generator was built from deterministic sine/cosine price waves plus comparatively small noise. That creates a highly learnable synthetic process. A standalone reproduction of the original generator produced approximately the same Strategy B performance seen in the screenshot (about 99.4–99.6% over the first 500 trades).

### 2. The 500-trade cap was distorting the displayed historical window

A 30-day EUR/USD 5-minute dataset contains about 8,641 candles, but the engine stopped after 500 executed trades. Therefore a result could be labelled as a 30-day backtest while its metrics represented only the earliest processed subset of that window. The cap has been raised to 25,000 and the existing audit warning remains.

### 3. Strategy B did not match its own documented definition

The UI/conditions describe MACD+EMA as a MACD/Signal crossover plus price confirmation. The implementation also allowed a continuation condition (`MACD below signal + negative histogram + EMA trend`) to trigger a new signal. The hardened build now requires the actual crossover for Strategy B. Strategy A has been aligned in the same way.

### 4. The demo history was not comparable across 7/30/90-day runs

The original random seed included the requested candle count. Consequently changing from 30 days to 90 days generated a different random sequence rather than extending the same history. The hardened provider seeds independently of requested count, generates a common 90-day history, and returns its suffix. A regression test now verifies that the 30-day window equals the suffix of the 90-day window when the end time is the same.

### 5. Synthetic data was hardened against trivial indicator predictability

The demo process was replaced with a seeded regime-switching stochastic process using random shocks and modest return autocorrelation. This is still synthetic data, but it is materially less deterministic and less susceptible to indicator phase-locking. It must not be confused with real historical data.

### 6. Unknown custom indicators previously failed open

`resolveValue()` previously returned the current candle close for an unknown operand. That could silently turn a misspelled indicator into a price comparison. It now returns `null`, causing the condition to fail closed.

### 7. Indicator warmup was incomplete for some parameters

The warmup calculation previously focused mainly on EMA/MACD. It now also accounts for RSI, Bollinger, ADX and Supertrend periods.

### 8. The existing unit tests were stale

The test suite referenced `strat_macd_trend` and `strat_bb_reversal`, IDs that no longer exist in the prebuilt strategy list. The tests therefore silently fell back to unrelated strategies. Those IDs were corrected and explicit strategy-ID regression coverage was added.

## What remains before live/research-grade claims

1. Connect a verified historical OHLC source.
2. Store source/provider metadata with every backtest.
3. Add strict train/validation/test or walk-forward evaluation.
4. Add Monte Carlo trade-order and bootstrap confidence analysis.
5. Add transaction/quote realism: spread, slippage, latency, missing bars and market-session rules.
6. For FX, handle weekends/market closures rather than treating the market as continuous 24/7.
7. Compare against simple baselines and random/reversed signals.
8. Report the exact timestamp coverage of executed trades, not only the loaded dataset window.
9. Never label a synthetic result as `AUDITED` in a way that could be mistaken for externally verified profitability.

## Current recommendation

Use the hardened build as a **research sandbox**, not as a live trading system. The next major engineering milestone should be a real-data provider plus an out-of-sample/walk-forward research harness.
