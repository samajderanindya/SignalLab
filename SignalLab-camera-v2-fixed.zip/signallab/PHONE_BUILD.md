# SignalLab — phone-only build path

This project can be built without a computer by using a GitHub Actions runner. The workflow in `.github/workflows/android-build.yml` installs Gradle 9.3.1 on the runner, builds the debug APK, and uploads the APK as a workflow artifact.

The app remains read-only with respect to Olymp Trade: the accessibility bridge observes visible quote text and does not click Up/Down or place orders.

## Local Android build

AndroidIDE is also capable of building Gradle-based Android projects directly on an Android device, but it is optional. The project does not require Android Studio.
