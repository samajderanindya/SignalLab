package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.data.model.Candle
import com.example.data.model.IndicatorType
import com.example.data.model.SignalDirection
import com.example.data.model.Timeframe
import com.example.ui.components.CandlestickChart
import com.example.ui.theme.IndicatorBollinger
import com.example.ui.theme.IndicatorEmaFast
import com.example.ui.theme.IndicatorEmaSlow
import com.example.ui.theme.IndicatorRsi
import com.example.ui.theme.IndicatorSupertrendGreen
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBlack
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalBorderSubtle
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceHighlight
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MarketsScreen(
    selectedAsset: Asset,
    selectedTimeframe: Timeframe,
    candles: List<Candle>,
    activeIndicators: Set<IndicatorType>,
    onSelectAsset: (Asset) -> Unit,
    onSelectTimeframe: (Timeframe) -> Unit,
    onToggleIndicator: (IndicatorType) -> Unit,
    onOpenTradeDialog: (Asset, SignalDirection) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentPrice = candles.lastOrNull()?.close ?: selectedAsset.basePrice

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_markets"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Live terminal feed status. No synthetic candles are shown here.
        item {
            val feedState = com.example.data.engine.OlympTradeAccessibilityService.feed.status
            val label = when (feedState.state) {
                com.example.data.engine.FeedState.LIVE -> "OLYMP TRADE FEED • LIVE QUOTES"
                com.example.data.engine.FeedState.CONNECTING -> "OLYMP TRADE FEED • CONNECTING"
                com.example.data.engine.FeedState.ERROR -> "OLYMP TRADE FEED • ERROR"
                com.example.data.engine.FeedState.DISCONNECTED -> "OLYMP TRADE FEED • WAITING FOR QUOTES"
            }
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = label + if (candles.isEmpty()) "\nOpen Olymp Trade and keep the selected instrument visible." else "",
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (feedState.state == com.example.data.engine.FeedState.LIVE) NeonGreen else TerminalAmber
                    )
                )
            }
        }

        // Asset Selector Tabs (EUR/USD, GBP/USD, USD/JPY, BTC/USD)
        item {
            Column {
                Text(
                    text = "SELECT ASSET",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Asset.values().forEach { asset ->
                        val isSelected = asset == selectedAsset
                        Surface(
                            onClick = { onSelectAsset(asset) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) TerminalCyan else TerminalSurface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) TerminalCyan else TerminalBorder
                            ),
                            modifier = Modifier.testTag("asset_tab_${asset.name}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = asset.code,
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) TerminalBlack else TextPrimary
                                        )
                                    )
                                    Text(
                                        text = "${if (asset.dailyChange >= 0) "+" else ""}${asset.dailyChange}%",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            color = if (isSelected) TerminalBlack.copy(alpha = 0.7f) else if (asset.dailyChange >= 0) NeonGreen else NeonRed,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Timeframe Selector Tabs (1m, 5m, 15m, 30m, 1H)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Timeframe.values().forEach { tf ->
                    val isSelected = tf == selectedTimeframe
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) TerminalSurfaceHighlight else androidx.compose.ui.graphics.Color.Transparent)
                            .clickable { onSelectTimeframe(tf) }
                            .padding(vertical = 6.dp)
                            .testTag("timeframe_tab_${tf.label}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tf.label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TerminalCyan else TextSecondary,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }

        // Candlestick Chart
        item {
            CandlestickChart(
                candles = candles,
                asset = selectedAsset,
                activeIndicators = activeIndicators
            )
        }

        // Indicator Toggle Chips: EMA, SMA, RSI, MACD, Bollinger Bands, ADX, Stochastic, Supertrend
        item {
            Column {
                Text(
                    text = "TECHNICAL INDICATORS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IndicatorType.values().forEach { ind ->
                        val isActive = activeIndicators.contains(ind)
                        val chipColor = when (ind) {
                            IndicatorType.EMA -> IndicatorEmaFast
                            IndicatorType.SMA -> IndicatorEmaSlow
                            IndicatorType.RSI -> IndicatorRsi
                            IndicatorType.BOLLINGER -> IndicatorBollinger
                            IndicatorType.SUPERTREND -> IndicatorSupertrendGreen
                            else -> TerminalCyan
                        }

                        Surface(
                            onClick = { onToggleIndicator(ind) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isActive) chipColor.copy(alpha = 0.2f) else TerminalSurface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isActive) chipColor else TerminalBorderSubtle
                            ),
                            modifier = Modifier.testTag("indicator_btn_${ind.shortName}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isActive) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(chipColor)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                }
                                Text(
                                    text = ind.shortName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isActive) chipColor else TextSecondary,
                                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Fast Simulated Trade Action Bar (CALL / PUT)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("markets_trade_action_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SIMULATE TRADE FOR ${selectedAsset.code}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        )
                        Text(
                            text = "Est. Payout 85%",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NeonGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // CALL Button
                        Button(
                            onClick = { onOpenTradeDialog(selectedAsset, SignalDirection.CALL) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = TerminalBlack
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("markets_btn_call")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "CALL",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "HIGHER",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            }
                        }

                        // PUT Button
                        Button(
                            onClick = { onOpenTradeDialog(selectedAsset, SignalDirection.PUT) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonRed,
                                contentColor = TerminalBlack
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("markets_btn_put")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "PUT",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "LOWER",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
